/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,

  // `imapflow`, `nodemailer`, `mailparser` and `pg` are Node-only libraries.
  // Telling Next to leave them as real `require()` calls (instead of trying to
  // bundle them) avoids "Module not found: fs" style build errors and keeps the
  // serverless function small.
  serverExternalPackages: ['imapflow', 'nodemailer', 'mailparser', 'pg'],

  eslint: {
    // We do not ship an eslint config; never let linting fail a deploy.
    ignoreDuringBuilds: true,
  },
};

export default nextConfig;
