import { randomUUID } from 'node:crypto';

export function newId(): string {
  return randomUUID();
}

export function nowIso(): string {
  return new Date().toISOString();
}

export function slugify(input: string): string {
  return input
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[̀-ͯ]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 60) || 'type';
}

export function clamp(n: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, n));
}

export function round(n: number, places = 3): number {
  const f = 10 ** places;
  return Math.round(n * f) / f;
}

/** Truncate for prompts and previews, without cutting mid-word where avoidable. */
export function truncate(text: string, max: number): string {
  if (text.length <= max) return text;
  const cut = text.slice(0, max);
  const lastSpace = cut.lastIndexOf(' ');
  return (lastSpace > max * 0.7 ? cut.slice(0, lastSpace) : cut) + '…';
}

/** Turn "Priya Sharma <priya@x.com>" into its parts. Tolerates bare addresses. */
export function parseAddress(raw: string): { name: string; email: string } {
  const value = (raw || '').trim();
  const angled = value.match(/^\s*(.*?)\s*<\s*([^<>\s]+@[^<>\s]+)\s*>\s*$/);
  if (angled) {
    return {
      name: angled[1].replace(/^["']|["']$/g, '').trim(),
      email: angled[2].toLowerCase(),
    };
  }
  const bare = value.match(/([^\s<>",]+@[^\s<>",]+)/);
  if (bare) {
    const email = bare[1].toLowerCase().replace(/[.,;]+$/, '');
    const name = value.replace(bare[1], '').replace(/[<>"']/g, '').trim();
    return { name, email };
  }
  return { name: value, email: '' };
}

/**
 * Best-effort human name for greetings.
 * Falls back to the local part of the address ("priya.sharma" → "Priya Sharma").
 */
export function displayName(fromName: string, fromEmail: string): string {
  const name = (fromName || '').trim();
  if (name && !name.includes('@')) return name;
  const local = (fromEmail || '').split('@')[0] || '';
  if (!local) return 'there';
  return (
    local
      .replace(/[._\-+]+/g, ' ')
      .replace(/\d+/g, '')
      .trim()
      .split(/\s+/)
      .filter(Boolean)
      .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
      .join(' ') || 'there'
  );
}

export function firstName(fullName: string): string {
  const first = (fullName || '').trim().split(/\s+/)[0];
  return first || 'there';
}

/** Safe JSON parse that never throws. */
export function safeJson<T>(raw: string, fallback: T): T {
  try {
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

/**
 * Pull the first JSON object out of a model response.
 * Models like to wrap JSON in ```json fences or add a sentence before it.
 */
export function extractJson(raw: string): unknown | null {
  if (!raw) return null;

  const fenced = raw.match(/```(?:json)?\s*([\s\S]*?)```/i);
  const candidates = [fenced?.[1], raw].filter(Boolean) as string[];

  for (const candidate of candidates) {
    const text = candidate.trim();
    try {
      return JSON.parse(text);
    } catch {
      // Fall through to brace scanning.
    }
    // Scan for a balanced {...} block, ignoring braces inside strings.
    const start = text.indexOf('{');
    if (start === -1) continue;
    let depth = 0;
    let inString = false;
    let escaped = false;
    for (let i = start; i < text.length; i++) {
      const ch = text[i];
      if (inString) {
        if (escaped) escaped = false;
        else if (ch === '\\') escaped = true;
        else if (ch === '"') inString = false;
        continue;
      }
      if (ch === '"') inString = true;
      else if (ch === '{') depth++;
      else if (ch === '}') {
        depth--;
        if (depth === 0) {
          try {
            return JSON.parse(text.slice(start, i + 1));
          } catch {
            break;
          }
        }
      }
    }
  }
  return null;
}

/** Reject obviously malformed addresses before we try to send to them. */
export function isValidEmail(value: string): boolean {
  const v = (value || '').trim();
  if (!v || v.length > 254) return false;
  // Single @, no whitespace, no control chars, a dot in the domain.
  if (!/^[^\s@<>,;"]+@[^\s@<>,;"]+\.[^\s@<>,;"]{2,}$/.test(v)) return false;
  if (/[\r\n\t]/.test(v)) return false;
  return true;
}

/**
 * Strip CR/LF from a value destined for an email header.
 * Without this, a crafted subject could inject extra headers.
 */
export function sanitizeHeader(value: string): string {
  return (value || '').replace(/[\r\n]+/g, ' ').trim();
}

/** Turn plain text into simple HTML for the multipart alternative. */
export function textToHtml(text: string): string {
  const escaped = (text || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
  return escaped
    .split(/\n{2,}/)
    .map((p) => `<p>${p.replace(/\n/g, '<br/>')}</p>`)
    .join('\n');
}

export function fileSafe(value: string): string {
  return (value || 'file')
    .replace(/[^a-zA-Z0-9._-]+/g, '_')
    .replace(/^_+|_+$/g, '')
    .slice(0, 80) || 'file';
}
