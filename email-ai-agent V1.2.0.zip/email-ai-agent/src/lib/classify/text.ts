/**
 * Small, dependency-free text analysis used by the offline matcher.
 *
 * Nothing here touches the network, so the app can still sort mail sensibly when
 * no AI key is configured (or when the AI call fails). These are pure functions,
 * which is what lets `tests/heuristic.test.mjs` check them directly.
 */

/**
 * Words that carry no signal about WHICH category an email belongs to.
 * Email pleasantries are included deliberately — "dear", "regards", "kindly"
 * appear in every category and would otherwise make everything look similar.
 */
const STOPWORDS = new Set([
  // grammar
  'a','an','the','and','or','but','if','then','than','that','this','these','those','there','here',
  'is','am','are','was','were','be','been','being','do','does','did','doing','done','have','has','had',
  'having','will','would','shall','should','can','could','may','might','must','of','in','on','at','to',
  'for','with','by','from','as','into','about','over','after','before','between','through','during',
  'above','below','up','down','out','off','again','further','once','it','its','i','me','my','mine','we',
  'us','our','ours','you','your','yours','he','him','his','she','her','hers','they','them','their',
  'theirs','who','whom','which','what','when','where','why','how','all','any','both','each','few',
  'more','most','other','some','such','no','nor','not','only','own','same','so','too','very','just',
  'also','because','while','until','against','being','get','got','let','make','made','one','two','now',
  // email pleasantries and boilerplate — present in every category
  'hi','hello','hey','dear','greetings','sir','madam','thanks','thank','thankyou','regards','best',
  'sincerely','cheers','yours','faithfully','please','kindly','appreciate','appreciated','hope',
  'well','good','morning','afternoon','evening','day','team','support','care','customer','service',
  'email','mail','message','sent','sending','send','write','writing','wrote','reply','replied',
  'response','responding','respond','contact','contacted','regarding','regard','subject','attached',
  'attachment','attaching','find','below','above','follow','following','followup','asap','soon',
  'possible','advance','help','helping','need','needed','want','wanted','like','would','could',
  'looking','look','forward','let','know','update','updated','updating','information','info','detail',
  'details','query','queries','question','questions','issue','issues','matter','concern','concerns',
  'assistance','assist','request','requested','requesting','inquiry','enquiry','sorry','apologies',
]);

/** Collapse whitespace and lowercase — used for phrase/keyword lookups. */
export function normalizeText(text: string): string {
  return (text || '').toLowerCase().replace(/\s+/g, ' ').trim();
}

/**
 * Remove quoted history and signature blocks so a long reply chain does not
 * drown out the actual new message.
 */
export function stripQuotedText(body: string): string {
  const lines = (body || '').split(/\r?\n/);
  const kept: string[] = [];

  for (const line of lines) {
    const trimmed = line.trim();
    // Common reply/forward separators — everything after these is history.
    if (/^-{2,}\s*original message\s*-{2,}$/i.test(trimmed)) break;
    if (/^-{2,}\s*forwarded message\s*-{2,}$/i.test(trimmed)) break;
    if (/^on .{4,80}\bwrote:$/i.test(trimmed)) break;
    if (/^from:\s.+$/i.test(trimmed) && kept.length > 2) break;
    // Signature delimiter per RFC 3676.
    if (trimmed === '--' || trimmed === '-- ') break;
    // Quoted lines.
    if (/^>+/.test(trimmed)) continue;
    kept.push(line);
  }

  const result = kept.join('\n').trim();
  // Only fall back to the original if stripping left nothing at all. A short
  // result is normal and correct: "ok, thanks" above a long quoted chain really
  // is the whole new message, and keeping the chain would drown it out.
  return result.length === 0 ? (body || '').trim() : result;
}

/**
 * Very light suffix stripping.
 *
 * This is not a linguistically correct stemmer and does not try to be. Its only
 * job is to make different surface forms of the same word collapse onto one
 * token, and since it is applied to both sides of every comparison, being crude
 * is harmless while being inconsistent is not.
 *
 * Guaranteed to collapse: plurals ("returns"→"return", "deliveries"→"delivery"),
 * past and progressive forms ("charged"/"charging"/"charge" all → "charg"), and
 * adverbs ("quickly"→"quick").
 *
 * Known limitation: it does not undo consonant doubling, so "ship" and "shipping"
 * remain different tokens. Fixing that would need a dictionary, because the same
 * rule that turns "shipping"→"ship" also turns "bill"→"bil". The keyword matcher
 * covers this case with prefix matching instead.
 */
export function stem(word: string): string {
  let w = word;

  if (w.length > 4 && w.endsWith('ies')) w = `${w.slice(0, -3)}y`;
  else if (w.length > 4 && w.endsWith('sses')) w = w.slice(0, -2);
  else if (w.length > 5 && w.endsWith('ing')) w = w.slice(0, -3);
  else if (w.length > 4 && w.endsWith('ed')) w = w.slice(0, -2);
  else if (w.length > 4 && w.endsWith('ly')) w = w.slice(0, -2);
  else if (w.length > 3 && w.endsWith('s') && !w.endsWith('ss') && !w.endsWith('us')) {
    w = w.slice(0, -1);
  }

  // Collapse a trailing silent "e" so the base form matches its own inflections:
  // without this "charge" stays "charge" while "charged" becomes "charg", and the
  // two never match despite being the same word.
  if (w.length > 4 && w.endsWith('e')) w = w.slice(0, -1);

  return w;
}

/**
 * Split text into comparable tokens.
 *
 * Anything containing a digit collapses to `#num`. That is deliberate: the exact
 * order number "ORD-88213" is unique to one email and would never match
 * anything, but "this text contains a reference number" IS a useful signal that
 * generalises across order and invoice enquiries.
 */
export function tokenize(text: string): string[] {
  const cleaned = (text || '')
    .toLowerCase()
    // Keep letters, digits and a few in-word separators.
    .replace(/[^a-z0-9#\s'\-_/]/g, ' ')
    .replace(/[''`]/g, '');

  const out: string[] = [];
  for (const rawPiece of cleaned.split(/[\s\-_/]+/)) {
    const piece = rawPiece.trim();
    if (!piece) continue;
    if (/\d/.test(piece)) {
      out.push('#num');
      continue;
    }
    if (piece.length < 3) continue;
    if (STOPWORDS.has(piece)) continue;
    const stemmed = stem(piece);
    if (stemmed.length < 3) continue;
    if (STOPWORDS.has(stemmed)) continue;
    out.push(stemmed);
  }
  return out;
}

/** Adjacent token pairs — captures phrases like "order status", "return label". */
export function bigrams(tokens: string[]): string[] {
  const out: string[] = [];
  for (let i = 0; i + 1 < tokens.length; i++) out.push(`${tokens[i]}~${tokens[i + 1]}`);
  return out;
}

export type FeatureVector = Map<string, number>;

/**
 * Build a weighted bag of features for one document.
 * The subject line is weighted more heavily than the body: it is short, written
 * last, and usually states the intent outright.
 */
export function features(subject: string, body: string): FeatureVector {
  const vec: FeatureVector = new Map();
  const add = (key: string, weight: number) => vec.set(key, (vec.get(key) ?? 0) + weight);

  const subjectTokens = tokenize(subject);
  const bodyTokens = tokenize(stripQuotedText(body));

  for (const t of subjectTokens) add(t, 2.0);
  for (const t of bodyTokens) add(t, 1.0);
  for (const g of bigrams(subjectTokens)) add(g, 1.5);
  for (const g of bigrams(bodyTokens)) add(g, 0.75);

  return vec;
}

/**
 * Inverse document frequency over a corpus of documents.
 * Smoothed so a term appearing in every document still has a small positive
 * weight rather than zero.
 */
export function buildIdf(corpus: FeatureVector[]): Map<string, number> {
  const df = new Map<string, number>();
  for (const doc of corpus) {
    for (const term of doc.keys()) df.set(term, (df.get(term) ?? 0) + 1);
  }
  const n = corpus.length || 1;
  const idf = new Map<string, number>();
  for (const [term, count] of df) {
    idf.set(term, Math.log((n + 1) / (count + 1)) + 1);
  }
  return idf;
}

/** Apply sublinear TF scaling and IDF weighting, then L2-normalise. */
export function tfidf(vec: FeatureVector, idf: Map<string, number>): FeatureVector {
  const out: FeatureVector = new Map();
  let norm = 0;
  for (const [term, count] of vec) {
    // Terms unseen in the corpus get the maximum plausible IDF rather than zero,
    // so a distinctive new word is not silently ignored.
    const weight = (1 + Math.log(count)) * (idf.get(term) ?? 2.0);
    out.set(term, weight);
    norm += weight * weight;
  }
  norm = Math.sqrt(norm);
  if (norm > 0) for (const [term, weight] of out) out.set(term, weight / norm);
  return out;
}

/** Cosine similarity of two already-normalised vectors: 0..1. */
export function cosine(a: FeatureVector, b: FeatureVector): number {
  // Iterate the smaller map.
  const [small, large] = a.size <= b.size ? [a, b] : [b, a];
  let dot = 0;
  for (const [term, weight] of small) {
    const other = large.get(term);
    if (other) dot += weight * other;
  }
  return dot < 0 ? 0 : dot > 1 ? 1 : dot;
}

/**
 * A keyword this short must match a whole word.
 *
 * Longer keywords are matched as prefixes, which is what makes "refund" fire on
 * "refunded" and "refunds". Applying that to short keywords is a trap: a prefix
 * match on "a" hits "and", and on "vat" it would hit "Vatican". Requiring a full
 * word below this length keeps the useful behaviour without the false positives.
 */
const PREFIX_MATCH_MIN_LENGTH = 5;

/**
 * Count how strongly a type's curated keywords appear in an email.
 *
 * Multi-word keywords must appear as a contiguous phrase and count double, since
 * "where is my order" is far more telling than "order" on its own.
 */
export function keywordHits(
  keywords: string[],
  subject: string,
  body: string,
): { hits: string[]; score: number } {
  const haystack = normalizeText(`${subject} ${stripQuotedText(body)}`);
  const tokenSet = new Set([...tokenize(subject), ...tokenize(stripQuotedText(body))]);

  const hits: string[] = [];
  let weighted = 0;

  for (const rawKeyword of keywords) {
    const keyword = normalizeText(rawKeyword);
    if (!keyword) continue;

    const isPhrase = keyword.includes(' ');
    let matched = false;

    if (isPhrase) {
      matched = haystack.includes(keyword);
    } else {
      const escaped = keyword.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      // Long keywords match as a prefix ("refund" → "refunded"); short ones must
      // match a whole word, or they fire on unrelated text.
      const boundary =
        keyword.length >= PREFIX_MATCH_MIN_LENGTH
          ? new RegExp(`\\b${escaped}`, 'i')
          : new RegExp(`\\b${escaped}\\b`, 'i');
      matched = boundary.test(haystack) || tokenSet.has(stem(keyword));
    }

    if (matched) {
      hits.push(rawKeyword);
      // Phrases are far more specific than single words, so they count double.
      weighted += isPhrase ? 2 : 1;
    }
  }

  // Saturating: 1 hit ≈ 0.43, 2 ≈ 0.67, 3 ≈ 0.81, 4 ≈ 0.89. Prevents a type with
  // a long keyword list from being punished for having many misses.
  const score = weighted === 0 ? 0 : 1 - Math.exp(-weighted / 1.8);
  return { hits, score };
}
