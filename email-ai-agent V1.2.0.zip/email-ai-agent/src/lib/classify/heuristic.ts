import type { TypeScore } from '../types';
import { clamp, round } from '../util';
import { buildIdf, cosine, features, keywordHits, tfidf, type FeatureVector } from './text';

/** Everything the matcher needs to know about one candidate type. */
export interface TypeProfile {
  typeId: string;
  typeName: string;
  slug: string;
  description: string;
  keywords: string[];
  /** The fed "input drafts" — example incoming emails for this type. */
  samples: Array<{ subject: string; body: string }>;
}

export interface HeuristicBreakdown extends TypeScore {
  /** Similarity to the single closest input draft (nearest neighbour). */
  bestSample: number;
  /** Similarity to all of this type's material combined. */
  centroid: number;
  /** How many curated keywords fired, before corroboration damping. */
  keyword: number;
  /** How much the similarity signals back up the keyword hits, 0.35..1. */
  corroboration: number;
}

/** How the three signals are mixed into one score. Tuned against the seed data. */
const WEIGHTS = { bestSample: 0.45, centroid: 0.2, keyword: 0.35 } as const;

/** Below this similarity, with no keyword hit at all, we treat the match as noise. */
const NOISE_FLOOR = 0.08;
const NOISE_PENALTY = 0.25;

/**
 * Keyword hits need corroboration from the similarity signals.
 *
 * Without this, an email about a completely unrelated subject can score well just
 * by happening to contain one of a type's keywords. A real supplier pitch that
 * mentions a "trial shipment" is not an order-status enquiry, and its similarity
 * to every order-status example is near zero — that disagreement is the signal.
 *
 * Similarity at or above SATURATION leaves keywords at full strength; at zero
 * similarity keywords retain only FLOOR of their weight.
 */
const CORROBORATION_SATURATION = 0.3;
const CORROBORATION_FLOOR = 0.35;

/**
 * Score an incoming email against every known type — with no network calls.
 *
 * This runs on every email, even when an AI provider is configured, because:
 *   1. it is the fallback when the AI call fails or no key is set;
 *   2. it gives the "why did it decide this" panel real numbers to show;
 *   3. it is a sanity check on the AI's answer.
 *
 * Returns every type, ranked best-first.
 */
export function scoreHeuristic(
  email: { subject: string; body: string },
  profiles: TypeProfile[],
): HeuristicBreakdown[] {
  if (!profiles.length) return [];

  // --- build the IDF corpus -------------------------------------------------
  // One document per input draft, plus one per type description. Using individual
  // samples (rather than one blob per type) gives a larger corpus and therefore a
  // more meaningful IDF with very little training data.
  const corpus: FeatureVector[] = [];
  const sampleVectors = new Map<string, FeatureVector[]>();
  const centroidVectors = new Map<string, FeatureVector>();

  for (const profile of profiles) {
    const perSample: FeatureVector[] = [];

    for (const sample of profile.samples) {
      const vec = features(sample.subject, sample.body);
      if (vec.size) {
        perSample.push(vec);
        corpus.push(vec);
      }
    }
    sampleVectors.set(profile.typeId, perSample);

    // The centroid document mixes description, keywords and every sample, so a
    // type still scores sensibly when it has only a description and no samples yet.
    const combined: FeatureVector = new Map();
    const merge = (vec: FeatureVector, weight: number) => {
      for (const [term, value] of vec) combined.set(term, (combined.get(term) ?? 0) + value * weight);
    };
    merge(features(profile.typeName, profile.description), 1.5);
    merge(features('', profile.keywords.join('. ')), 1.5);
    for (const vec of perSample) merge(vec, 1);

    centroidVectors.set(profile.typeId, combined);
    if (combined.size) corpus.push(combined);
  }

  const idf = buildIdf(corpus);
  const emailVec = tfidf(features(email.subject, email.body), idf);

  // --- score each type ------------------------------------------------------
  const results: HeuristicBreakdown[] = profiles.map((profile) => {
    let bestSample = 0;
    for (const vec of sampleVectors.get(profile.typeId) ?? []) {
      const sim = cosine(emailVec, tfidf(vec, idf));
      if (sim > bestSample) bestSample = sim;
    }

    const centroidVec = centroidVectors.get(profile.typeId);
    const centroid = centroidVec?.size ? cosine(emailVec, tfidf(centroidVec, idf)) : 0;

    const { hits, score: keyword } = keywordHits(profile.keywords, email.subject, email.body);

    // Damp keyword evidence when nothing else about the email resembles this type.
    const corroboration = clamp(
      (bestSample + centroid) / CORROBORATION_SATURATION,
      CORROBORATION_FLOOR,
      1,
    );
    const corroboratedKeyword = keyword * corroboration;

    let score =
      WEIGHTS.bestSample * bestSample +
      WEIGHTS.centroid * centroid +
      WEIGHTS.keyword * corroboratedKeyword;

    // An email that neither resembles any example nor trips a single keyword is
    // almost certainly a category we have never seen. Push it firmly down so the
    // threshold check flags it for a human instead of guessing.
    if (bestSample < NOISE_FLOOR && keyword === 0) score *= NOISE_PENALTY;

    return {
      typeId: profile.typeId,
      typeName: profile.typeName,
      slug: profile.slug,
      score: round(score, 4),
      matchedKeywords: hits,
      bestSample: round(bestSample, 4),
      centroid: round(centroid, 4),
      keyword: round(keyword, 4),
      corroboration: round(corroboration, 4),
    };
  });

  return results.sort((a, b) => b.score - a.score || a.typeName.localeCompare(b.typeName));
}

/** Gap between the winner and the runner-up. A small gap means "not sure". */
export function scoreMargin(scores: Array<{ score: number }>): number {
  if (scores.length === 0) return 0;
  if (scores.length === 1) return scores[0].score;
  return round(scores[0].score - scores[1].score, 4);
}
