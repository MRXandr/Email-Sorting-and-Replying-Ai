import { resolveAiProvider } from '../ai';
import { AiError } from '../ai/provider';
import type { ClassificationMethod, EmailType, Settings, TypeScore } from '../types';
import { extractJson, round, truncate } from '../util';
import { scoreHeuristic, scoreMargin, type HeuristicBreakdown, type TypeProfile } from './heuristic';
import { stripQuotedText } from './text';

export interface ClassifyInput {
  subject: string;
  body: string;
}

export interface ClassifyResult {
  /** null means "matches no known type" → the caller flags it for a human. */
  typeId: string | null;
  confidence: number;
  method: ClassificationMethod;
  reasoning: string;
  /** Every type, ranked by the offline matcher, with signal breakdowns. */
  scores: HeuristicBreakdown[];
  aiRaw: string | null;
  /** Populated only when `typeId` is null — explains why it could not be matched. */
  flagReason: string | null;
  /** Set when an AI provider was configured but the call failed. */
  aiError: string | null;
  aiUsed: boolean;
}

interface AiVerdict {
  slug: string | null;
  /** The model's confidence in whatever it said, 0..1. */
  confidence: number;
  reasoning: string;
  raw: string;
  /** Set when the model named a category that does not exist. */
  invalidSlug?: string;
}

/** How many example input drafts per type to put in the prompt. */
const EXAMPLES_PER_TYPE = 3;
/** Character budget per example, to keep the prompt affordable. */
const EXAMPLE_CHARS = 420;
/** Character budget for the email being classified. */
const EMAIL_CHARS = 2600;

const SYSTEM_PROMPT = `You are an email triage classifier for a company's shared support inbox.

You are given a catalogue of the categories this company handles. Each category has a description and real examples of incoming mail. Your job is to decide which SINGLE category a new email belongs to.

The most important rule: if the email does not clearly belong to one of the listed categories, you MUST return null for "slug".

Returning null is a correct and valuable answer, not a failure. The catalogue covers only what this company has taught you so far. Mail it does not cover — supplier and partnership pitches, job applications, press enquiries, legal or regulatory notices, invoices from vendors, internal mail, marketing spam, or any genuinely new kind of request — must return null so a human can look at it and decide.

Never stretch a category to make an email fit. A wrong category causes a wrong automated reply to be drafted to a real customer. Returning null simply routes the email to a person, which is always safe.

Judge the email by what the sender actually wants, not by isolated words. An email that mentions "shipment" while pitching wholesale packaging is a supplier pitch, not a customer asking where their order is.

Respond with a single JSON object in exactly this shape:
{
  "slug": "<the slug of the matching category, or null>",
  "confidence": <number from 0 to 1, how sure you are>,
  "reasoning": "<one or two sentences explaining the decision>",
  "runners_up": [{ "slug": "<slug>", "confidence": <number> }]
}

Set "confidence" honestly. Use a value below 0.6 when you are genuinely unsure, and prefer null over a low-confidence guess when nothing really fits.`;

/** Build the catalogue section of the prompt from the types and their input drafts. */
function buildCatalogue(profiles: TypeProfile[]): string {
  return profiles
    .map((profile) => {
      const lines: string[] = [];
      lines.push(`### CATEGORY slug: ${profile.slug}`);
      lines.push(`Name: ${profile.typeName}`);
      if (profile.description) lines.push(`Covers: ${profile.description}`);
      if (profile.keywords.length) {
        lines.push(`Typical phrases: ${profile.keywords.slice(0, 18).join(', ')}`);
      }

      profile.samples.slice(0, EXAMPLES_PER_TYPE).forEach((sample, i) => {
        lines.push(`Example ${i + 1} — Subject: ${truncate(sample.subject, 140)}`);
        lines.push(
          `Example ${i + 1} — Body: ${truncate(stripQuotedText(sample.body).replace(/\s+/g, ' '), EXAMPLE_CHARS)}`,
        );
      });

      if (!profile.samples.length) {
        lines.push('(No example emails have been added for this category yet.)');
      }

      return lines.join('\n');
    })
    .join('\n\n');
}

function buildUserPrompt(profiles: TypeProfile[], email: ClassifyInput): string {
  return [
    'Here is the catalogue of categories this company handles.',
    '',
    buildCatalogue(profiles),
    '',
    '---',
    '',
    'Now classify this newly received email:',
    '',
    `Subject: ${truncate(email.subject || '(no subject)', 300)}`,
    'Body:',
    truncate(stripQuotedText(email.body) || '(empty body)', EMAIL_CHARS),
    '',
    `Valid slugs are exactly: ${profiles.map((p) => p.slug).join(', ')}`,
    'Use null for "slug" if none of them genuinely fits.',
  ].join('\n');
}

/** Parse and validate the model's JSON, tolerating fences and stray prose. */
function parseAiVerdict(raw: string, validSlugs: Set<string>): AiVerdict {
  const parsed = extractJson(raw) as Record<string, unknown> | null;
  if (!parsed || typeof parsed !== 'object') {
    throw new AiError('parse', `could not find a JSON object in the response: ${raw.slice(0, 200)}`);
  }

  const rawSlug = parsed.slug;
  let slug: string | null = null;

  if (typeof rawSlug === 'string') {
    const trimmed = rawSlug.trim();
    // Models sometimes write the string "null" or "none" instead of JSON null.
    if (trimmed && !['null', 'none', 'no match', 'unknown', 'n/a'].includes(trimmed.toLowerCase())) {
      slug = trimmed;
    }
  }

  // A slug we do not recognise is treated as "no match" rather than trusted.
  if (slug && !validSlugs.has(slug)) {
    return {
      slug: null,
      confidence: 0,
      reasoning: `The model proposed an unknown category "${slug}", so the email was treated as unmatched.`,
      raw,
      invalidSlug: slug,
    };
  }

  const rawConfidence = Number(parsed.confidence);
  const confidence = Number.isFinite(rawConfidence)
    ? Math.min(1, Math.max(0, rawConfidence > 1 ? rawConfidence / 100 : rawConfidence))
    : 0.5;

  const reasoning =
    typeof parsed.reasoning === 'string' && parsed.reasoning.trim()
      ? parsed.reasoning.trim()
      : 'No reasoning supplied.';

  return { slug, confidence: round(confidence, 3), reasoning, raw };
}

/** Strip the internal breakdown fields, leaving what the API returns to the browser. */
export function toTypeScores(scores: HeuristicBreakdown[]): TypeScore[] {
  return scores.map((s) => ({
    typeId: s.typeId,
    typeName: s.typeName,
    slug: s.slug,
    score: s.score,
    matchedKeywords: s.matchedKeywords,
  }));
}

export function buildProfiles(
  types: EmailType[],
  samplesByType: Map<string, Array<{ subject: string; body: string; source?: string }>>,
): TypeProfile[] {
  return types.map((type) => {
    const samples = [...(samplesByType.get(type.id) ?? [])];
    // Put human-taught corrections first: they are the most informative examples
    // and they are the ones that must survive the per-type example cap.
    samples.sort((a, b) => {
      const aLearned = a.source === 'human_review' ? 0 : 1;
      const bLearned = b.source === 'human_review' ? 0 : 1;
      return aLearned - bLearned;
    });

    return {
      typeId: type.id,
      typeName: type.name,
      slug: type.slug,
      description: type.description,
      keywords: type.keywords,
      samples: samples.map((s) => ({ subject: s.subject, body: s.body })),
    };
  });
}

/**
 * Decide which type an email belongs to.
 *
 * The offline matcher always runs — it is the fallback, and it supplies the
 * numbers shown in the "why this decision" panel. When an AI provider is
 * configured, its verdict takes precedence, because it understands intent rather
 * than vocabulary. If the AI call fails for any reason, the matcher's answer is
 * used and the failure is reported rather than hidden.
 */
export async function classifyEmail(
  email: ClassifyInput,
  profiles: TypeProfile[],
  settings: Settings,
): Promise<ClassifyResult> {
  const scores = scoreHeuristic(email, profiles);

  // --- guard rails ----------------------------------------------------------
  if (!profiles.length) {
    return {
      typeId: null,
      confidence: 0,
      method: 'heuristic',
      reasoning: 'No email types have been configured yet, so nothing could be matched.',
      scores: [],
      aiRaw: null,
      flagReason:
        'No email types exist yet. Add your categories with their input and output drafts on the Types page, then reprocess this email.',
      aiError: null,
      aiUsed: false,
    };
  }

  const hasContent = Boolean((email.subject || '').trim() || stripQuotedText(email.body || '').trim());
  if (!hasContent) {
    return {
      typeId: null,
      confidence: 0,
      method: 'heuristic',
      reasoning: 'The email had no subject and no readable body text.',
      scores,
      aiRaw: null,
      flagReason: 'The email contained no readable text to classify.',
      aiError: null,
      aiUsed: false,
    };
  }

  // --- AI path --------------------------------------------------------------
  const provider = resolveAiProvider();
  let aiError: string | null = null;

  if (provider) {
    try {
      const raw = await provider.complete({
        system: SYSTEM_PROMPT,
        prompt: buildUserPrompt(profiles, email),
        json: true,
        temperature: 0,
        maxTokens: 700,
      });

      const verdict = parseAiVerdict(raw, new Set(profiles.map((p) => p.slug)));
      const chosen = verdict.slug ? profiles.find((p) => p.slug === verdict.slug) : undefined;

      if (!chosen) {
        // `confidence` always means "how likely is it that this email matches one
        // of our known types". A model that is 95% sure nothing fits therefore
        // records 0.05, and a model that named a category we do not have records
        // 0, because there is no valid match to be confident about. Storing its
        // raw 0.95 here would show "0.95 confidence" beside a flagged email.
        return {
          typeId: null,
          confidence: verdict.invalidSlug ? 0 : round(1 - verdict.confidence, 3),
          method: 'ai',
          reasoning: verdict.reasoning,
          scores,
          aiRaw: verdict.raw,
          flagReason: `No existing type matches this email. ${verdict.reasoning}`,
          aiError: null,
          aiUsed: true,
        };
      }

      if (verdict.confidence < settings.confidenceThreshold) {
        return {
          typeId: null,
          confidence: verdict.confidence,
          method: 'ai',
          reasoning: verdict.reasoning,
          scores,
          aiRaw: verdict.raw,
          flagReason:
            `The closest type was "${chosen.typeName}", but confidence was ` +
            `${verdict.confidence.toFixed(2)}, below the ${settings.confidenceThreshold.toFixed(2)} ` +
            `threshold. Flagged rather than answered on a guess.`,
          aiError: null,
          aiUsed: true,
        };
      }

      // Did the offline matcher independently reach the same conclusion?
      const heuristicAgrees = scores[0]?.typeId === chosen.typeId;
      const method: ClassificationMethod = heuristicAgrees ? 'ai+heuristic' : 'ai';
      const agreementNote = heuristicAgrees
        ? ' The offline keyword matcher independently ranked the same type first.'
        : scores[0]
          ? ` Note: the offline matcher would have ranked "${scores[0].typeName}" first (score ${scores[0].score.toFixed(2)}).`
          : '';

      return {
        typeId: chosen.typeId,
        confidence: verdict.confidence,
        method,
        reasoning: verdict.reasoning + agreementNote,
        scores,
        aiRaw: verdict.raw,
        flagReason: null,
        aiError: null,
        aiUsed: true,
      };
    } catch (err) {
      // Fall through to the offline matcher rather than failing the whole request.
      aiError =
        err instanceof AiError
          ? `${err.provider}: ${err.message}`
          : `unexpected error: ${(err as Error).message}`;
      console.error('[classify] AI call failed, falling back to the offline matcher:', aiError);
    }
  }

  // --- offline matcher path -------------------------------------------------
  const top = scores[0];
  const margin = scoreMargin(scores);
  const prefix = aiError
    ? 'The AI provider could not be reached, so the offline keyword matcher decided this. '
    : 'Matched by the offline keyword matcher (no AI provider is configured). ';

  if (!top || top.score < settings.heuristicThreshold) {
    return {
      typeId: null,
      confidence: round(top?.score ?? 0, 3),
      method: 'heuristic',
      reasoning:
        prefix +
        `The best candidate was "${top?.typeName ?? 'none'}" at ${(top?.score ?? 0).toFixed(3)}, ` +
        `below the ${settings.heuristicThreshold.toFixed(2)} threshold.`,
      scores,
      aiRaw: null,
      flagReason:
        `This email does not resemble any existing type. Closest was ` +
        `"${top?.typeName ?? 'none'}" at ${(top?.score ?? 0).toFixed(3)}, under the ` +
        `${settings.heuristicThreshold.toFixed(2)} threshold.`,
      aiError,
      aiUsed: false,
    };
  }

  if (margin < settings.marginThreshold && scores.length > 1) {
    return {
      typeId: null,
      confidence: round(top.score, 3),
      method: 'heuristic',
      reasoning:
        prefix +
        `"${top.typeName}" (${top.score.toFixed(3)}) and "${scores[1].typeName}" ` +
        `(${scores[1].score.toFixed(3)}) scored almost identically.`,
      scores,
      aiRaw: null,
      flagReason:
        `Too close to call between "${top.typeName}" and "${scores[1].typeName}" ` +
        `(gap ${margin.toFixed(3)}, needs ${settings.marginThreshold.toFixed(2)}). ` +
        `A person should decide which is right.`,
      aiError,
      aiUsed: false,
    };
  }

  return {
    typeId: top.typeId,
    confidence: round(top.score, 3),
    method: 'heuristic',
    reasoning:
      prefix +
      `"${top.typeName}" scored ${top.score.toFixed(3)}, beating the runner-up by ${margin.toFixed(3)}.` +
      (top.matchedKeywords?.length ? ` Matched phrases: ${top.matchedKeywords.slice(0, 6).join(', ')}.` : ''),
    scores,
    aiRaw: null,
    flagReason: null,
    aiError,
    aiUsed: false,
  };
}
