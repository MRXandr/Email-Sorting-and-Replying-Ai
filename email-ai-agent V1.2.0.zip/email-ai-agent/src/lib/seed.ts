import type { Store } from './db';
import type { NewEmailType } from './types';

/**
 * Demo data for a fictional retailer, "Northwind Retail".
 *
 * This is the "5 types of email a company receives" from the brief, each with:
 *   - `samples`       — the fed INPUT drafts: example incoming emails
 *   - `replySubject` / `replyBody` — the fed OUTPUT draft: the reply template
 *
 * Replace all of this with your own company's types and drafts from the Types
 * page in the UI; nothing here is hard-coded anywhere else in the app.
 */

export interface SeedType extends NewEmailType {
  samples: Array<{ subject: string; body: string }>;
  replyExamples?: Array<{ subject: string; body: string }>;
}

export const SEED_TYPES: SeedType[] = [
  // ---------------------------------------------------------------- 1
  {
    name: 'Order Status & Delivery',
    slug: 'order-status',
    description:
      'A customer who has already placed an order wants to know where it is: has it shipped, ' +
      'when will it arrive, why is it late, the tracking link is not updating, or delivery was ' +
      'attempted and missed. The order already exists and payment already went through.',
    keywords: [
      'order status',
      'where is my order',
      'where is it',
      'where is my parcel',
      'tracking',
      'tracking number',
      'shipped',
      'dispatch',
      'delivery date',
      'out for delivery',
      'still not arrived',
      'has not arrived',
      'not arrived',
      'not received',
      'nothing has come',
      'no sign of',
      'when will it arrive',
      'when will i receive',
      'still waiting for my order',
      'delayed',
      'late',
      'courier',
      'awb',
      'in transit',
      'redelivery',
    ],
    replyGuidance:
      'Acknowledge the specific order number. Give a clear next step and a concrete timeframe. ' +
      'Never promise a delivery date that has not been confirmed by the logistics team.',
    replySubject: 'Re: {{subject}}',
    replyBody: `Hi {{customer_first_name}},

Thank you for checking in about order {{order_id}}.

I have pulled up your order and it is currently with our logistics partner. You can follow its progress live using the tracking reference on your order page, which updates each time the courier scans the parcel.

If the tracking has not moved in the last 48 hours, that usually means the parcel is waiting at a sorting hub. I have asked our logistics team to confirm the current position and I will write back as soon as they respond.

If it turns out the parcel has been misrouted, we will either reship your items at no cost to you or refund the order in full, whichever you prefer.

Sorry for the wait, and thank you for your patience.

Best regards,
{{signature}}`,
    samples: [
      {
        subject: 'Where is my order 88213?',
        body: `Hello,

I placed order 88213 last Tuesday and the site said it would be delivered in 3-5 days. It has been 9 days now and the tracking page has not changed at all, it still says "label created".

Could you tell me where the parcel actually is and when I will get it?

Thanks,
Rohit Menon`,
      },
      {
        subject: 'Order not shipped yet — ORD-40192',
        body: `Hi team,

My order ORD-40192 still shows as processing. I was charged on the 3rd. When will it be dispatched? I need it before the weekend.

Regards,
Anita`,
      },
      {
        subject: 'Tracking number not working',
        body: `Good morning,

The courier tracking number you sent me for my order returns "no information found" on the courier website. Has the parcel actually been handed over to the courier?

The order number is 77451.

Thanks
Daniel Osei`,
      },
      {
        subject: 'Missed delivery, what now?',
        body: `Hi,

The courier says they attempted delivery yesterday while I was at work and left no card. The tracking now says "returning to sender". I do not want the order cancelled — can you arrange redelivery for Saturday?

Order 90233.

Priya S.`,
      },
    ],
  },

  // ---------------------------------------------------------------- 2
  {
    name: 'Returns & Refunds',
    slug: 'returns-refunds',
    description:
      'A customer wants to send an item back, cancel something already delivered, exchange for a ' +
      'different size or colour, or is chasing a refund they were promised for a return. The item ' +
      'has usually been received and is unwanted, faulty, or the wrong item.',
    keywords: [
      'return',
      'return label',
      'refund',
      'refund status',
      'exchange',
      'swap',
      'send it back',
      'send them back',
      'send this back',
      'wrong item',
      'wrong size',
      'wrong colour',
      'wrong color',
      'too small',
      'too big',
      'does not fit',
      'damaged',
      'defective',
      'faulty',
      'broken',
      'money back',
      'rma',
      'replacement',
      'restocking fee',
    ],
    replyGuidance:
      'State the return window and confirm who pays for shipping. If the item arrived damaged or ' +
      'incorrect, the customer never pays return postage — say so explicitly.',
    replySubject: 'Re: {{subject}} — return for order {{order_id}}',
    replyBody: `Hi {{customer_first_name}},

Thanks for getting in touch about order {{order_id}}, and sorry this one has not worked out.

I have started a return for you. Here is what happens next:

1. A prepaid return label will reach this email address within one working day.
2. Repack the item with all original tags and packaging, and attach the label.
3. Hand the parcel to any partner drop-off point, or book a free pickup from the link in the label email.

Once the item reaches our warehouse and passes inspection, your refund is released to the original payment method. Banks typically take 5-7 working days after that to post it to your statement.

If the item arrived damaged or was not what you ordered, you will not pay anything towards return shipping, and I can send a replacement straight away instead of a refund if you would prefer that.

Just reply and let me know which you would like.

Best regards,
{{signature}}`,
    samples: [
      {
        subject: 'Need to return these shoes',
        body: `Hi,

I received order 61277 yesterday. The shoes are a size too small. I would like to return them and get a refund, or exchange for one size up if that is easier.

How do I send them back?

Thanks
Meera Iyer`,
      },
      {
        subject: 'Item arrived damaged',
        body: `Hello,

The blender from order 55810 arrived with a cracked jug. There is glass in the box. I have attached photos.

I want a replacement, or a full refund if you cannot replace it. I should not have to pay to send back something that arrived broken.

Sam Whitfield`,
      },
      {
        subject: 'Refund still not received',
        body: `Hi,

I returned order 48120 three weeks ago and your warehouse confirmed receipt on the 14th. I still have not seen the refund on my card.

Can you tell me when the money will actually be back in my account?

Regards,
Tolu Adeyemi`,
      },
      {
        subject: 'Wrong item shipped',
        body: `Hi team,

I ordered a navy blue jacket (order 71509) and received a grey hoodie instead. Completely different product.

Please arrange collection of the hoodie and send the jacket I actually paid for.

Thanks,
Lena Fischer`,
      },
    ],
  },

  // ---------------------------------------------------------------- 3
  {
    name: 'Product Information (Pre-Sales)',
    slug: 'product-info',
    description:
      'Someone who has NOT bought yet is asking questions before deciding: specifications, ' +
      'dimensions, materials, compatibility, whether something is in stock, when it will be ' +
      'restocked, warranty length, or whether the company ships to their country. There is no ' +
      'existing order number because the purchase has not happened.',
    keywords: [
      'before i buy',
      'before i order',
      'before ordering',
      'before placing',
      'not bought yet',
      'not ordered yet',
      'thinking of buying',
      'planning to buy',
      'in stock',
      'back in stock',
      'out of stock',
      'restock',
      'availability',
      'available',
      'specification',
      'spec',
      'dimensions',
      'measurements',
      'material',
      'compatible',
      'compatibility',
      'does it come in',
      'which model',
      'what model',
      'warranty',
      'guarantee',
      'do you ship to',
      'do you deliver to',
      'what size',
      'difference between',
      'recommend',
    ],
    replyGuidance:
      'Answer the actual question first, then invite the purchase. Never invent a specification — ' +
      'if the exact figure is not in the product data, say you are confirming it with the supplier.',
    replySubject: 'Re: {{subject}}',
    replyBody: `Hi {{customer_first_name}},

Thanks for your interest, and good question — better to check before ordering than to be disappointed afterwards.

Here is what I can confirm:

- Full specifications, including dimensions and materials, are listed under the "Details" tab on the product page, and that page is always the most current source.
- Stock shown on the product page is live. If an item is out of stock, the page offers a "notify me" option that emails you the moment it is back, usually within two to three weeks.
- Every item carries a 24-month manufacturer warranty against defects, on top of your statutory rights.

If there is a specific measurement or compatibility detail you need that is not on the page, tell me exactly what you are matching it against and I will confirm it with our supplier rather than guess.

Happy to help you pick the right one.

Best regards,
{{signature}}`,
    samples: [
      {
        subject: 'Is the standing desk available in white?',
        body: `Hello,

I am looking at the electric standing desk on your site. Before I order I want to check a few things:

- Does it come in white as well as oak?
- What is the maximum height?
- Is the frame steel or aluminium?

Also, do you ship to Ireland?

Thanks
Ciara Byrne`,
      },
      {
        subject: 'When will the espresso machine be back in stock?',
        body: `Hi,

The Lumo 400 espresso machine has been showing as out of stock for two weeks. Do you know when it will be restocked? I am ready to buy as soon as it is available.

Also is the warranty 1 year or 2?

Regards
Mark T.`,
      },
      {
        subject: 'Will this fit my model?',
        body: `Hi,

I want to check compatibility before I buy. I have a 2019 model and I want to know if the replacement filter cartridge you sell fits it, or whether that is only for the newer version.

The dimensions on the page do not say.

Thanks,
Hannah Krishnan`,
      },
      {
        subject: 'Difference between the two mattress models',
        body: `Good afternoon,

Could you explain the difference between the Cloud and Cloud Pro mattresses? The pages look almost identical apart from the price.

Which one would you recommend for a side sleeper? I have not ordered yet.

Thank you
Oliver Grant`,
      },
    ],
  },

  // ---------------------------------------------------------------- 4
  {
    name: 'Billing & Payment Issue',
    slug: 'billing-payment',
    description:
      'Something is wrong with money mechanics rather than with the goods: charged twice, charged ' +
      'the wrong amount, payment declined at checkout, a pending authorisation that has not ' +
      'cleared, a discount or promo code that did not apply, a VAT or GST invoice needed for ' +
      'accounting, or a subscription that should have been cancelled but still billed.',
    keywords: [
      'charged twice',
      'double charged',
      'duplicate charge',
      'overcharged',
      'wrong amount',
      'payment failed',
      'payment declined',
      'card declined',
      'invoice',
      'gst',
      'vat',
      'tax invoice',
      'promo code',
      'discount code',
      'coupon',
      'pending charge',
      'billed again',
      'billed twice',
      'billed three times',
      'subscription charge',
      'statement',
      'bank statement',
      'deducted',
      'debited',
      'refund the difference',
      'credit note',
      'gstin',
      'billing team',
    ],
    replyGuidance:
      'Be precise about amounts and dates — this is an accounting matter. Distinguish clearly ' +
      'between a real duplicate charge and a pending authorisation, which is not a charge at all.',
    replySubject: 'Re: {{subject}} — billing query',
    replyBody: `Hi {{customer_first_name}},

Thanks for flagging this, and sorry for the concern — an unexpected amount on a statement is never a small thing.

I am raising this with our billing team now. Two things are worth separating:

- A genuine duplicate charge is refunded in full, and we do that without asking you to chase it.
- A pending authorisation looks identical on most banking apps but is not a charge. It is a temporary hold placed at checkout, and it drops off by itself within 5-7 working days without any money leaving your account.

Our billing team will confirm which of the two this is and write to you with the outcome. If it is a duplicate, the refund is raised the same day and a credit note follows by email.

If you need a formal tax invoice for your records, say the word and I will have one issued to this address.

Thank you for your patience while we sort this out.

Best regards,
{{signature}}`,
    samples: [
      {
        subject: 'Charged twice for order 33902',
        body: `Hello,

My bank statement shows two charges of 4,299 on the same day for order 33902. I only placed one order.

Please refund the duplicate. I have attached the statement screenshot.

Regards,
Vikram Nair`,
      },
      {
        subject: 'Promo code did not apply',
        body: `Hi,

I used the code SPRING20 at checkout and the order total did not change. I was charged the full amount on order 29014.

Can you refund the 20% difference?

Thanks
Beatrice Lund`,
      },
      {
        subject: 'Need GST invoice for my purchase',
        body: `Hi team,

I need a proper GST tax invoice for order 51188 for my company accounts. The email receipt I got does not show the GST breakdown or your GSTIN.

Could you send the tax invoice to this address?

Thanks,
Suresh Rao
Finance, Meridian Textiles`,
      },
      {
        subject: 'Payment declined but money taken',
        body: `Hello,

Checkout told me my card was declined so I tried again with a different card. Now I can see a pending amount from the first attempt as well.

Am I going to be charged twice? The successful order is 66207.

Regards
Fatima Haddad`,
      },
    ],
  },

  // ---------------------------------------------------------------- 5
  {
    name: 'Complaint & Service Escalation',
    slug: 'complaint-escalation',
    description:
      'An angry or badly let-down customer escalating. They are unhappy with how they have been ' +
      'treated rather than asking a fresh question: no reply for days, promises broken, being ' +
      'passed between agents, demanding a manager, threatening a chargeback, a consumer forum, ' +
      'social media or legal action, or a formal complaint about rude service.',
    keywords: [
      'unacceptable',
      'appalling',
      'disgusted',
      'furious',
      'fed up',
      'had enough',
      'second time',
      'third time',
      'fourth time',
      'written twice',
      'written three times',
      'no one has replied',
      'nobody has replied',
      'no reply',
      'no response',
      'heard nothing',
      'ignored',
      'ignoring',
      'chasing',
      'still waiting',
      'speak to a manager',
      'talk to a manager',
      'want a manager',
      'supervisor',
      'someone senior',
      'someone in charge',
      'escalate',
      'escalated',
      'formal complaint',
      'complaint',
      'chargeback',
      'dispute the charge',
      'consumer forum',
      'ombudsman',
      'legal action',
      'solicitor',
      'take this further',
      'social media',
      'worst service',
      'terrible service',
      'cancel my account',
      'close my account',
    ],
    replyGuidance:
      'Apologise once, plainly, without excuses. Take ownership with a named owner and a date. Do ' +
      'not re-ask for information the customer has already given. Never argue about who is right.',
    replySubject: 'Re: {{subject}} — escalated, owned by our team',
    replyBody: `Hi {{customer_first_name}},

You are right to be annoyed, and I am sorry. Having to ask more than once is exactly the experience we should not be giving you.

I have escalated this and it is now owned by our senior care team rather than sitting in the general queue. Concretely:

- I have pulled together the full history on your account so you do not have to repeat anything.
- A named specialist is now responsible for seeing this through to a resolution.
- You will receive a substantive update from them by {{expected_resolution_date}}, not just an acknowledgement.

If the delay has left you out of pocket, tell me what it cost you and I will put that to the team along with the case.

Thank you for staying with us long enough to give us the chance to fix it. I would rather hear this directly than have you give up on us quietly.

Best regards,
{{signature}}`,
    samples: [
      {
        subject: 'This is the third time I am writing',
        body: `This is completely unacceptable.

This is the THIRD email I have sent about order 19845 and nobody has replied to any of them. Two weeks of silence. Every time I call I get told someone will ring me back and nobody ever does.

I want to speak to a manager. If I do not hear from someone senior by Friday I am raising this with the consumer forum and disputing the charge with my bank.

Absolutely appalling service.

Gordon Pryce`,
      },
      {
        subject: 'Formal complaint about your support team',
        body: `To whom it may concern,

I wish to register a formal complaint about how I have been treated. I have been passed between four different agents, each of whom asked me to explain the problem from the beginning, and one of whom was openly rude.

I have been a customer for six years. This is the worst service I have received from any company.

I expect a written response from someone with authority.

Margaret Osei-Bonsu`,
      },
      {
        subject: 'Fed up — cancelling everything',
        body: `I have had enough.

Nothing has been resolved, I am still waiting, and the last agent closed my ticket without telling me. I am going to post about this publicly and cancel my account.

If you actually care, someone senior can call me today.

Dev Malhotra`,
      },
    ],
  },
];

/**
 * Example emails for the demo inbox.
 * The last two match NO seeded type on purpose — they exist to demonstrate the
 * flag → file → human review → learn loop.
 */
export const SEED_INBOX: Array<{
  from: string;
  subject: string;
  body: string;
  note: string;
  expectFlag?: boolean;
}> = [
  {
    from: 'Kavya Reddy <kavya.reddy@example.com>',
    subject: 'Still no sign of order 92771',
    note: 'Should classify as Order Status & Delivery',
    body: `Hi,

Order 92771 was supposed to arrive on the 12th. The tracking link has said "in transit" for six days and the courier helpline just puts me on hold.

Can you find out where the parcel actually is?

Thanks,
Kavya`,
  },
  {
    from: 'Tom Brady <t.brady@example.com>',
    subject: 'Jacket is the wrong size, need to send it back',
    note: 'Should classify as Returns & Refunds',
    body: `Hello,

The jacket from order 80145 arrived today but it is far too big — I ordered a medium and this is clearly an XL, the label says so.

I would like to return it for the correct size, or a refund if you have no mediums left. How do I arrange that?

Tom`,
  },
  {
    from: 'Lucia Moretti <lucia.m@example.com>',
    subject: 'Question about the desk before I order',
    note: 'Should classify as Product Information (Pre-Sales)',
    body: `Good morning,

I am about to buy the sit-stand desk but I need to check two things first. What is the desktop thickness, and is the walnut finish real veneer or laminate?

Also, do you ship to Italy, and is the warranty valid there?

I have not placed an order yet.

Kind regards,
Lucia`,
  },
  {
    from: 'Ahmed Farouk <ahmed.farouk@example.com>',
    subject: 'Two charges on my card for one order',
    note: 'Should classify as Billing & Payment Issue',
    body: `Hello,

I placed order 31556 yesterday. My statement shows the amount deducted twice — 2,150 on both lines, same date, same merchant.

Please refund the duplicate charge and confirm in writing.

Regards,
Ahmed Farouk`,
  },
  {
    from: 'Ruth Delaney <r.delaney@example.com>',
    subject: 'Fourth email, still nothing, I want a manager',
    note: 'Should classify as Complaint & Service Escalation',
    body: `This is now my fourth email.

Nobody has replied to a single one. Two of your agents promised a callback and neither happened. I have been waiting nineteen days.

I want this escalated to a manager today. If not, I will be disputing the charge with my bank and taking this to the consumer forum.

This is the worst service I have ever dealt with.

Ruth Delaney`,
  },
  {
    from: 'Priyanka Chandra <priyanka@brightpackaging.example>',
    subject: 'Wholesale partnership proposal — sustainable packaging',
    note: 'Should be FLAGGED — no seeded type covers B2B supplier outreach',
    expectFlag: true,
    body: `Dear Procurement Team,

I am writing on behalf of Bright Packaging, a manufacturer of compostable retail packaging based in Pune.

We supply moulded pulp and FSC-certified cartons to several mid-size retail chains and I believe there is a strong fit with your product range. Our minimum order quantity is 5,000 units and we can hold buffer stock at our Mumbai warehouse.

I have attached our catalogue and current rate card. Would your buying team be open to a 20-minute call next week to discuss volume pricing and a trial shipment?

I am also happy to send physical samples if you share a shipping address.

Warm regards,
Priyanka Chandra
Head of Business Development, Bright Packaging Pvt Ltd`,
  },
  {
    from: 'Joel Mensah <joel.mensah.cv@example.com>',
    subject: 'Application for Warehouse Supervisor position',
    note: 'Should be FLAGGED — recruitment is not one of the five seeded types',
    expectFlag: true,
    body: `Dear Hiring Manager,

I would like to apply for the Warehouse Supervisor role advertised on your careers page (reference WH-114).

I have seven years of experience in distribution centre operations, including four years supervising a team of twelve on a two-shift pattern. I am certified in forklift operation and have led two WMS migrations.

My CV is attached. I am available for interview at any time and could start with four weeks notice.

Thank you for considering my application.

Yours sincerely,
Joel Mensah`,
  },
];

/** Wipe the store and load the demo company, its types, drafts and inbox samples. */
export async function seedDatabase(store: Store, opts: { includeInbox?: boolean } = {}) {
  await store.reset();

  await store.saveSettings({
    companyName: 'Northwind Retail',
    supportSignature: 'Customer Care Team\nNorthwind Retail\nsupport@northwind-retail.example',
  });

  let typeCount = 0;
  let sampleCount = 0;

  for (const seed of SEED_TYPES) {
    const { samples, replyExamples, ...typeInput } = seed;
    const type = await store.createType(typeInput);
    typeCount++;

    for (const sample of samples) {
      await store.addSample({
        typeId: type.id,
        subject: sample.subject,
        body: sample.body,
        source: 'seed',
      });
      sampleCount++;
    }

    for (const example of replyExamples ?? []) {
      await store.addReplyExample({
        typeId: type.id,
        subject: example.subject,
        body: example.body,
        source: 'seed',
      });
    }
  }

  await store.log('seed', `Seeded ${typeCount} email types with ${sampleCount} input drafts`, {
    typeCount,
    sampleCount,
  });

  return { typeCount, sampleCount, inboxCount: opts.includeInbox ? SEED_INBOX.length : 0 };
}
