/**
 * Optional password gate for the hosted site.
 *
 * If APP_PASSWORD is not set the app is open, which is convenient locally. Once
 * it is set, every page and API route requires a session cookie.
 *
 * Uses Web Crypto rather than node:crypto so this module also works inside
 * `middleware.ts`, which runs on the Edge runtime.
 */

export const SESSION_COOKIE = 'mail_agent_session';

/**
 * Derive the session token from the password and secret.
 *
 * The cookie holds this digest, never the password itself, so the password does
 * not sit in the browser. Changing APP_PASSWORD or AUTH_SECRET invalidates every
 * existing session automatically.
 */
export async function sessionToken(password: string, secret: string): Promise<string> {
  const data = new TextEncoder().encode(`${password}::${secret}::mail-agent-v1`);
  const digest = await crypto.subtle.digest('SHA-256', data);
  return [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, '0')).join('');
}

/** Constant-time comparison, so a wrong cookie cannot be guessed byte by byte. */
export function safeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

/** Paths that must stay reachable without a session, or login is impossible. */
export function isPublicPath(pathname: string): boolean {
  return (
    pathname === '/login' ||
    pathname === '/api/login' ||
    pathname === '/api/health' ||
    pathname === '/favicon.ico' ||
    pathname.startsWith('/_next/') ||
    pathname.startsWith('/icon') ||
    pathname.startsWith('/apple-icon')
  );
}
