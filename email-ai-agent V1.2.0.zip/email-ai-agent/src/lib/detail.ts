import type { ListEmailsOptions, Store } from './db';
import type { Draft, EmailDetail, EmailRecord, EmailType, ReviewItem } from './types';

/** Everything the UI needs to render one email on one screen. */
export async function getEmailDetail(store: Store, emailId: string): Promise<EmailDetail | null> {
  const email = await store.getEmail(emailId);
  if (!email) return null;

  const [classification, draft, review] = await Promise.all([
    store.getClassificationForEmail(emailId),
    store.getDraftForEmail(emailId),
    store.getReviewForEmail(emailId),
  ]);

  const type = classification?.typeId ? await store.getType(classification.typeId) : null;

  return { email, classification, type, draft, review };
}

export interface EmailSummary {
  email: EmailRecord;
  typeName: string | null;
  typeId: string | null;
  confidence: number | null;
  method: string | null;
  draftStatus: Draft['status'] | null;
  unresolvedCount: number;
  reviewId: string | null;
  reviewStatus: ReviewItem['status'] | null;
}

/** One page of emails, each with just enough context for a list row. */
export async function listEmailSummaries(
  store: Store,
  opts: ListEmailsOptions = {},
): Promise<{ items: EmailSummary[]; total: number }> {
  const [emails, total, types] = await Promise.all([
    store.listEmails(opts),
    store.countEmails(opts),
    store.listTypes({ includeInactive: true }),
  ]);

  const typeById = new Map<string, EmailType>(types.map((t) => [t.id, t]));

  const items = await Promise.all(
    emails.map(async (email) => {
      const [classification, draft, review] = await Promise.all([
        store.getClassificationForEmail(email.id),
        store.getDraftForEmail(email.id),
        store.getReviewForEmail(email.id),
      ]);

      const type = classification?.typeId ? typeById.get(classification.typeId) : undefined;

      return {
        email,
        typeName: type?.name ?? null,
        typeId: type?.id ?? null,
        confidence: classification?.confidence ?? null,
        method: classification?.method ?? null,
        draftStatus: draft?.status ?? null,
        unresolvedCount: draft?.unresolvedPlaceholders.length ?? 0,
        reviewId: review?.id ?? null,
        reviewStatus: review?.status ?? null,
      };
    }),
  );

  return { items, total };
}

export interface ReviewSummary {
  review: ReviewItem;
  email: EmailRecord | null;
  resolvedTypeName: string | null;
}

/** The review queue with its emails attached. */
export async function listReviewSummaries(
  store: Store,
  status?: ReviewItem['status'],
): Promise<ReviewSummary[]> {
  const reviews = await store.listReviews(status);
  const types = await store.listTypes({ includeInactive: true });
  const typeById = new Map(types.map((t) => [t.id, t]));

  return Promise.all(
    reviews.map(async (review) => ({
      review,
      email: await store.getEmail(review.emailId),
      resolvedTypeName: review.resolvedTypeId
        ? (typeById.get(review.resolvedTypeId)?.name ?? null)
        : null,
    })),
  );
}

export interface TypeDetail {
  type: EmailType;
  samples: Awaited<ReturnType<Store['listSamples']>>;
  replyExamples: Awaited<ReturnType<Store['listReplyExamples']>>;
  classifiedCount: number;
}

export async function getTypeDetail(store: Store, typeId: string): Promise<TypeDetail | null> {
  const type = await store.getType(typeId);
  if (!type) return null;

  const [samples, replyExamples, stats] = await Promise.all([
    store.listSamples(typeId),
    store.listReplyExamples(typeId),
    store.stats(),
  ]);

  return {
    type,
    samples,
    replyExamples,
    classifiedCount: stats.perType.find((p) => p.typeId === typeId)?.count ?? 0,
  };
}
