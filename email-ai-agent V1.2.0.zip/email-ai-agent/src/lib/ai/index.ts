import { aiConfig } from '../config';
import { AnthropicProvider } from './anthropic';
import { GeminiProvider } from './gemini';
import { OpenAiProvider } from './openai';
import type { AiProvider } from './provider';

export { AiError } from './provider';
export type { AiProvider, CompleteRequest } from './provider';

/**
 * Build the configured provider, or return null when no AI is available.
 *
 * `null` is a fully supported state, not an error: the app then runs on the
 * offline matcher and template-filled replies. That is what makes the project
 * demonstrable with no API key and no spend.
 */
export function getAiProvider(): AiProvider | null {
  const cfg = aiConfig();

  switch (cfg.provider) {
    case 'gemini':
      if (!cfg.gemini.apiKey) return null;
      return new GeminiProvider(
        cfg.gemini.apiKey,
        cfg.gemini.model,
        cfg.timeoutMs,
        cfg.gemini.baseUrl,
      );

    case 'openai':
      if (!cfg.openai.apiKey) return null;
      return new OpenAiProvider(
        cfg.openai.apiKey,
        cfg.openai.model,
        cfg.openai.baseUrl,
        cfg.timeoutMs,
      );

    case 'anthropic':
      if (!cfg.anthropic.apiKey) return null;
      return new AnthropicProvider(cfg.anthropic.apiKey, cfg.anthropic.model, cfg.timeoutMs);

    case 'none':
    default:
      return null;
  }
}

/**
 * Test helper: lets the test suite inject a fake provider so the full pipeline
 * can be exercised without network access or an API key.
 */
const globalForAi = globalThis as unknown as { __mailAgentAiOverride?: AiProvider | null };

export function setAiProviderOverride(provider: AiProvider | null | undefined): void {
  globalForAi.__mailAgentAiOverride = provider;
}

export function resolveAiProvider(): AiProvider | null {
  if (globalForAi.__mailAgentAiOverride !== undefined) return globalForAi.__mailAgentAiOverride;
  return getAiProvider();
}
