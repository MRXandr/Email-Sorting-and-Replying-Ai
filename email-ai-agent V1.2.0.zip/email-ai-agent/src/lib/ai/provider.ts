/**
 * A deliberately tiny provider interface: one text-in / text-out call.
 *
 * Both the classifier and the reply drafter build their own prompt and parse
 * their own result, so swapping model vendors touches only the files in this
 * folder. All three implementations use plain `fetch` against the vendor's REST
 * API rather than an SDK, which keeps the dependency tree small and avoids
 * SDK-version churn.
 */

export interface CompleteRequest {
  /** Instructions about role and rules. */
  system?: string;
  /** The actual task and data. */
  prompt: string;
  maxTokens?: number;
  temperature?: number;
  /** Ask the model to emit JSON, where the vendor supports a JSON mode. */
  json?: boolean;
}

export interface AiProvider {
  readonly name: string;
  readonly model: string;
  complete(req: CompleteRequest): Promise<string>;
}

/** Carries enough detail for the UI to explain what went wrong. */
export class AiError extends Error {
  readonly status: number | null;
  readonly provider: string;
  readonly retryable: boolean;

  constructor(provider: string, message: string, status: number | null = null) {
    super(message);
    this.name = 'AiError';
    this.provider = provider;
    this.status = status;
    // 429 = rate limited, 5xx = vendor trouble, null = network/timeout.
    this.retryable = status === 429 || status === null || (status >= 500 && status < 600);
  }
}

/**
 * Turn a vendor error body into something a human can act on.
 * Beginners hit 401 (wrong key) and 429 (free-tier limit) most often, so those
 * get explicit advice rather than a raw status code.
 */
export function describeHttpError(provider: string, status: number, body: string): AiError {
  const snippet = body.slice(0, 400).replace(/\s+/g, ' ').trim();

  let advice = '';
  if (status === 401 || status === 403) {
    advice =
      ' — the API key was rejected. Check the key is copied in full, has no stray spaces, ' +
      'and belongs to the provider selected in AI_PROVIDER.';
  } else if (status === 429) {
    advice =
      ' — rate limit or quota reached. Free tiers allow a limited number of requests per ' +
      'minute; wait a moment and retry, or check your billing page.';
  } else if (status === 404) {
    advice =
      ' — the model name was not found. Check the model setting; model names change over time.';
  } else if (status >= 500) {
    advice = ' — the provider had a server error. This is usually temporary.';
  }

  return new AiError(provider, `${provider} API returned ${status}${advice} ${snippet}`, status);
}

/** fetch with a hard timeout, so a hung request cannot stall the whole email pipeline. */
export async function fetchWithTimeout(
  url: string,
  init: RequestInit,
  timeoutMs: number,
  provider: string,
): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...init, signal: controller.signal });
  } catch (err) {
    const message = (err as Error).name === 'AbortError'
      ? `request timed out after ${timeoutMs}ms`
      : `network error: ${(err as Error).message}`;
    throw new AiError(provider, message, null);
  } finally {
    clearTimeout(timer);
  }
}

/**
 * Run `fn`, retrying once on a retryable failure.
 * One retry is the right amount here: it absorbs a transient 429 or 503 without
 * turning a broken key into a long wait for the user.
 */
export async function withRetry<T>(fn: () => Promise<T>, provider: string): Promise<T> {
  try {
    return await fn();
  } catch (err) {
    const retryable = err instanceof AiError ? err.retryable : false;
    if (!retryable) throw err;
    await new Promise((resolve) => setTimeout(resolve, 1200));
    try {
      return await fn();
    } catch (second) {
      if (second instanceof AiError) throw second;
      throw new AiError(provider, (second as Error).message, null);
    }
  }
}
