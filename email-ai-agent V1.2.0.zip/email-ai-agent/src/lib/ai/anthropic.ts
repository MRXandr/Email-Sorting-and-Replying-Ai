import {
  AiError,
  describeHttpError,
  fetchWithTimeout,
  withRetry,
  type AiProvider,
  type CompleteRequest,
} from './provider';

interface AnthropicResponse {
  content?: Array<{ type?: string; text?: string }>;
  stop_reason?: string;
  error?: { message?: string };
}

/** Anthropic Claude via the Messages API. */
export class AnthropicProvider implements AiProvider {
  readonly name = 'anthropic';
  readonly model: string;
  private readonly apiKey: string;
  private readonly timeoutMs: number;

  constructor(apiKey: string, model: string, timeoutMs: number) {
    this.apiKey = apiKey;
    this.model = model;
    this.timeoutMs = timeoutMs;
  }

  async complete(req: CompleteRequest): Promise<string> {
    if (!this.apiKey) throw new AiError(this.name, 'ANTHROPIC_API_KEY is not set');

    // The Messages API has no JSON mode, so when JSON is wanted we say so in the
    // system prompt and let `extractJson` handle any surrounding prose.
    const system = req.json
      ? `${req.system ?? ''}\n\nRespond with a single valid JSON object and nothing else. No markdown fences, no commentary.`.trim()
      : req.system;

    const body: Record<string, unknown> = {
      model: this.model,
      max_tokens: req.maxTokens ?? 1600,
      temperature: req.temperature ?? 0.2,
      messages: [{ role: 'user', content: req.prompt }],
      ...(system ? { system } : {}),
    };

    return withRetry(async () => {
      const res = await fetchWithTimeout(
        'https://api.anthropic.com/v1/messages',
        {
          method: 'POST',
          headers: {
            'content-type': 'application/json',
            'x-api-key': this.apiKey,
            'anthropic-version': '2023-06-01',
          },
          body: JSON.stringify(body),
        },
        this.timeoutMs,
        this.name,
      );

      const text = await res.text();
      if (!res.ok) throw describeHttpError(this.name, res.status, text);

      let parsed: AnthropicResponse;
      try {
        parsed = JSON.parse(text) as AnthropicResponse;
      } catch {
        throw new AiError(this.name, `could not parse response as JSON: ${text.slice(0, 200)}`);
      }

      const out = (parsed.content ?? [])
        .filter((block) => block.type === 'text' || typeof block.text === 'string')
        .map((block) => block.text ?? '')
        .join('')
        .trim();

      if (!out) {
        throw new AiError(
          this.name,
          `returned no text (${parsed.stop_reason ?? parsed.error?.message ?? 'unknown reason'})`,
        );
      }
      return out;
    }, this.name);
  }
}
