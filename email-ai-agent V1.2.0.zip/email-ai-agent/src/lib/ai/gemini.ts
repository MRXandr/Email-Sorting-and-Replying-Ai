import {
  AiError,
  describeHttpError,
  fetchWithTimeout,
  withRetry,
  type AiProvider,
  type CompleteRequest,
} from './provider';

interface GeminiResponse {
  candidates?: Array<{
    content?: { parts?: Array<{ text?: string }> };
    finishReason?: string;
  }>;
  promptFeedback?: { blockReason?: string };
  error?: { message?: string; status?: string };
}

/** Google Gemini via the Generative Language REST API. */
export class GeminiProvider implements AiProvider {
  readonly name = 'gemini';
  readonly model: string;
  private readonly apiKey: string;
  private readonly baseUrl: string;
  private readonly timeoutMs: number;

  constructor(apiKey: string, model: string, timeoutMs: number, baseUrl: string) {
    this.apiKey = apiKey;
    this.model = model;
    this.timeoutMs = timeoutMs;
    this.baseUrl = baseUrl.replace(/\/+$/, '');
  }

  async complete(req: CompleteRequest): Promise<string> {
    if (!this.apiKey) throw new AiError(this.name, 'GEMINI_API_KEY is not set');

    const url = `${this.baseUrl}/models/${encodeURIComponent(this.model)}:generateContent`;

    const body: Record<string, unknown> = {
      contents: [{ role: 'user', parts: [{ text: req.prompt }] }],
      generationConfig: {
        temperature: req.temperature ?? 0.2,
        maxOutputTokens: req.maxTokens ?? 1600,
        ...(req.json ? { responseMimeType: 'application/json' } : {}),
      },
    };
    if (req.system) {
      body.systemInstruction = { parts: [{ text: req.system }] };
    }

    return withRetry(async () => {
      const res = await fetchWithTimeout(
        url,
        {
          method: 'POST',
          headers: {
            'content-type': 'application/json',
            // Header auth rather than a query string, so the key never lands in logs.
            'x-goog-api-key': this.apiKey,
          },
          body: JSON.stringify(body),
        },
        this.timeoutMs,
        this.name,
      );

      const text = await res.text();
      if (!res.ok) throw describeHttpError(this.name, res.status, text);

      let parsed: GeminiResponse;
      try {
        parsed = JSON.parse(text) as GeminiResponse;
      } catch {
        throw new AiError(this.name, `could not parse response as JSON: ${text.slice(0, 200)}`);
      }

      if (parsed.promptFeedback?.blockReason) {
        throw new AiError(
          this.name,
          `the request was blocked by a content filter (${parsed.promptFeedback.blockReason})`,
        );
      }

      const candidate = parsed.candidates?.[0];
      const out = (candidate?.content?.parts ?? [])
        .map((p) => p.text ?? '')
        .join('')
        .trim();

      if (!out) {
        const reason = candidate?.finishReason ?? parsed.error?.message ?? 'unknown reason';
        // MAX_TOKENS here means the model spent its budget before emitting anything usable.
        throw new AiError(this.name, `returned no text (${reason})`);
      }
      return out;
    }, this.name);
  }
}
