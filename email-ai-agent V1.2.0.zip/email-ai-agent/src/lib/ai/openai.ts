import {
  AiError,
  describeHttpError,
  fetchWithTimeout,
  withRetry,
  type AiProvider,
  type CompleteRequest,
} from './provider';

interface OpenAiResponse {
  choices?: Array<{ message?: { content?: string }; finish_reason?: string }>;
  error?: { message?: string };
}

/**
 * OpenAI Chat Completions. Also works with any provider that mirrors this API
 * (Azure OpenAI, Groq, Together, a local Ollama) by setting OPENAI_BASE_URL.
 */
export class OpenAiProvider implements AiProvider {
  readonly name = 'openai';
  readonly model: string;
  private readonly apiKey: string;
  private readonly baseUrl: string;
  private readonly timeoutMs: number;

  constructor(apiKey: string, model: string, baseUrl: string, timeoutMs: number) {
    this.apiKey = apiKey;
    this.model = model;
    this.baseUrl = baseUrl.replace(/\/+$/, '');
    this.timeoutMs = timeoutMs;
  }

  async complete(req: CompleteRequest): Promise<string> {
    if (!this.apiKey) throw new AiError(this.name, 'OPENAI_API_KEY is not set');

    const messages: Array<{ role: string; content: string }> = [];
    if (req.system) messages.push({ role: 'system', content: req.system });
    messages.push({ role: 'user', content: req.prompt });

    const body: Record<string, unknown> = {
      model: this.model,
      messages,
      temperature: req.temperature ?? 0.2,
      max_tokens: req.maxTokens ?? 1600,
      ...(req.json ? { response_format: { type: 'json_object' } } : {}),
    };

    return withRetry(async () => {
      const res = await fetchWithTimeout(
        `${this.baseUrl}/chat/completions`,
        {
          method: 'POST',
          headers: {
            'content-type': 'application/json',
            authorization: `Bearer ${this.apiKey}`,
          },
          body: JSON.stringify(body),
        },
        this.timeoutMs,
        this.name,
      );

      const text = await res.text();
      if (!res.ok) throw describeHttpError(this.name, res.status, text);

      let parsed: OpenAiResponse;
      try {
        parsed = JSON.parse(text) as OpenAiResponse;
      } catch {
        throw new AiError(this.name, `could not parse response as JSON: ${text.slice(0, 200)}`);
      }

      const out = (parsed.choices?.[0]?.message?.content ?? '').trim();
      if (!out) {
        throw new AiError(
          this.name,
          `returned no text (${parsed.choices?.[0]?.finish_reason ?? parsed.error?.message ?? 'unknown reason'})`,
        );
      }
      return out;
    }, this.name);
  }
}
