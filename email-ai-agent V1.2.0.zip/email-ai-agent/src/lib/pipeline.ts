import { buildProfiles, classifyEmail, toTypeScores } from './classify/classifier';
import { appBaseUrl, reviewTeamEmailDefault, smtpConfigured } from './config';
import type { Store } from './db';
import { draftReply } from './draft/drafter';
import { buildFlagFile } from './flagfile';
import { sendMail } from './mail/smtp';
import type {
  Classification,
  Draft,
  EmailRecord,
  EmailType,
  ReviewItem,
  Settings,
  TypeSample,
} from './types';
import { isValidEmail, nowIso, truncate } from './util';

export interface ProcessInput {
  fromName?: string;
  fromEmail: string;
  toEmail?: string;
  subject: string;
  body: string;
  receivedAt?: string;
  source?: EmailRecord['source'];
  externalId?: string | null;
}

export interface AlertOutcome {
  attempted: boolean;
  ok: boolean;
  to: string | null;
  error: string | null;
  filename: string | null;
}

export interface SendOutcome {
  attempted: boolean;
  ok: boolean;
  error: string | null;
}

export interface ProcessResult {
  email: EmailRecord;
  classification: Classification;
  type: EmailType | null;
  draft: Draft | null;
  review: ReviewItem | null;
  flagged: boolean;
  /** Set when the AI classifier failed and the offline matcher was used instead. */
  aiError: string | null;
  /** Set when the AI drafter failed and the filled template was used instead. */
  draftAiError: string | null;
  alert: AlertOutcome | null;
  autoSend: SendOutcome | null;
  /** True when this exact message had already been processed before. */
  duplicate: boolean;
}

function groupSamples(samples: TypeSample[]): Map<string, TypeSample[]> {
  const map = new Map<string, TypeSample[]>();
  for (const sample of samples) {
    const list = map.get(sample.typeId);
    if (list) list.push(sample);
    else map.set(sample.typeId, [sample]);
  }
  return map;
}

/** Where flagged-email alerts go: the saved setting, else the env default. */
export function resolveReviewEmail(settings: Settings): string {
  const configured = settings.reviewTeamEmail?.trim() || reviewTeamEmailDefault();
  return isValidEmail(configured) ? configured : '';
}

/**
 * The core of the system. For one email:
 *
 *   1. score it against every known type, using the fed input drafts;
 *   2. either match it to a type and draft a reply from that type's output draft,
 *   3. or flag it, write a file describing it, and email the human team.
 *
 * Shared by pasted emails, uploaded files, mailbox fetches and reprocessing, so
 * every route behaves identically.
 */
async function runPipeline(
  store: Store,
  email: EmailRecord,
  settings: Settings,
  opts: { sendAlert: boolean; existingReview?: ReviewItem | null },
): Promise<Omit<ProcessResult, 'duplicate'>> {
  const types = await store.listTypes();
  const samplesByType = groupSamples(await store.listSamples());
  const profiles = buildProfiles(types, samplesByType);

  const verdict = await classifyEmail({ subject: email.subject, body: email.body }, profiles, settings);

  const classification = await store.addClassification({
    emailId: email.id,
    typeId: verdict.typeId,
    confidence: verdict.confidence,
    method: verdict.method,
    reasoning: verdict.reasoning,
    scores: toTypeScores(verdict.scores),
    aiRaw: verdict.aiRaw,
  });

  // ---------------------------------------------------------------- matched
  if (verdict.typeId) {
    const type = types.find((t) => t.id === verdict.typeId) ?? null;

    if (!type) {
      // Defensive: a type was deleted between the two reads.
      const updated = await store.updateEmail(email.id, { status: 'flagged' });
      const review = await store.addReview({
        emailId: email.id,
        reason: 'The matched type no longer exists. Please reassign this email.',
        topScores: toTypeScores(verdict.scores).slice(0, 5),
      });
      return {
        email: updated,
        classification,
        type: null,
        draft: null,
        review,
        flagged: true,
        aiError: verdict.aiError,
        draftAiError: null,
        alert: null,
        autoSend: null,
      };
    }

    const replyExamples = await store.listReplyExamples(type.id);
    const drafted = await draftReply(email, type, replyExamples, settings);

    const draft = await store.addDraft({
      emailId: email.id,
      typeId: type.id,
      subject: drafted.subject,
      body: drafted.body,
      generatedBy: drafted.generatedBy,
      unresolvedPlaceholders: drafted.unresolvedPlaceholders,
      status: 'draft',
    });

    const updated = await store.updateEmail(email.id, { status: 'classified' });

    // Optional auto-send. Off by default: a person approving each reply is the
    // right default for anything that leaves the building in the company's name.
    let autoSend: SendOutcome | null = null;
    if (settings.autoSendEnabled) {
      if (!smtpConfigured()) {
        // Auto-send is on but there is no way to send. Say so rather than doing
        // nothing quietly — a silent no-op here looks like a delivered reply.
        autoSend = {
          attempted: false,
          ok: false,
          error:
            'Auto-send is switched on, but SMTP is not configured, so nothing was sent. ' +
            'Set SMTP_HOST, SMTP_USER and SMTP_PASSWORD, or turn auto-send off.',
        };
      } else if (drafted.unresolvedPlaceholders.length) {
        autoSend = {
          attempted: false,
          ok: false,
          error:
            `Not sent automatically: the draft still has unfilled placeholders ` +
            `(${drafted.unresolvedPlaceholders.join(', ')}). Fill them in and send it by hand.`,
        };
      } else {
        const result = await sendMail({
          to: email.fromEmail,
          subject: draft.subject,
          text: draft.body,
          inReplyTo: email.externalId?.startsWith('<') ? email.externalId : null,
          references: email.externalId?.startsWith('<') ? email.externalId : null,
        });
        autoSend = { attempted: true, ok: result.ok, error: result.error };
        await store.updateDraft(draft.id, {
          status: result.ok ? 'sent' : 'draft',
          sentAt: result.ok ? nowIso() : null,
          sendError: result.error,
        });
        if (result.ok) draft.status = 'sent';
      }
    }

    await store.log(
      'classified',
      `"${truncate(email.subject || '(no subject)', 60)}" → ${type.name}`,
      { emailId: email.id, typeId: type.id, confidence: verdict.confidence, method: verdict.method },
    );

    return {
      email: updated,
      classification,
      type,
      draft: autoSend?.ok ? await store.getDraft(draft.id) : draft,
      review: null,
      flagged: false,
      aiError: verdict.aiError,
      draftAiError: drafted.aiError,
      alert: null,
      autoSend,
    };
  }

  // ---------------------------------------------------------------- flagged
  const updated = await store.updateEmail(email.id, { status: 'flagged' });
  const reason = verdict.flagReason ?? 'This email did not match any existing type.';
  const topScores = toTypeScores(verdict.scores).slice(0, 5);

  const review = opts.existingReview
    ? await store.updateReview(opts.existingReview.id, { reason, topScores, status: 'open' })
    : await store.addReview({ emailId: email.id, reason, topScores });

  // Write the file and forward it to the human team.
  let alert: AlertOutcome | null = null;
  const file = buildFlagFile({
    email: updated,
    classification,
    review,
    settings,
    baseUrl: appBaseUrl(),
  });

  if (opts.sendAlert) {
    const to = resolveReviewEmail(settings);
    if (!to) {
      alert = {
        attempted: false,
        ok: false,
        to: null,
        filename: file.filename,
        error:
          'No review team address is set, so no alert email was sent. Add one on the Settings page ' +
          '(the email is still waiting in the review queue).',
      };
    } else {
      const result = await sendMail({
        to,
        subject: `[Action needed] Unclassified email from ${updated.fromEmail} — ${truncate(updated.subject || '(no subject)', 80)}`,
        text: buildAlertBody(updated, reason, topScores, review.id),
        attachments: [{ filename: file.filename, content: file.content }],
      });
      alert = {
        attempted: true,
        ok: result.ok,
        to,
        error: result.error,
        filename: file.filename,
      };
      await store.updateReview(review.id, {
        alertSentAt: result.ok ? nowIso() : null,
        alertError: result.error,
      });
      if (result.ok) review.alertSentAt = nowIso();
      review.alertError = result.error;
    }
  } else {
    alert = { attempted: false, ok: false, to: null, error: null, filename: file.filename };
  }

  await store.log('flagged', `"${truncate(updated.subject || '(no subject)', 60)}" needs human review`, {
    emailId: updated.id,
    reviewId: review.id,
    reason,
  });

  return {
    email: updated,
    classification,
    type: null,
    draft: null,
    review,
    flagged: true,
    aiError: verdict.aiError,
    draftAiError: null,
    alert,
    autoSend: null,
  };
}

function buildAlertBody(
  email: EmailRecord,
  reason: string,
  topScores: Array<{ typeName: string; score: number }>,
  reviewId: string,
): string {
  const base = appBaseUrl();
  const lines: string[] = [];

  lines.push('An email arrived that does not match any of the email types configured in the system.');
  lines.push('No reply has been sent to the sender. It is waiting for someone to decide what it is.');
  lines.push('');
  lines.push(`From:     ${email.fromName ? `${email.fromName} <${email.fromEmail}>` : email.fromEmail}`);
  lines.push(`Subject:  ${email.subject || '(no subject)'}`);
  lines.push(`Received: ${email.receivedAt}`);
  lines.push('');
  lines.push('Why it was flagged:');
  lines.push(reason);
  lines.push('');

  if (topScores.length) {
    lines.push('Closest existing types (none passed the threshold):');
    for (const score of topScores.slice(0, 3)) {
      lines.push(`  - ${score.typeName}: ${score.score.toFixed(3)}`);
    }
    lines.push('');
  }

  lines.push('Review it here:');
  lines.push(`  ${base}/review/${reviewId}`);
  lines.push('');
  lines.push('You can either assign it to a type that already exists — which teaches the system to');
  lines.push('recognise emails like it in future — or create a new type with its own reply template.');
  lines.push('');
  lines.push('The full email is attached to this message as a text file.');
  lines.push('');
  lines.push('--');
  lines.push('Sent automatically by the email triage agent.');

  return lines.join('\n');
}

/** Take a brand-new email all the way through the pipeline. */
export async function processEmail(store: Store, input: ProcessInput): Promise<ProcessResult> {
  const settings = await store.getSettings();

  // Never process the same message twice — mailbox fetches can overlap.
  if (input.externalId) {
    const existing = await store.findEmailByExternalId(input.externalId);
    if (existing) {
      const classification = await store.getClassificationForEmail(existing.id);
      const draft = await store.getDraftForEmail(existing.id);
      const review = await store.getReviewForEmail(existing.id);
      return {
        email: existing,
        classification:
          classification ??
          ({
            id: '',
            emailId: existing.id,
            typeId: null,
            confidence: 0,
            method: 'heuristic',
            reasoning: 'Already processed previously.',
            scores: [],
            aiRaw: null,
            createdAt: existing.createdAt,
          } as Classification),
        type: classification?.typeId ? await store.getType(classification.typeId) : null,
        draft,
        review,
        flagged: existing.status === 'flagged',
        aiError: null,
        draftAiError: null,
        alert: null,
        autoSend: null,
        duplicate: true,
      };
    }
  }

  const email = await store.createEmail({
    externalId: input.externalId ?? null,
    fromName: input.fromName ?? '',
    fromEmail: input.fromEmail,
    toEmail: input.toEmail ?? '',
    subject: input.subject,
    body: input.body,
    receivedAt: input.receivedAt ?? nowIso(),
    source: input.source ?? 'manual',
    // Provisional; runPipeline sets the real status.
    status: 'classified',
  });

  const result = await runPipeline(store, email, settings, { sendAlert: true });
  return { ...result, duplicate: false };
}

/**
 * Re-run classification and drafting for an email already in the system.
 *
 * Useful after teaching the system something new: an email that was flagged
 * yesterday may classify cleanly today. History is appended, not overwritten, so
 * the earlier decision stays visible.
 */
export async function reprocessEmail(
  store: Store,
  emailId: string,
  opts: { sendAlert?: boolean } = {},
): Promise<ProcessResult> {
  const email = await store.getEmail(emailId);
  if (!email) throw new Error(`Email ${emailId} not found`);

  const settings = await store.getSettings();
  const existingReview = await store.getReviewForEmail(emailId);
  const openReview = existingReview?.status === 'open' ? existingReview : null;

  const result = await runPipeline(store, email, settings, {
    // Do not re-spam the team on a manual reprocess unless explicitly asked.
    sendAlert: opts.sendAlert ?? false,
    existingReview: openReview,
  });

  // If it used to need a human and now does not, close that request out.
  if (!result.flagged && openReview) {
    const closed = await store.updateReview(openReview.id, {
      status: 'resolved',
      resolution: 'existing_type',
      resolvedTypeId: result.type?.id ?? null,
      resolvedBy: 'system (reprocess)',
      resolutionNotes: `Automatically matched to "${result.type?.name ?? 'a type'}" when reprocessed.`,
      resolvedAt: nowIso(),
    });

    await store.log(
      'review_auto_closed',
      `A flagged email now matches "${result.type?.name ?? 'a type'}", so its review was closed`,
      { emailId, reviewId: openReview.id, typeId: result.type?.id ?? null },
    );

    // Return the closed review rather than null: the caller needs to be able to
    // tell the user that the outstanding request was dealt with.
    return { ...result, review: closed, duplicate: false };
  }

  return { ...result, duplicate: false };
}

// ------------------------------------------------------------------ learning

export type ResolvePayload =
  | {
      mode: 'existing';
      typeId: string;
      resolvedBy?: string;
      notes?: string;
      /** Add this email as a training example for the type. Defaults to true. */
      learn?: boolean;
    }
  | {
      mode: 'new';
      name: string;
      description?: string;
      keywords?: string[];
      replySubject?: string;
      replyBody?: string;
      replyGuidance?: string;
      /** Further example incoming emails for the new type. */
      extraSamples?: Array<{ subject: string; body: string }>;
      /** Example approved replies for the new type. */
      replyExamples?: Array<{ subject: string; body: string }>;
      resolvedBy?: string;
      notes?: string;
      learn?: boolean;
    };

export interface ResolveResult extends ProcessResult {
  /** The type the email was filed under. */
  resolvedType: EmailType;
  /** True when a brand-new type was created. */
  createdType: boolean;
  /** True when this email was stored as a training example. */
  learned: boolean;
}

/**
 * Apply a human decision to a flagged email. This is where the system learns.
 *
 * Two routes, matching the brief:
 *
 *   - `existing`: the team says it is really one of the types we already have. The
 *     email is stored as a new input draft for that type, so the next email like
 *     it is recognised without a human.
 *
 *   - `new`: the team says it is a genuinely new category, and supplies the input
 *     and output drafts for it. A new type is created and this email becomes its
 *     first training example.
 *
 * In both cases a reply is then drafted from that type's output draft.
 */
export async function resolveReviewItem(
  store: Store,
  reviewId: string,
  payload: ResolvePayload,
): Promise<ResolveResult> {
  const review = await store.getReview(reviewId);
  if (!review) throw Object.assign(new Error('Review item not found'), { status: 404 });
  if (review.status === 'resolved') {
    throw Object.assign(new Error('This review item has already been resolved'), { status: 409 });
  }

  const email = await store.getEmail(review.emailId);
  if (!email) throw Object.assign(new Error('The email for this review item is missing'), { status: 404 });

  const settings = await store.getSettings();
  const learn = payload.learn !== false;

  let type: EmailType;
  let createdType = false;

  if (payload.mode === 'existing') {
    const existing = await store.getType(payload.typeId);
    if (!existing) {
      throw Object.assign(new Error(`Email type ${payload.typeId} not found`), { status: 400 });
    }
    type = existing;
  } else {
    if (!payload.name?.trim()) {
      throw Object.assign(new Error('A name is required for a new email type'), { status: 400 });
    }
    type = await store.createType({
      name: payload.name.trim(),
      description: payload.description ?? '',
      keywords: payload.keywords ?? [],
      replySubject: payload.replySubject ?? 'Re: {{subject}}',
      replyBody: payload.replyBody ?? '',
      replyGuidance: payload.replyGuidance ?? '',
      active: true,
    });
    createdType = true;

    for (const sample of payload.extraSamples ?? []) {
      if (!sample.subject?.trim() && !sample.body?.trim()) continue;
      await store.addSample({
        typeId: type.id,
        subject: sample.subject ?? '',
        body: sample.body ?? '',
        source: 'manual',
      });
    }
    for (const example of payload.replyExamples ?? []) {
      if (!example.subject?.trim() && !example.body?.trim()) continue;
      await store.addReplyExample({
        typeId: type.id,
        subject: example.subject ?? '',
        body: example.body ?? '',
        source: 'manual',
      });
    }
  }

  // ---- THE LEARNING STEP ----
  // Storing this email as an input draft is what makes the next one like it
  // classify automatically. Tagged `human_review` so it is visibly a correction,
  // counted on the dashboard, and prioritised in the AI prompt.
  if (learn) {
    await store.addSample({
      typeId: type.id,
      subject: email.subject,
      body: email.body,
      source: 'human_review',
    });
  }

  const classification = await store.addClassification({
    emailId: email.id,
    typeId: type.id,
    confidence: 1,
    method: 'human',
    reasoning:
      payload.mode === 'new'
        ? `Assigned by ${payload.resolvedBy?.trim() || 'a reviewer'} to the newly created type "${type.name}".` +
          (payload.notes ? ` Note: ${payload.notes}` : '')
        : `Assigned by ${payload.resolvedBy?.trim() || 'a reviewer'} to the existing type "${type.name}".` +
          (payload.notes ? ` Note: ${payload.notes}` : ''),
    scores: review.topScores,
    aiRaw: null,
  });

  const replyExamples = await store.listReplyExamples(type.id);
  const drafted = await draftReply(email, type, replyExamples, settings);

  const draft = await store.addDraft({
    emailId: email.id,
    typeId: type.id,
    subject: drafted.subject,
    body: drafted.body,
    generatedBy: drafted.generatedBy,
    unresolvedPlaceholders: drafted.unresolvedPlaceholders,
    status: 'draft',
  });

  const updatedEmail = await store.updateEmail(email.id, { status: 'resolved' });

  const updatedReview = await store.updateReview(review.id, {
    status: 'resolved',
    resolution: payload.mode === 'new' ? 'new_type' : 'existing_type',
    resolvedTypeId: type.id,
    resolvedBy: payload.resolvedBy?.trim() || 'a reviewer',
    resolutionNotes: payload.notes ?? '',
    resolvedAt: nowIso(),
  });

  await store.log(
    payload.mode === 'new' ? 'learned_new_type' : 'learned_existing_type',
    payload.mode === 'new'
      ? `New type "${type.name}" created from a flagged email`
      : `Flagged email taught to existing type "${type.name}"`,
    { emailId: email.id, typeId: type.id, reviewId: review.id, learned: learn },
  );

  return {
    email: updatedEmail,
    classification,
    type,
    draft,
    review: updatedReview,
    flagged: false,
    aiError: null,
    draftAiError: drafted.aiError,
    alert: null,
    autoSend: null,
    duplicate: false,
    resolvedType: type,
    createdType,
    learned: learn,
  };
}
