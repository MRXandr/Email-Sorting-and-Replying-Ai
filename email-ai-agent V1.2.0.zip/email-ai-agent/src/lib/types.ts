/**
 * Domain types shared by the whole application.
 *
 * Vocabulary used throughout the codebase (matching the project brief):
 *   - "email type"     = a category of incoming mail, e.g. "Order Status Enquiry"
 *   - "input draft"    = an example INCOMING email for a type. Stored as a
 *                        `TypeSample`. These are what the system compares a new
 *                        email against to decide which type it belongs to.
 *   - "output draft"   = the reply template that has been fed for a type. Stored
 *                        on the type itself as `replySubject` / `replyBody`,
 *                        with optional extra examples as `ReplyExample` rows.
 */

/** How a classification decision was reached. */
export type ClassificationMethod = 'ai' | 'heuristic' | 'ai+heuristic' | 'human';

/** Lifecycle of an incoming email. */
export type EmailStatus =
  /** Matched a known type; a draft reply exists. */
  | 'classified'
  /** Matched nothing confidently; waiting for the human team. */
  | 'flagged'
  /** Was flagged, then a human decided what it was. */
  | 'resolved';

/** Where an email came from. */
export type EmailSource = 'manual' | 'upload' | 'imap' | 'seed';

/** Lifecycle of a drafted reply. */
export type DraftStatus = 'draft' | 'edited' | 'sent' | 'discarded';

/** Lifecycle of a human-review item. */
export type ReviewStatus = 'open' | 'resolved';

/** Where a training sample came from. `human_review` samples are the ones the
 *  system LEARNED — added when the human team resolved a flagged email. */
export type SampleSource = 'seed' | 'manual' | 'human_review';

/** An email category, with its fed output draft. */
export interface EmailType {
  id: string;
  name: string;
  /** URL-safe identifier. Also what the AI returns when it picks a type. */
  slug: string;
  /** Plain-English description of what belongs in this category. Fed to the AI. */
  description: string;
  /** Strong lexical signals for this category, used by the offline matcher. */
  keywords: string[];
  /** Output draft — subject line template. Supports {{placeholders}}. */
  replySubject: string;
  /** Output draft — body template. Supports {{placeholders}}. */
  replyBody: string;
  /** Extra instructions for the AI when rewriting the output draft (tone, must-mentions). */
  replyGuidance: string;
  active: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface NewEmailType {
  name: string;
  slug?: string;
  description?: string;
  keywords?: string[];
  replySubject?: string;
  replyBody?: string;
  replyGuidance?: string;
  active?: boolean;
}

/** An example INCOMING email for a type — an "input draft". */
export interface TypeSample {
  id: string;
  typeId: string;
  subject: string;
  body: string;
  source: SampleSource;
  createdAt: string;
}

/** An extra example REPLY for a type — an additional "output draft". */
export interface ReplyExample {
  id: string;
  typeId: string;
  subject: string;
  body: string;
  source: SampleSource;
  createdAt: string;
}

/** An incoming email the system has received. */
export interface EmailRecord {
  id: string;
  /** RFC Message-ID (or IMAP uid) — used so the same mail is never processed twice. */
  externalId: string | null;
  fromName: string;
  fromEmail: string;
  toEmail: string;
  subject: string;
  body: string;
  receivedAt: string;
  source: EmailSource;
  status: EmailStatus;
  createdAt: string;
}

export interface NewEmail {
  externalId?: string | null;
  fromName?: string;
  fromEmail: string;
  toEmail?: string;
  subject: string;
  body: string;
  receivedAt?: string;
  source?: EmailSource;
  status?: EmailStatus;
}

/** One type's score for a given email, 0..1. */
export interface TypeScore {
  typeId: string;
  typeName: string;
  slug: string;
  score: number;
  /** Which signals fired, for the "why did it decide this" panel. */
  matchedKeywords?: string[];
}

/** The decision made about one email. */
export interface Classification {
  id: string;
  emailId: string;
  /** null means "did not match any known type" → the email gets flagged. */
  typeId: string | null;
  confidence: number;
  method: ClassificationMethod;
  reasoning: string;
  /** All types, ranked. Lets the UI show runners-up. */
  scores: TypeScore[];
  /** Raw AI response, kept for debugging. */
  aiRaw: string | null;
  createdAt: string;
}

export interface NewClassification {
  emailId: string;
  typeId: string | null;
  confidence: number;
  method: ClassificationMethod;
  reasoning: string;
  scores: TypeScore[];
  aiRaw?: string | null;
}

/** A generated reply, built from the type's output draft. */
export interface Draft {
  id: string;
  emailId: string;
  typeId: string | null;
  subject: string;
  body: string;
  /** e.g. "gemini:gemini-2.0-flash" or "template" */
  generatedBy: string;
  /** Placeholders the system could not fill from the incoming email. */
  unresolvedPlaceholders: string[];
  status: DraftStatus;
  sentAt: string | null;
  sendError: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface NewDraft {
  emailId: string;
  typeId: string | null;
  subject: string;
  body: string;
  generatedBy: string;
  unresolvedPlaceholders?: string[];
  status?: DraftStatus;
}

/** A flagged email awaiting a human decision. */
export interface ReviewItem {
  id: string;
  emailId: string;
  reason: string;
  /** Best guesses at the time of flagging, so the human has a starting point. */
  topScores: TypeScore[];
  status: ReviewStatus;
  alertSentAt: string | null;
  alertError: string | null;
  resolution: 'existing_type' | 'new_type' | null;
  resolvedTypeId: string | null;
  resolvedBy: string | null;
  resolutionNotes: string;
  resolvedAt: string | null;
  createdAt: string;
}

export interface NewReviewItem {
  emailId: string;
  reason: string;
  topScores: TypeScore[];
}

/** Runtime settings the user can change in the UI without redeploying. */
export interface Settings {
  companyName: string;
  supportSignature: string;
  /** Where flagged-email alerts are sent. */
  reviewTeamEmail: string;
  /**
   * Minimum confidence to accept the AI's answer, 0..1. Below this → flag.
   * This applies to the confidence the model reports about its own choice.
   */
  confidenceThreshold: number;
  /**
   * Minimum score to accept the offline matcher's answer, 0..1. Below this → flag.
   * Kept separate from `confidenceThreshold` because the two numbers are not on
   * the same scale: a model reports 0.9 for an obvious match, whereas the
   * matcher's cosine-based score for the same email is around 0.5. The default
   * comes from `scripts/calibrate.mjs`, which measures the gap between known and
   * unknown mail on the seeded data.
   */
  heuristicThreshold: number;
  /** The winner must beat the runner-up by at least this much, or it is ambiguous. */
  marginThreshold: number;
  /** If true, drafts are emailed automatically. Off by default — humans approve. */
  autoSendEnabled: boolean;
  updatedAt: string;
}

export interface LogEntry {
  id: string;
  at: string;
  kind: string;
  message: string;
  meta: Record<string, unknown> | null;
}

export interface Stats {
  totalEmails: number;
  classified: number;
  flaggedOpen: number;
  resolved: number;
  typeCount: number;
  sampleCount: number;
  learnedSampleCount: number;
  draftsSent: number;
  perType: Array<{ typeId: string; typeName: string; count: number }>;
}

/** Everything the UI needs to show one email on one screen. */
export interface EmailDetail {
  email: EmailRecord;
  classification: Classification | null;
  type: EmailType | null;
  draft: Draft | null;
  review: ReviewItem | null;
}
