import { simpleParser } from 'mailparser';
import { parseAddress } from '../util';

export interface ParsedIncoming {
  externalId: string | null;
  fromName: string;
  fromEmail: string;
  toEmail: string;
  subject: string;
  body: string;
  receivedAt: string;
  /** Message-ID of the original, so a reply can thread correctly. */
  messageId: string | null;
  references: string | null;
}

/** HTML fallback for messages that carry no plain-text alternative. */
function htmlToText(html: string): string {
  return html
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<\/(p|div|tr|li|h[1-6])>/gi, '\n')
    .replace(/<li[^>]*>/gi, '- ')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/&quot;/gi, '"')
    .replace(/&#39;/gi, "'")
    .replace(/[ \t]+\n/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

/** Parse a full RFC 822 message — an uploaded .eml file, or an IMAP fetch. */
export async function parseRawEmail(raw: string | Buffer): Promise<ParsedIncoming> {
  const parsed = await simpleParser(raw);

  const fromEntry = parsed.from?.value?.[0];
  const fromEmail = (fromEntry?.address ?? '').toLowerCase();
  const fromName = fromEntry?.name ?? '';

  // `to` may be a single object or an array depending on the message.
  const toList = Array.isArray(parsed.to) ? parsed.to : parsed.to ? [parsed.to] : [];
  const toEmail = (toList[0]?.value?.[0]?.address ?? '').toLowerCase();

  const text = (parsed.text ?? '').trim();
  const body = text || (parsed.html ? htmlToText(String(parsed.html)) : '');

  return {
    externalId: parsed.messageId ?? null,
    fromName,
    fromEmail,
    toEmail,
    subject: parsed.subject ?? '',
    body,
    receivedAt: (parsed.date ?? new Date()).toISOString(),
    messageId: parsed.messageId ?? null,
    references: Array.isArray(parsed.references)
      ? parsed.references.join(' ')
      : (parsed.references ?? null),
  };
}

/** True when text looks like a saved email rather than just a message body. */
export function looksLikeRawEmail(text: string): boolean {
  const head = (text || '').slice(0, 2000);
  // A real message has several headers before the first blank line.
  const headerCount = [
    /^from:\s/im,
    /^to:\s/im,
    /^subject:\s/im,
    /^date:\s/im,
    /^message-id:\s/im,
    /^mime-version:\s/im,
    /^content-type:\s/im,
    /^received:\s/im,
  ].filter((re) => re.test(head)).length;
  return headerCount >= 3;
}

/**
 * Parse text a user pasted into the app.
 *
 * Accepts three shapes, in order of preference:
 *   1. A full .eml message (delegated to `parseRawEmail`).
 *   2. A simple header block — `From:` / `Subject:` lines, a blank line, the body.
 *   3. Just a body, in which case the caller supplies sender and subject.
 */
export async function parsePastedEmail(
  text: string,
  fallback: { from?: string; subject?: string } = {},
): Promise<ParsedIncoming> {
  const input = (text ?? '').replace(/\r\n/g, '\n');

  if (looksLikeRawEmail(input)) {
    const parsed = await parseRawEmail(input);
    // Fall back to supplied values if the message was missing them.
    if (!parsed.fromEmail && fallback.from) {
      const addr = parseAddress(fallback.from);
      parsed.fromEmail = addr.email;
      parsed.fromName = addr.name;
    }
    if (!parsed.subject && fallback.subject) parsed.subject = fallback.subject;
    return parsed;
  }

  // Look for a leading simple header block.
  const lines = input.split('\n');
  const headers: Record<string, string> = {};
  let bodyStart = 0;
  let sawHeader = false;

  for (let i = 0; i < Math.min(lines.length, 12); i++) {
    const line = lines[i];
    if (!line.trim()) {
      if (sawHeader) {
        bodyStart = i + 1;
        break;
      }
      continue;
    }
    const match = line.match(/^(from|to|subject|date|sender|reply-to)\s*:\s*(.*)$/i);
    if (!match) {
      if (sawHeader) bodyStart = i;
      break;
    }
    headers[match[1].toLowerCase()] = match[2].trim();
    sawHeader = true;
    bodyStart = i + 1;
  }

  const body = (sawHeader ? lines.slice(bodyStart).join('\n') : input).trim();
  const fromRaw = headers.from || headers.sender || fallback.from || '';
  const addr = parseAddress(fromRaw);
  const dateRaw = headers.date ? new Date(headers.date) : null;

  return {
    externalId: null,
    fromName: addr.name,
    fromEmail: addr.email,
    toEmail: headers.to ? parseAddress(headers.to).email : '',
    subject: headers.subject || fallback.subject || '',
    body,
    receivedAt:
      dateRaw && !Number.isNaN(dateRaw.getTime()) ? dateRaw.toISOString() : new Date().toISOString(),
    messageId: null,
    references: null,
  };
}
