import { ImapFlow } from 'imapflow';
import { imapConfig, imapConfigured } from '../config';
import { parseRawEmail, type ParsedIncoming } from './parse';

export interface FetchedMessage extends ParsedIncoming {
  uid: number;
}

export interface FetchReport {
  ok: boolean;
  /** Messages handed to the callback. */
  fetched: number;
  /** Messages the callback reported as successfully processed. */
  processed: number;
  /** Messages skipped because they had already been processed before. */
  skipped: number;
  /** Total unread messages waiting, before the batch limit was applied. */
  unseenTotal: number;
  error: string | null;
  notes: string[];
}

/**
 * Hard ceiling on the whole IMAP session.
 *
 * Vercel's Hobby plan allows up to 60s per request, so we stop well short and
 * return what we have rather than being killed mid-flight.
 */
const SESSION_TIMEOUT_MS = 45_000;

function buildClient(): ImapFlow {
  const cfg = imapConfig();
  return new ImapFlow({
    host: cfg.host,
    port: cfg.port,
    secure: cfg.secure,
    auth: { user: cfg.user, pass: cfg.pass },
    // The library is chatty by default; we surface our own messages instead.
    logger: false,
    emitLogs: false,
  });
}

function describeImapError(err: Error): string {
  const raw = err.message || String(err);
  const sys = (err as NodeJS.ErrnoException).code;

  if (/authenticationfailed|invalid credentials|login failed|auth/i.test(raw)) {
    return (
      `${raw} — the mail server rejected the username or password. For Gmail you need a ` +
      `16-character App Password (2-step verification must be on), not your normal password, ` +
      `and IMAP must be enabled in Gmail settings.`
    );
  }
  if (sys === 'ETIMEDOUT' || /timed out|timeout/i.test(raw)) {
    return (
      `${raw} — could not reach the mail server in time. Check IMAP_HOST and IMAP_PORT ` +
      `(993 with IMAP_SECURE=true is the normal combination).`
    );
  }
  if (sys === 'ENOTFOUND' || /getaddrinfo/i.test(raw)) {
    return `${raw} — the IMAP_HOST name could not be resolved. Check it for typos.`;
  }
  if (/does not exist|nonexistent|no such mailbox/i.test(raw)) {
    return `${raw} — the mailbox in IMAP_MAILBOX was not found. "INBOX" is the usual value.`;
  }
  return raw;
}

/** Check credentials without reading any mail — used by the Settings page. */
export async function verifyImap(): Promise<{ ok: boolean; error: string | null; unseen?: number }> {
  if (!imapConfigured()) {
    return { ok: false, error: 'IMAP_HOST, IMAP_USER and IMAP_PASSWORD are not all set.' };
  }

  const client = buildClient();
  try {
    await client.connect();
    const mailbox = await client.mailboxOpen(imapConfig().mailbox, { readOnly: true });
    const unseen = typeof mailbox.exists === 'number' ? mailbox.exists : 0;
    await client.logout();
    return { ok: true, error: null, unseen };
  } catch (err) {
    try {
      await client.close();
    } catch {
      /* already closed */
    }
    return { ok: false, error: describeImapError(err as Error) };
  }
}

/**
 * Fetch unread mail and hand each message to `onMessage`.
 *
 * A message is marked as read on the server only AFTER the callback reports it
 * processed. That ordering matters: if the app crashes or the AI call fails
 * halfway, the message stays unread and is picked up on the next fetch instead of
 * being silently lost.
 */
export async function fetchNewMail(
  onMessage: (msg: FetchedMessage) => Promise<{ processed: boolean; skipped?: boolean }>,
  opts: { batchSize?: number } = {},
): Promise<FetchReport> {
  const report: FetchReport = {
    ok: false,
    fetched: 0,
    processed: 0,
    skipped: 0,
    unseenTotal: 0,
    error: null,
    notes: [],
  };

  if (!imapConfigured()) {
    report.error =
      'IMAP is not configured. Set IMAP_HOST, IMAP_USER and IMAP_PASSWORD to read a real mailbox.';
    return report;
  }

  const cfg = imapConfig();
  const batchSize = Math.min(Math.max(opts.batchSize ?? cfg.batchSize, 1), 25);
  const client = buildClient();
  const deadline = Date.now() + SESSION_TIMEOUT_MS;

  try {
    await client.connect();
    const lock = await client.getMailboxLock(cfg.mailbox);

    try {
      // UIDs rather than sequence numbers: sequence numbers shift as the mailbox changes.
      const found = await client.search({ seen: false }, { uid: true });
      const uids = Array.isArray(found) ? found : [];
      report.unseenTotal = uids.length;

      if (!uids.length) {
        report.ok = true;
        report.notes.push('No unread messages in the mailbox.');
        return report;
      }

      // Newest first, capped, so a large backlog does not blow the time limit.
      const batch = uids.slice(-batchSize).reverse();
      if (uids.length > batch.length) {
        report.notes.push(
          `${uids.length} unread messages found; processing the newest ${batch.length} this run. ` +
            `Click again to continue, or raise IMAP_BATCH_SIZE.`,
        );
      }

      // Read everything into memory first, then close the iterator before issuing
      // other commands on the same connection.
      const raw: Array<{ uid: number; source: Buffer }> = [];
      for await (const message of client.fetch(batch, { uid: true, source: true }, { uid: true })) {
        if (message.source) raw.push({ uid: message.uid, source: message.source });
        if (Date.now() > deadline) {
          report.notes.push('Stopped early to stay inside the request time limit.');
          break;
        }
      }

      for (const item of raw) {
        if (Date.now() > deadline) {
          report.notes.push('Stopped early to stay inside the request time limit.');
          break;
        }

        let parsed: ParsedIncoming;
        try {
          parsed = await parseRawEmail(item.source);
        } catch (err) {
          report.notes.push(`Could not parse message uid ${item.uid}: ${(err as Error).message}`);
          continue;
        }

        report.fetched++;

        const result = await onMessage({
          ...parsed,
          uid: item.uid,
          // Fall back to a mailbox-scoped id so deduplication still works on
          // messages that arrive without a Message-ID header.
          externalId: parsed.externalId || `imap:${cfg.mailbox}:${item.uid}`,
        });

        if (result.skipped) report.skipped++;
        if (result.processed) report.processed++;

        // Only now is it safe to mark the message read.
        if ((result.processed || result.skipped) && cfg.markSeen) {
          try {
            await client.messageFlagsAdd([item.uid], ['\\Seen'], { uid: true });
          } catch (err) {
            report.notes.push(
              `Processed uid ${item.uid} but could not mark it read: ${(err as Error).message}. ` +
                `It may be fetched again next time.`,
            );
          }
        }
      }

      report.ok = true;
      return report;
    } finally {
      lock.release();
    }
  } catch (err) {
    report.error = describeImapError(err as Error);
    return report;
  } finally {
    try {
      await client.logout();
    } catch {
      try {
        await client.close();
      } catch {
        /* nothing more we can do */
      }
    }
  }
}
