import nodemailer from 'nodemailer';
import type { Transporter } from 'nodemailer';
import { smtpConfig, smtpConfigured } from '../config';
import { isValidEmail, sanitizeHeader, textToHtml } from '../util';

export interface SendMailInput {
  to: string;
  subject: string;
  text: string;
  /** Threading headers, so the reply lands in the customer's original thread. */
  inReplyTo?: string | null;
  references?: string | null;
  attachments?: Array<{ filename: string; content: string; contentType?: string }>;
}

export interface SendMailResult {
  ok: boolean;
  messageId: string | null;
  error: string | null;
  /** True when SMTP is simply not configured, as opposed to a real failure. */
  skipped: boolean;
}

/** One transporter per process; nodemailer pools connections internally. */
const globalForSmtp = globalThis as unknown as {
  __mailAgentTransport?: Transporter;
  __mailAgentTransportKey?: string;
};

function getTransport(): Transporter {
  const cfg = smtpConfig();
  const key = `${cfg.host}:${cfg.port}:${cfg.user}:${cfg.secure}`;

  if (globalForSmtp.__mailAgentTransport && globalForSmtp.__mailAgentTransportKey === key) {
    return globalForSmtp.__mailAgentTransport;
  }

  const transport = nodemailer.createTransport({
    host: cfg.host,
    port: cfg.port,
    // true for port 465 (implicit TLS), false for 587 (STARTTLS upgrade).
    secure: cfg.secure,
    auth: { user: cfg.user, pass: cfg.pass },
    // Serverless functions are short-lived; fail fast rather than hold the request.
    connectionTimeout: 20_000,
    greetingTimeout: 15_000,
    socketTimeout: 25_000,
  });

  globalForSmtp.__mailAgentTransport = transport;
  globalForSmtp.__mailAgentTransportKey = key;
  return transport;
}

/** Drop the cached transporter, e.g. after credentials change. */
export function resetSmtpTransport(): void {
  globalForSmtp.__mailAgentTransport?.close?.();
  globalForSmtp.__mailAgentTransport = undefined;
  globalForSmtp.__mailAgentTransportKey = undefined;
}

/**
 * Send one email.
 *
 * Never throws: every caller is in the middle of processing mail and a send
 * failure must not lose the work already done. The result says what happened and
 * the caller records it.
 */
export async function sendMail(input: SendMailInput): Promise<SendMailResult> {
  if (!smtpConfigured()) {
    return {
      ok: false,
      messageId: null,
      skipped: true,
      error:
        'SMTP is not configured. Set SMTP_HOST, SMTP_USER and SMTP_PASSWORD to let the app send email.',
    };
  }

  const recipient = (input.to || '').trim();
  if (!isValidEmail(recipient)) {
    return {
      ok: false,
      messageId: null,
      skipped: false,
      error: `"${recipient}" is not a valid email address, so nothing was sent.`,
    };
  }

  const cfg = smtpConfig();

  try {
    const info = await getTransport().sendMail({
      from: cfg.from,
      to: recipient,
      // Subjects come from model output and from incoming mail, so strip CR/LF —
      // without this, a crafted subject could inject extra SMTP headers.
      subject: sanitizeHeader(input.subject) || '(no subject)',
      text: input.text,
      html: textToHtml(input.text),
      ...(input.inReplyTo ? { inReplyTo: sanitizeHeader(input.inReplyTo) } : {}),
      ...(input.references ? { references: sanitizeHeader(input.references) } : {}),
      ...(input.attachments?.length
        ? {
            attachments: input.attachments.map((a) => ({
              filename: a.filename,
              content: a.content,
              contentType: a.contentType ?? 'text/plain; charset=utf-8',
            })),
          }
        : {}),
    });

    return { ok: true, messageId: info.messageId ?? null, error: null, skipped: false };
  } catch (err) {
    return { ok: false, messageId: null, skipped: false, error: describeSmtpError(err as Error) };
  }
}

/** Verify credentials without sending anything — used by the Settings page. */
export async function verifySmtp(): Promise<{ ok: boolean; error: string | null }> {
  if (!smtpConfigured()) {
    return { ok: false, error: 'SMTP_HOST, SMTP_USER and SMTP_PASSWORD are not all set.' };
  }
  try {
    await getTransport().verify();
    return { ok: true, error: null };
  } catch (err) {
    return { ok: false, error: describeSmtpError(err as Error) };
  }
}

/** Translate the common SMTP failures into something actionable. */
function describeSmtpError(err: Error): string {
  const raw = err.message || String(err);
  const code = (err as NodeJS.ErrnoException & { responseCode?: number }).responseCode;
  const sys = (err as NodeJS.ErrnoException).code;

  if (/invalid login|username and password not accepted|authentication failed/i.test(raw) || code === 535) {
    return (
      `${raw} — the mail server rejected the username or password. For Gmail you must use a ` +
      `16-character App Password (with 2-step verification enabled), not your normal account ` +
      `password. Remove any spaces from the App Password.`
    );
  }
  if (sys === 'ETIMEDOUT' || sys === 'ESOCKET' || /timeout/i.test(raw)) {
    return (
      `${raw} — could not reach the mail server. Check SMTP_HOST and SMTP_PORT, and note that ` +
      `port 465 needs SMTP_SECURE=true while port 587 needs SMTP_SECURE=false.`
    );
  }
  if (sys === 'EDNS' || /getaddrinfo|ENOTFOUND/i.test(raw)) {
    return `${raw} — the SMTP_HOST name could not be resolved. Check it for typos.`;
  }
  if (/self.signed|certificate/i.test(raw)) {
    return `${raw} — a TLS certificate problem. Check SMTP_SECURE matches the port you are using.`;
  }
  return raw;
}
