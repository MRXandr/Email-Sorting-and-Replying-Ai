/**
 * All environment-variable reading happens here, in one place.
 *
 * Every function reads `process.env` fresh on each call rather than caching at
 * module load. That matters on Vercel, where a function instance can be reused
 * across requests, and in tests where we change env between cases.
 */

export type AiProviderName = 'gemini' | 'openai' | 'anthropic' | 'none';

function str(name: string, fallback = ''): string {
  const v = process.env[name];
  return v === undefined || v === null ? fallback : String(v).trim();
}

function bool(name: string, fallback: boolean): boolean {
  const v = str(name);
  if (!v) return fallback;
  return ['1', 'true', 'yes', 'on'].includes(v.toLowerCase());
}

function int(name: string, fallback: number): number {
  const v = parseInt(str(name), 10);
  return Number.isFinite(v) ? v : fallback;
}

/** Which AI provider to use. Auto-detected from whichever key is present. */
export function aiProvider(): AiProviderName {
  const explicit = str('AI_PROVIDER').toLowerCase();
  if (explicit === 'gemini' || explicit === 'openai' || explicit === 'anthropic' || explicit === 'none') {
    return explicit;
  }
  if (str('GEMINI_API_KEY')) return 'gemini';
  if (str('OPENAI_API_KEY')) return 'openai';
  if (str('ANTHROPIC_API_KEY')) return 'anthropic';
  return 'none';
}

export function aiConfig() {
  return {
    provider: aiProvider(),
    gemini: {
      apiKey: str('GEMINI_API_KEY'),
      // Fast + generous free tier. Override with GEMINI_MODEL if you like.
      model: str('GEMINI_MODEL', 'gemini-2.0-flash'),
      // Overridable so the request can be pointed at a proxy or a test double.
      baseUrl: str('GEMINI_BASE_URL', 'https://generativelanguage.googleapis.com/v1beta'),
    },
    openai: {
      apiKey: str('OPENAI_API_KEY'),
      model: str('OPENAI_MODEL', 'gpt-4o-mini'),
      baseUrl: str('OPENAI_BASE_URL', 'https://api.openai.com/v1'),
    },
    anthropic: {
      apiKey: str('ANTHROPIC_API_KEY'),
      model: str('ANTHROPIC_MODEL', 'claude-sonnet-4-5'),
    },
    /** Hard cap on how long we wait for the model before falling back. */
    timeoutMs: int('AI_TIMEOUT_MS', 30000),
  };
}

export function databaseUrl(): string {
  // Vercel's Neon integration sets some of these for you, so accept any of them.
  return (
    str('DATABASE_URL') ||
    str('POSTGRES_URL') ||
    str('POSTGRES_PRISMA_URL') ||
    str('NEON_DATABASE_URL')
  );
}

/** Folder used by the zero-setup local JSON store (when there is no database). */
export function dataDir(): string {
  return str('DATA_DIR', '.data');
}

export function isProduction(): boolean {
  return str('NODE_ENV') === 'production';
}

/**
 * True when running on a serverless host (Vercel, AWS Lambda, Netlify).
 *
 * This matters because such hosts give each request a throwaway, read-only
 * filesystem. The local JSON file store cannot work there at all — not merely
 * "works but does not persist" — so the app must say so plainly rather than
 * fail with a filesystem error the user cannot interpret.
 */
export function isServerless(): boolean {
  return Boolean(
    str('VERCEL') ||
      str('VERCEL_ENV') ||
      str('AWS_LAMBDA_FUNCTION_NAME') ||
      str('LAMBDA_TASK_ROOT') ||
      str('NETLIFY') ||
      str('FUNCTIONS_WORKER_RUNTIME'),
  );
}

/** The exact wording shown wherever a missing database needs explaining. */
export const STORAGE_NOT_CONFIGURED_MESSAGE =
  'This app is hosted on a serverless platform, which does not allow writing files, so it needs ' +
  'a database. Add a DATABASE_URL environment variable with a Postgres connection string, then ' +
  'redeploy. A free one takes about five minutes to set up at neon.com — see docs/03-database.md. ' +
  'Remember that adding an environment variable only takes effect on a NEW deployment.';

export function imapConfig() {
  return {
    host: str('IMAP_HOST'),
    port: int('IMAP_PORT', 993),
    user: str('IMAP_USER'),
    pass: str('IMAP_PASSWORD'),
    secure: bool('IMAP_SECURE', true),
    mailbox: str('IMAP_MAILBOX', 'INBOX'),
    /** Max messages pulled per "Fetch mail" click. Keeps us inside serverless time limits. */
    batchSize: int('IMAP_BATCH_SIZE', 5),
    /** If true, messages are marked \Seen after processing so they are not re-fetched. */
    markSeen: bool('IMAP_MARK_SEEN', true),
  };
}

export function imapConfigured(): boolean {
  const c = imapConfig();
  return Boolean(c.host && c.user && c.pass);
}

export function smtpConfig() {
  return {
    host: str('SMTP_HOST'),
    port: int('SMTP_PORT', 587),
    user: str('SMTP_USER'),
    pass: str('SMTP_PASSWORD'),
    /** true = implicit TLS (port 465). false = STARTTLS (port 587). */
    secure: bool('SMTP_SECURE', int('SMTP_PORT', 587) === 465),
    from: str('SMTP_FROM') || str('SMTP_USER'),
  };
}

export function smtpConfigured(): boolean {
  const c = smtpConfig();
  return Boolean(c.host && c.user && c.pass);
}

/** Fallback review address, used until one is saved in Settings. */
export function reviewTeamEmailDefault(): string {
  return str('REVIEW_TEAM_EMAIL');
}

/**
 * Public base URL, used to put clickable links to the review page into alert
 * emails. Vercel injects VERCEL_URL (without a scheme) automatically.
 */
export function appBaseUrl(): string {
  const explicit = str('APP_BASE_URL');
  if (explicit) return explicit.replace(/\/+$/, '');

  const vercel = str('VERCEL_PROJECT_PRODUCTION_URL') || str('VERCEL_URL');
  if (vercel) return `https://${vercel.replace(/^https?:\/\//, '').replace(/\/+$/, '')}`;

  const port = str('PORT', '3000');
  return `http://localhost:${port}`;
}

export function authConfig() {
  return {
    /** If blank, the site is open — no login screen. */
    password: str('APP_PASSWORD'),
    /** Used to derive the session cookie. Any long random string. */
    secret: str('AUTH_SECRET', 'change-me-in-production'),
  };
}

export function authEnabled(): boolean {
  return Boolean(authConfig().password);
}

/** A summary safe to send to the browser — never includes secrets. */
export function publicConfigSummary() {
  const ai = aiConfig();
  const keyPresent =
    (ai.provider === 'gemini' && Boolean(ai.gemini.apiKey)) ||
    (ai.provider === 'openai' && Boolean(ai.openai.apiKey)) ||
    (ai.provider === 'anthropic' && Boolean(ai.anthropic.apiKey));

  return {
    aiProvider: ai.provider,
    aiModel:
      ai.provider === 'gemini'
        ? ai.gemini.model
        : ai.provider === 'openai'
          ? ai.openai.model
          : ai.provider === 'anthropic'
            ? ai.anthropic.model
            : null,
    aiReady: ai.provider !== 'none' && keyPresent,
    storage: databaseUrl() ? 'postgres' : 'file',
    storageWarning:
      !databaseUrl() && isProduction()
        ? 'No DATABASE_URL is set. On a serverless host the local file store is wiped on every deploy and is not shared between requests. Add a Postgres connection string.'
        : null,
    imapConfigured: imapConfigured(),
    smtpConfigured: smtpConfigured(),
    authEnabled: authEnabled(),
  };
}
