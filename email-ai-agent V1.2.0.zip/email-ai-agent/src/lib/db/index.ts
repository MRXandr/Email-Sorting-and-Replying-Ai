import {
  databaseUrl,
  dataDir,
  isProduction,
  isServerless,
  STORAGE_NOT_CONFIGURED_MESSAGE,
} from '../config';
import { FileStore } from './filestore';
import { PostgresStore } from './postgres';
import type { Store } from './store';

export type { Store, ListEmailsOptions } from './store';
export { DEFAULT_SETTINGS } from './store';

/**
 * Thrown when the app is hosted somewhere it cannot write files and no database
 * has been configured. Carries a 503 so the API layer reports it as a
 * configuration problem rather than a crash.
 */
export class StorageNotConfiguredError extends Error {
  readonly status = 503;
  readonly code = 'STORAGE_NOT_CONFIGURED';

  constructor() {
    super(STORAGE_NOT_CONFIGURED_MESSAGE);
    this.name = 'StorageNotConfiguredError';
  }
}

/**
 * Cached on `globalThis` so Next's dev-mode hot reloading does not create a new
 * connection pool on every file save, and so a warm serverless instance reuses
 * the one it already opened.
 */
const globalForStore = globalThis as unknown as {
  __mailAgentStore?: Store;
  __mailAgentStoreKey?: string;
  __mailAgentWarned?: boolean;
};

/**
 * Returns the initialised store. Safe to call from every request: the schema
 * creation inside `init()` is memoised and idempotent.
 */
export async function getStore(): Promise<Store> {
  const url = databaseUrl();

  // Fail with an explanation rather than a filesystem error. On a serverless host
  // the file store cannot work at all, and falling back to a temporary directory
  // would be worse than failing: each request runs on a different instance, so
  // data would appear and vanish at random, which is far harder to diagnose than
  // a message naming the missing variable.
  if (!url && isServerless()) {
    throw new StorageNotConfiguredError();
  }

  const key = url ? `pg:${url}` : `file:${dataDir()}`;

  // If the connection target changed (tests switch between adapters), rebuild.
  if (globalForStore.__mailAgentStore && globalForStore.__mailAgentStoreKey === key) {
    return globalForStore.__mailAgentStore;
  }

  const store: Store = url ? new PostgresStore(url) : new FileStore(dataDir());

  if (!url && isProduction() && !globalForStore.__mailAgentWarned) {
    globalForStore.__mailAgentWarned = true;
    console.warn(
      '[storage] No DATABASE_URL set while running in production. Falling back to the ' +
        'local JSON file store, which is wiped on every deploy and is not shared between ' +
        'serverless instances. Set DATABASE_URL to a Postgres connection string.',
    );
  }

  await store.init();

  globalForStore.__mailAgentStore = store;
  globalForStore.__mailAgentStoreKey = key;
  return store;
}

/** Test helper: drop the cached instance so the next call rebuilds it. */
export async function resetStoreCache(): Promise<void> {
  const existing = globalForStore.__mailAgentStore;
  globalForStore.__mailAgentStore = undefined;
  globalForStore.__mailAgentStoreKey = undefined;
  if (existing) await existing.close().catch(() => undefined);
}
