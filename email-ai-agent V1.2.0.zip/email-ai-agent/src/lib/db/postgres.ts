import { Pool } from 'pg';
import type { PoolClient, QueryResultRow } from 'pg';
import { SCHEMA_SQL } from './schema';
import { DEFAULT_SETTINGS, type ListEmailsOptions, type Store } from './store';
import type {
  Classification,
  Draft,
  EmailRecord,
  EmailType,
  LogEntry,
  NewClassification,
  NewDraft,
  NewEmail,
  NewEmailType,
  NewReviewItem,
  ReplyExample,
  ReviewItem,
  ReviewStatus,
  SampleSource,
  Settings,
  Stats,
  TypeSample,
} from '../types';
import { newId, nowIso, slugify } from '../util';

/** Arbitrary but fixed key so all instances take the same lock before running DDL. */
const SCHEMA_LOCK_KEY = 918_273_645;

function needsSsl(connectionString: string): boolean {
  if (/sslmode=disable/i.test(connectionString)) return false;
  // Local databases normally have no TLS configured at all.
  if (/@(localhost|127\.0\.0\.1|\[::1\])[:/]/i.test(connectionString)) return false;
  if (/^postgres(ql)?:\/\/[^@]*@?(localhost|127\.0\.0\.1)/i.test(connectionString)) return false;
  return true;
}

/**
 * A single pool per process. On Vercel a warm function instance reuses this, so
 * we do not open a new connection per request. `max` is deliberately small
 * because many instances may exist at once.
 */
const globalForPg = globalThis as unknown as { __mailAgentPool?: Pool };

function getPool(connectionString: string): Pool {
  if (globalForPg.__mailAgentPool) return globalForPg.__mailAgentPool;

  const pool = new Pool({
    connectionString,
    // Neon and most managed providers present a certificate from a public CA,
    // but intermediate proxies vary; we keep TLS on without pinning the chain.
    ssl: needsSsl(connectionString) ? { rejectUnauthorized: false } : false,
    max: 3,
    idleTimeoutMillis: 10_000,
    connectionTimeoutMillis: 15_000,
  });

  // Without a listener, a background client error crashes the process.
  pool.on('error', (err) => {
    console.error('[postgres] idle client error:', err.message);
  });

  globalForPg.__mailAgentPool = pool;
  return pool;
}

// ---------------------------------------------------------------- row mapping

function iso(value: unknown): string {
  if (!value) return nowIso();
  if (value instanceof Date) return value.toISOString();
  return new Date(String(value)).toISOString();
}

function isoOrNull(value: unknown): string | null {
  if (value === null || value === undefined) return null;
  return iso(value);
}

/** JSONB normally arrives parsed, but be tolerant of text columns too. */
function jsonArray<T>(value: unknown): T[] {
  if (Array.isArray(value)) return value as T[];
  if (typeof value === 'string') {
    try {
      const parsed = JSON.parse(value);
      return Array.isArray(parsed) ? (parsed as T[]) : [];
    } catch {
      return [];
    }
  }
  return [];
}

function mapType(r: QueryResultRow): EmailType {
  return {
    id: r.id,
    name: r.name,
    slug: r.slug,
    description: r.description ?? '',
    keywords: jsonArray<string>(r.keywords),
    replySubject: r.reply_subject ?? '',
    replyBody: r.reply_body ?? '',
    replyGuidance: r.reply_guidance ?? '',
    active: Boolean(r.active),
    createdAt: iso(r.created_at),
    updatedAt: iso(r.updated_at),
  };
}

function mapSample(r: QueryResultRow): TypeSample {
  return {
    id: r.id,
    typeId: r.type_id,
    subject: r.subject ?? '',
    body: r.body ?? '',
    source: (r.source ?? 'manual') as SampleSource,
    createdAt: iso(r.created_at),
  };
}

function mapReplyExample(r: QueryResultRow): ReplyExample {
  return mapSample(r) as ReplyExample;
}

function mapEmail(r: QueryResultRow): EmailRecord {
  return {
    id: r.id,
    externalId: r.external_id ?? null,
    fromName: r.from_name ?? '',
    fromEmail: r.from_email ?? '',
    toEmail: r.to_email ?? '',
    subject: r.subject ?? '',
    body: r.body ?? '',
    receivedAt: iso(r.received_at),
    source: r.source,
    status: r.status,
    createdAt: iso(r.created_at),
  };
}

function mapClassification(r: QueryResultRow): Classification {
  return {
    id: r.id,
    emailId: r.email_id,
    typeId: r.type_id ?? null,
    confidence: Number(r.confidence ?? 0),
    method: r.method,
    reasoning: r.reasoning ?? '',
    scores: jsonArray(r.scores),
    aiRaw: r.ai_raw ?? null,
    createdAt: iso(r.created_at),
  };
}

function mapDraft(r: QueryResultRow): Draft {
  return {
    id: r.id,
    emailId: r.email_id,
    typeId: r.type_id ?? null,
    subject: r.subject ?? '',
    body: r.body ?? '',
    generatedBy: r.generated_by ?? '',
    unresolvedPlaceholders: jsonArray<string>(r.unresolved_placeholders),
    status: r.status,
    sentAt: isoOrNull(r.sent_at),
    sendError: r.send_error ?? null,
    createdAt: iso(r.created_at),
    updatedAt: iso(r.updated_at),
  };
}

function mapReview(r: QueryResultRow): ReviewItem {
  return {
    id: r.id,
    emailId: r.email_id,
    reason: r.reason ?? '',
    topScores: jsonArray(r.top_scores),
    status: r.status,
    alertSentAt: isoOrNull(r.alert_sent_at),
    alertError: r.alert_error ?? null,
    resolution: r.resolution ?? null,
    resolvedTypeId: r.resolved_type_id ?? null,
    resolvedBy: r.resolved_by ?? null,
    resolutionNotes: r.resolution_notes ?? '',
    resolvedAt: isoOrNull(r.resolved_at),
    createdAt: iso(r.created_at),
  };
}

// ---------------------------------------------------------------- the adapter

export class PostgresStore implements Store {
  readonly kind = 'postgres' as const;
  private pool: Pool;
  private initPromise: Promise<void> | null = null;

  constructor(connectionString: string) {
    this.pool = getPool(connectionString);
  }

  /**
   * Run a query, recreating the schema once if a table turns out to be missing.
   *
   * `init()` memoises its success, so without this a process that booted against
   * a database whose tables were later dropped or reset — easy to do from a
   * provider's web console, and what happens on a fresh database branch — would
   * fail every request for the rest of its life. Postgres error 42P01 is
   * `undefined_table`, so it is a precise signal, not a catch-all retry.
   */
  private async q<T extends QueryResultRow = QueryResultRow>(
    sql: string,
    params: unknown[] = [],
    allowSchemaRepair = true,
  ): Promise<T[]> {
    try {
      const res = await this.pool.query<T>(sql, params as never[]);
      return res.rows;
    } catch (err) {
      const code = (err as { code?: string }).code;
      if (code !== '42P01' || !allowSchemaRepair) throw err;

      console.warn('[postgres] a table was missing; recreating the schema and retrying once.');
      this.initPromise = null;
      await this.init();
      // Retry with repair disabled, so a genuinely broken schema fails loudly
      // instead of looping.
      return this.q<T>(sql, params, false);
    }
  }

  async init(): Promise<void> {
    // Memoised: the schema is created at most once per process.
    if (this.initPromise) return this.initPromise;

    this.initPromise = (async () => {
      let client: PoolClient | null = null;
      try {
        client = await this.pool.connect();
        await client.query('BEGIN');
        // Serialise DDL across concurrent instances. Released on COMMIT.
        await client.query('SELECT pg_advisory_xact_lock($1)', [SCHEMA_LOCK_KEY]);
        await client.query(SCHEMA_SQL);
        await client.query(
          `INSERT INTO settings (id, data, updated_at)
           VALUES (1, $1::jsonb, now())
           ON CONFLICT (id) DO NOTHING`,
          [JSON.stringify(DEFAULT_SETTINGS)],
        );
        await client.query('COMMIT');
      } catch (err) {
        if (client) {
          try {
            await client.query('ROLLBACK');
          } catch {
            /* connection may already be unusable */
          }
        }
        // Let the next call retry rather than caching a failure forever.
        this.initPromise = null;
        throw err;
      } finally {
        client?.release();
      }
    })();

    return this.initPromise;
  }

  async close(): Promise<void> {
    if (globalForPg.__mailAgentPool) {
      await globalForPg.__mailAgentPool.end();
      globalForPg.__mailAgentPool = undefined;
    }
  }

  // ---- types ----

  async listTypes(opts: { includeInactive?: boolean } = {}): Promise<EmailType[]> {
    const where = opts.includeInactive ? '' : 'WHERE active = TRUE';
    const rows = await this.q(`SELECT * FROM email_types ${where} ORDER BY name ASC`);
    return rows.map(mapType);
  }

  async getType(id: string): Promise<EmailType | null> {
    const rows = await this.q('SELECT * FROM email_types WHERE id = $1', [id]);
    return rows[0] ? mapType(rows[0]) : null;
  }

  async getTypeBySlug(slug: string): Promise<EmailType | null> {
    const rows = await this.q('SELECT * FROM email_types WHERE slug = $1', [slug]);
    return rows[0] ? mapType(rows[0]) : null;
  }

  async createType(input: NewEmailType): Promise<EmailType> {
    const id = newId();
    // Guarantee a unique slug even if the name collides with an existing type.
    const base = slugify(input.slug || input.name);
    let slug = base;
    for (let n = 2; await this.getTypeBySlug(slug); n++) slug = `${base}-${n}`;

    const rows = await this.q(
      `INSERT INTO email_types
         (id, name, slug, description, keywords, reply_subject, reply_body, reply_guidance, active)
       VALUES ($1,$2,$3,$4,$5::jsonb,$6,$7,$8,$9)
       RETURNING *`,
      [
        id,
        input.name,
        slug,
        input.description ?? '',
        JSON.stringify(input.keywords ?? []),
        input.replySubject ?? '',
        input.replyBody ?? '',
        input.replyGuidance ?? '',
        input.active ?? true,
      ],
    );
    return mapType(rows[0]);
  }

  async updateType(id: string, patch: Partial<NewEmailType>): Promise<EmailType> {
    const sets: string[] = [];
    const params: unknown[] = [];
    const push = (col: string, value: unknown, cast = '') => {
      params.push(value);
      sets.push(`${col} = $${params.length}${cast}`);
    };

    if (patch.name !== undefined) push('name', patch.name);
    if (patch.slug !== undefined) push('slug', slugify(patch.slug));
    if (patch.description !== undefined) push('description', patch.description);
    if (patch.keywords !== undefined) push('keywords', JSON.stringify(patch.keywords), '::jsonb');
    if (patch.replySubject !== undefined) push('reply_subject', patch.replySubject);
    if (patch.replyBody !== undefined) push('reply_body', patch.replyBody);
    if (patch.replyGuidance !== undefined) push('reply_guidance', patch.replyGuidance);
    if (patch.active !== undefined) push('active', patch.active);

    if (!sets.length) {
      const existing = await this.getType(id);
      if (!existing) throw new Error(`Email type ${id} not found`);
      return existing;
    }

    sets.push('updated_at = now()');
    params.push(id);
    const rows = await this.q(
      `UPDATE email_types SET ${sets.join(', ')} WHERE id = $${params.length} RETURNING *`,
      params,
    );
    if (!rows[0]) throw new Error(`Email type ${id} not found`);
    return mapType(rows[0]);
  }

  async deleteType(id: string): Promise<void> {
    await this.q('DELETE FROM email_types WHERE id = $1', [id]);
  }

  // ---- input drafts ----

  async listSamples(typeId?: string): Promise<TypeSample[]> {
    const rows = typeId
      ? await this.q('SELECT * FROM type_samples WHERE type_id = $1 ORDER BY created_at ASC', [typeId])
      : await this.q('SELECT * FROM type_samples ORDER BY created_at ASC');
    return rows.map(mapSample);
  }

  async addSample(input: {
    typeId: string;
    subject: string;
    body: string;
    source?: SampleSource;
  }): Promise<TypeSample> {
    const rows = await this.q(
      `INSERT INTO type_samples (id, type_id, subject, body, source)
       VALUES ($1,$2,$3,$4,$5) RETURNING *`,
      [newId(), input.typeId, input.subject, input.body, input.source ?? 'manual'],
    );
    return mapSample(rows[0]);
  }

  async deleteSample(id: string): Promise<void> {
    await this.q('DELETE FROM type_samples WHERE id = $1', [id]);
  }

  // ---- extra output drafts ----

  async listReplyExamples(typeId?: string): Promise<ReplyExample[]> {
    const rows = typeId
      ? await this.q('SELECT * FROM reply_examples WHERE type_id = $1 ORDER BY created_at ASC', [typeId])
      : await this.q('SELECT * FROM reply_examples ORDER BY created_at ASC');
    return rows.map(mapReplyExample);
  }

  async addReplyExample(input: {
    typeId: string;
    subject: string;
    body: string;
    source?: SampleSource;
  }): Promise<ReplyExample> {
    const rows = await this.q(
      `INSERT INTO reply_examples (id, type_id, subject, body, source)
       VALUES ($1,$2,$3,$4,$5) RETURNING *`,
      [newId(), input.typeId, input.subject, input.body, input.source ?? 'manual'],
    );
    return mapReplyExample(rows[0]);
  }

  async deleteReplyExample(id: string): Promise<void> {
    await this.q('DELETE FROM reply_examples WHERE id = $1', [id]);
  }

  // ---- emails ----

  async createEmail(input: NewEmail): Promise<EmailRecord> {
    const rows = await this.q(
      `INSERT INTO emails
         (id, external_id, from_name, from_email, to_email, subject, body, received_at, source, status)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
       RETURNING *`,
      [
        newId(),
        input.externalId ?? null,
        input.fromName ?? '',
        input.fromEmail,
        input.toEmail ?? '',
        input.subject,
        input.body,
        input.receivedAt ?? nowIso(),
        input.source ?? 'manual',
        input.status ?? 'classified',
      ],
    );
    return mapEmail(rows[0]);
  }

  async getEmail(id: string): Promise<EmailRecord | null> {
    const rows = await this.q('SELECT * FROM emails WHERE id = $1', [id]);
    return rows[0] ? mapEmail(rows[0]) : null;
  }

  async findEmailByExternalId(externalId: string): Promise<EmailRecord | null> {
    if (!externalId) return null;
    const rows = await this.q('SELECT * FROM emails WHERE external_id = $1', [externalId]);
    return rows[0] ? mapEmail(rows[0]) : null;
  }

  /** Shared WHERE builder so list and count can never disagree. */
  private emailFilter(opts: ListEmailsOptions): { sql: string; params: unknown[] } {
    const clauses: string[] = [];
    const params: unknown[] = [];

    if (opts.status) {
      params.push(opts.status);
      clauses.push(`e.status = $${params.length}`);
    }
    if (opts.typeId) {
      params.push(opts.typeId);
      clauses.push(
        `EXISTS (SELECT 1 FROM classifications c
                  WHERE c.email_id = e.id AND c.type_id = $${params.length})`,
      );
    }
    if (opts.search) {
      params.push(`%${opts.search}%`);
      const i = params.length;
      clauses.push(`(e.subject ILIKE $${i} OR e.body ILIKE $${i} OR e.from_email ILIKE $${i})`);
    }

    return { sql: clauses.length ? `WHERE ${clauses.join(' AND ')}` : '', params };
  }

  async listEmails(opts: ListEmailsOptions = {}): Promise<EmailRecord[]> {
    const { sql, params } = this.emailFilter(opts);
    const limit = Math.min(Math.max(opts.limit ?? 50, 1), 500);
    const offset = Math.max(opts.offset ?? 0, 0);
    const rows = await this.q(
      `SELECT e.* FROM emails e ${sql}
       ORDER BY e.created_at DESC
       LIMIT ${limit} OFFSET ${offset}`,
      params,
    );
    return rows.map(mapEmail);
  }

  async countEmails(opts: ListEmailsOptions = {}): Promise<number> {
    const { sql, params } = this.emailFilter(opts);
    const rows = await this.q(`SELECT COUNT(*)::int AS n FROM emails e ${sql}`, params);
    return Number(rows[0]?.n ?? 0);
  }

  async updateEmail(id: string, patch: Partial<Pick<EmailRecord, 'status'>>): Promise<EmailRecord> {
    if (patch.status === undefined) {
      const existing = await this.getEmail(id);
      if (!existing) throw new Error(`Email ${id} not found`);
      return existing;
    }
    const rows = await this.q('UPDATE emails SET status = $1 WHERE id = $2 RETURNING *', [
      patch.status,
      id,
    ]);
    if (!rows[0]) throw new Error(`Email ${id} not found`);
    return mapEmail(rows[0]);
  }

  async deleteEmail(id: string): Promise<void> {
    await this.q('DELETE FROM emails WHERE id = $1', [id]);
  }

  // ---- classifications ----

  async addClassification(input: NewClassification): Promise<Classification> {
    const rows = await this.q(
      `INSERT INTO classifications
         (id, email_id, type_id, confidence, method, reasoning, scores, ai_raw)
       VALUES ($1,$2,$3,$4,$5,$6,$7::jsonb,$8)
       RETURNING *`,
      [
        newId(),
        input.emailId,
        input.typeId,
        input.confidence,
        input.method,
        input.reasoning,
        JSON.stringify(input.scores ?? []),
        input.aiRaw ?? null,
      ],
    );
    return mapClassification(rows[0]);
  }

  async getClassificationForEmail(emailId: string): Promise<Classification | null> {
    const rows = await this.q(
      'SELECT * FROM classifications WHERE email_id = $1 ORDER BY created_at DESC LIMIT 1',
      [emailId],
    );
    return rows[0] ? mapClassification(rows[0]) : null;
  }

  // ---- drafts ----

  async addDraft(input: NewDraft): Promise<Draft> {
    const rows = await this.q(
      `INSERT INTO drafts
         (id, email_id, type_id, subject, body, generated_by, unresolved_placeholders, status)
       VALUES ($1,$2,$3,$4,$5,$6,$7::jsonb,$8)
       RETURNING *`,
      [
        newId(),
        input.emailId,
        input.typeId,
        input.subject,
        input.body,
        input.generatedBy,
        JSON.stringify(input.unresolvedPlaceholders ?? []),
        input.status ?? 'draft',
      ],
    );
    return mapDraft(rows[0]);
  }

  async getDraft(id: string): Promise<Draft | null> {
    const rows = await this.q('SELECT * FROM drafts WHERE id = $1', [id]);
    return rows[0] ? mapDraft(rows[0]) : null;
  }

  async getDraftForEmail(emailId: string): Promise<Draft | null> {
    const rows = await this.q(
      'SELECT * FROM drafts WHERE email_id = $1 ORDER BY created_at DESC LIMIT 1',
      [emailId],
    );
    return rows[0] ? mapDraft(rows[0]) : null;
  }

  async updateDraft(
    id: string,
    patch: Partial<
      Pick<Draft, 'subject' | 'body' | 'status' | 'sentAt' | 'sendError' | 'unresolvedPlaceholders'>
    >,
  ): Promise<Draft> {
    const sets: string[] = [];
    const params: unknown[] = [];
    const push = (col: string, value: unknown, cast = '') => {
      params.push(value);
      sets.push(`${col} = $${params.length}${cast}`);
    };

    if (patch.subject !== undefined) push('subject', patch.subject);
    if (patch.body !== undefined) push('body', patch.body);
    if (patch.status !== undefined) push('status', patch.status);
    if (patch.sentAt !== undefined) push('sent_at', patch.sentAt);
    if (patch.sendError !== undefined) push('send_error', patch.sendError);
    if (patch.unresolvedPlaceholders !== undefined) {
      push('unresolved_placeholders', JSON.stringify(patch.unresolvedPlaceholders), '::jsonb');
    }

    if (!sets.length) {
      const existing = await this.getDraft(id);
      if (!existing) throw new Error(`Draft ${id} not found`);
      return existing;
    }

    sets.push('updated_at = now()');
    params.push(id);
    const rows = await this.q(
      `UPDATE drafts SET ${sets.join(', ')} WHERE id = $${params.length} RETURNING *`,
      params,
    );
    if (!rows[0]) throw new Error(`Draft ${id} not found`);
    return mapDraft(rows[0]);
  }

  // ---- review queue ----

  async addReview(input: NewReviewItem): Promise<ReviewItem> {
    const rows = await this.q(
      `INSERT INTO review_items (id, email_id, reason, top_scores, status)
       VALUES ($1,$2,$3,$4::jsonb,'open') RETURNING *`,
      [newId(), input.emailId, input.reason, JSON.stringify(input.topScores ?? [])],
    );
    return mapReview(rows[0]);
  }

  async getReview(id: string): Promise<ReviewItem | null> {
    const rows = await this.q('SELECT * FROM review_items WHERE id = $1', [id]);
    return rows[0] ? mapReview(rows[0]) : null;
  }

  async getReviewForEmail(emailId: string): Promise<ReviewItem | null> {
    const rows = await this.q(
      'SELECT * FROM review_items WHERE email_id = $1 ORDER BY created_at DESC LIMIT 1',
      [emailId],
    );
    return rows[0] ? mapReview(rows[0]) : null;
  }

  async listReviews(status?: ReviewStatus): Promise<ReviewItem[]> {
    const rows = status
      ? await this.q('SELECT * FROM review_items WHERE status = $1 ORDER BY created_at DESC', [status])
      : await this.q('SELECT * FROM review_items ORDER BY created_at DESC');
    return rows.map(mapReview);
  }

  async updateReview(id: string, patch: Partial<ReviewItem>): Promise<ReviewItem> {
    const sets: string[] = [];
    const params: unknown[] = [];
    const push = (col: string, value: unknown, cast = '') => {
      params.push(value);
      sets.push(`${col} = $${params.length}${cast}`);
    };

    if (patch.reason !== undefined) push('reason', patch.reason);
    if (patch.topScores !== undefined) push('top_scores', JSON.stringify(patch.topScores), '::jsonb');
    if (patch.status !== undefined) push('status', patch.status);
    if (patch.alertSentAt !== undefined) push('alert_sent_at', patch.alertSentAt);
    if (patch.alertError !== undefined) push('alert_error', patch.alertError);
    if (patch.resolution !== undefined) push('resolution', patch.resolution);
    if (patch.resolvedTypeId !== undefined) push('resolved_type_id', patch.resolvedTypeId);
    if (patch.resolvedBy !== undefined) push('resolved_by', patch.resolvedBy);
    if (patch.resolutionNotes !== undefined) push('resolution_notes', patch.resolutionNotes);
    if (patch.resolvedAt !== undefined) push('resolved_at', patch.resolvedAt);

    if (!sets.length) {
      const existing = await this.getReview(id);
      if (!existing) throw new Error(`Review item ${id} not found`);
      return existing;
    }

    params.push(id);
    const rows = await this.q(
      `UPDATE review_items SET ${sets.join(', ')} WHERE id = $${params.length} RETURNING *`,
      params,
    );
    if (!rows[0]) throw new Error(`Review item ${id} not found`);
    return mapReview(rows[0]);
  }

  // ---- settings ----

  async getSettings(): Promise<Settings> {
    const rows = await this.q('SELECT data, updated_at FROM settings WHERE id = 1');
    if (!rows[0]) return { ...DEFAULT_SETTINGS, updatedAt: nowIso() };
    const data =
      typeof rows[0].data === 'string' ? JSON.parse(rows[0].data) : (rows[0].data as object);
    return { ...DEFAULT_SETTINGS, ...data, updatedAt: iso(rows[0].updated_at) };
  }

  async saveSettings(patch: Partial<Settings>): Promise<Settings> {
    const current = await this.getSettings();
    const { updatedAt: _ignored, ...rest } = { ...current, ...patch };
    const rows = await this.q(
      `INSERT INTO settings (id, data, updated_at) VALUES (1, $1::jsonb, now())
       ON CONFLICT (id) DO UPDATE SET data = $1::jsonb, updated_at = now()
       RETURNING data, updated_at`,
      [JSON.stringify(rest)],
    );
    const data =
      typeof rows[0].data === 'string' ? JSON.parse(rows[0].data) : (rows[0].data as object);
    return { ...DEFAULT_SETTINGS, ...data, updatedAt: iso(rows[0].updated_at) };
  }

  // ---- log ----

  async log(kind: string, message: string, meta?: Record<string, unknown>): Promise<void> {
    try {
      await this.q('INSERT INTO activity_log (id, kind, message, meta) VALUES ($1,$2,$3,$4::jsonb)', [
        newId(),
        kind,
        message,
        meta ? JSON.stringify(meta) : null,
      ]);
    } catch (err) {
      // Logging must never break the request it is describing.
      console.error('[log] failed:', (err as Error).message);
    }
  }

  async listLog(limit = 50): Promise<LogEntry[]> {
    const n = Math.min(Math.max(limit, 1), 500);
    const rows = await this.q(`SELECT * FROM activity_log ORDER BY at DESC LIMIT ${n}`);
    return rows.map((r) => ({
      id: r.id,
      at: iso(r.at),
      kind: r.kind,
      message: r.message,
      meta: (r.meta ?? null) as Record<string, unknown> | null,
    }));
  }

  // ---- dashboard ----

  async stats(): Promise<Stats> {
    const [emailCounts, typeCount, sampleCounts, sentCount, perType] = await Promise.all([
      this.q(`SELECT status, COUNT(*)::int AS n FROM emails GROUP BY status`),
      this.q(`SELECT COUNT(*)::int AS n FROM email_types WHERE active = TRUE`),
      this.q(
        `SELECT COUNT(*)::int AS total,
                COUNT(*) FILTER (WHERE source = 'human_review')::int AS learned
         FROM type_samples`,
      ),
      this.q(`SELECT COUNT(*)::int AS n FROM drafts WHERE status = 'sent'`),
      this.q(
        `SELECT t.id, t.name, COUNT(c.id)::int AS n
         FROM email_types t
         LEFT JOIN classifications c ON c.type_id = t.id
         GROUP BY t.id, t.name
         ORDER BY n DESC, t.name ASC`,
      ),
    ]);

    const byStatus = new Map(emailCounts.map((r) => [r.status as string, Number(r.n)]));
    const total = [...byStatus.values()].reduce((a, b) => a + b, 0);

    return {
      totalEmails: total,
      classified: byStatus.get('classified') ?? 0,
      flaggedOpen: byStatus.get('flagged') ?? 0,
      resolved: byStatus.get('resolved') ?? 0,
      typeCount: Number(typeCount[0]?.n ?? 0),
      sampleCount: Number(sampleCounts[0]?.total ?? 0),
      learnedSampleCount: Number(sampleCounts[0]?.learned ?? 0),
      draftsSent: Number(sentCount[0]?.n ?? 0),
      perType: perType.map((r) => ({ typeId: r.id, typeName: r.name, count: Number(r.n) })),
    };
  }

  async reset(): Promise<void> {
    await this.init();
    // CASCADE clears dependants; email_types is last because others reference it.
    await this.q(
      `TRUNCATE activity_log, review_items, drafts, classifications, emails,
                reply_examples, type_samples, email_types CASCADE`,
    );
    await this.q('DELETE FROM settings WHERE id = 1');
    await this.q(`INSERT INTO settings (id, data, updated_at) VALUES (1, $1::jsonb, now())`, [
      JSON.stringify(DEFAULT_SETTINGS),
    ]);
  }
}
