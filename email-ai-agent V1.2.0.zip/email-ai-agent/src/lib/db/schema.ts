/**
 * Postgres schema. Every statement is idempotent (`IF NOT EXISTS`) so this can
 * run on every cold start without harm. It is wrapped in an advisory lock by the
 * caller so two concurrent serverless invocations cannot race each other.
 */
export const SCHEMA_SQL = `
CREATE TABLE IF NOT EXISTS email_types (
  id              TEXT PRIMARY KEY,
  name            TEXT NOT NULL,
  slug            TEXT NOT NULL UNIQUE,
  description     TEXT NOT NULL DEFAULT '',
  keywords        JSONB NOT NULL DEFAULT '[]'::jsonb,
  reply_subject   TEXT NOT NULL DEFAULT '',
  reply_body      TEXT NOT NULL DEFAULT '',
  reply_guidance  TEXT NOT NULL DEFAULT '',
  active          BOOLEAN NOT NULL DEFAULT TRUE,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS type_samples (
  id         TEXT PRIMARY KEY,
  type_id    TEXT NOT NULL REFERENCES email_types(id) ON DELETE CASCADE,
  subject    TEXT NOT NULL DEFAULT '',
  body       TEXT NOT NULL DEFAULT '',
  source     TEXT NOT NULL DEFAULT 'manual',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS type_samples_type_idx ON type_samples(type_id);

CREATE TABLE IF NOT EXISTS reply_examples (
  id         TEXT PRIMARY KEY,
  type_id    TEXT NOT NULL REFERENCES email_types(id) ON DELETE CASCADE,
  subject    TEXT NOT NULL DEFAULT '',
  body       TEXT NOT NULL DEFAULT '',
  source     TEXT NOT NULL DEFAULT 'manual',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS reply_examples_type_idx ON reply_examples(type_id);

CREATE TABLE IF NOT EXISTS emails (
  id          TEXT PRIMARY KEY,
  external_id TEXT,
  from_name   TEXT NOT NULL DEFAULT '',
  from_email  TEXT NOT NULL DEFAULT '',
  to_email    TEXT NOT NULL DEFAULT '',
  subject     TEXT NOT NULL DEFAULT '',
  body        TEXT NOT NULL DEFAULT '',
  received_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  source      TEXT NOT NULL DEFAULT 'manual',
  status      TEXT NOT NULL DEFAULT 'classified',
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS emails_external_id_idx
  ON emails(external_id) WHERE external_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS emails_status_idx  ON emails(status);
CREATE INDEX IF NOT EXISTS emails_created_idx ON emails(created_at DESC);

CREATE TABLE IF NOT EXISTS classifications (
  id         TEXT PRIMARY KEY,
  email_id   TEXT NOT NULL REFERENCES emails(id) ON DELETE CASCADE,
  type_id    TEXT REFERENCES email_types(id) ON DELETE SET NULL,
  confidence DOUBLE PRECISION NOT NULL DEFAULT 0,
  method     TEXT NOT NULL DEFAULT 'heuristic',
  reasoning  TEXT NOT NULL DEFAULT '',
  scores     JSONB NOT NULL DEFAULT '[]'::jsonb,
  ai_raw     TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS classifications_email_idx
  ON classifications(email_id, created_at DESC);

CREATE TABLE IF NOT EXISTS drafts (
  id                      TEXT PRIMARY KEY,
  email_id                TEXT NOT NULL REFERENCES emails(id) ON DELETE CASCADE,
  type_id                 TEXT REFERENCES email_types(id) ON DELETE SET NULL,
  subject                 TEXT NOT NULL DEFAULT '',
  body                    TEXT NOT NULL DEFAULT '',
  generated_by            TEXT NOT NULL DEFAULT '',
  unresolved_placeholders JSONB NOT NULL DEFAULT '[]'::jsonb,
  status                  TEXT NOT NULL DEFAULT 'draft',
  sent_at                 TIMESTAMPTZ,
  send_error              TEXT,
  created_at              TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at              TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS drafts_email_idx ON drafts(email_id, created_at DESC);

CREATE TABLE IF NOT EXISTS review_items (
  id               TEXT PRIMARY KEY,
  email_id         TEXT NOT NULL REFERENCES emails(id) ON DELETE CASCADE,
  reason           TEXT NOT NULL DEFAULT '',
  top_scores       JSONB NOT NULL DEFAULT '[]'::jsonb,
  status           TEXT NOT NULL DEFAULT 'open',
  alert_sent_at    TIMESTAMPTZ,
  alert_error      TEXT,
  resolution       TEXT,
  resolved_type_id TEXT REFERENCES email_types(id) ON DELETE SET NULL,
  resolved_by      TEXT,
  resolution_notes TEXT NOT NULL DEFAULT '',
  resolved_at      TIMESTAMPTZ,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS review_status_idx ON review_items(status, created_at DESC);
CREATE INDEX IF NOT EXISTS review_email_idx  ON review_items(email_id);

CREATE TABLE IF NOT EXISTS settings (
  id         INT PRIMARY KEY,
  data       JSONB NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT settings_single_row CHECK (id = 1)
);

CREATE TABLE IF NOT EXISTS activity_log (
  id      TEXT PRIMARY KEY,
  at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  kind    TEXT NOT NULL,
  message TEXT NOT NULL,
  meta    JSONB
);
CREATE INDEX IF NOT EXISTS activity_log_at_idx ON activity_log(at DESC);
`;
