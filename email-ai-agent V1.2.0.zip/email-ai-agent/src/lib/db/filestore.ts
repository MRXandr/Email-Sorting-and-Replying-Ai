import { mkdir, readFile, rename, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { DEFAULT_SETTINGS, type ListEmailsOptions, type Store } from './store';
import type {
  Classification,
  Draft,
  EmailRecord,
  EmailType,
  LogEntry,
  NewClassification,
  NewDraft,
  NewEmail,
  NewEmailType,
  NewReviewItem,
  ReplyExample,
  ReviewItem,
  ReviewStatus,
  SampleSource,
  Settings,
  Stats,
  TypeSample,
} from '../types';
import { newId, nowIso, slugify } from '../util';

interface FileData {
  version: number;
  types: EmailType[];
  samples: TypeSample[];
  replyExamples: ReplyExample[];
  emails: EmailRecord[];
  classifications: Classification[];
  drafts: Draft[];
  reviews: ReviewItem[];
  settings: Settings;
  log: LogEntry[];
}

function emptyData(): FileData {
  return {
    version: 1,
    types: [],
    samples: [],
    replyExamples: [],
    emails: [],
    classifications: [],
    drafts: [],
    reviews: [],
    settings: { ...DEFAULT_SETTINGS, updatedAt: nowIso() },
    log: [],
  };
}

function clone<T>(value: T): T {
  return structuredClone(value);
}

/**
 * Error codes that mean "a directory cannot be created here", so the store
 * should fall back to a writable temporary location.
 *
 * ENOENT belongs in this list despite looking like a plain missing-path error.
 * `mkdir` with `recursive: true` creates any missing parents, so ENOENT means
 * the filesystem refused the write rather than that a parent was absent, and
 * read-only container filesystems report it exactly this way.
 *
 * Leaving ENOENT out was a real bug: a deployment to a serverless host failed
 * with a bare `ENOENT: no such file or directory, mkdir '/var/task/.data'`
 * instead of falling back and explaining what to do. Exported so the test suite
 * can pin the list down.
 */
export const UNWRITABLE_DIR_CODES = ['EROFS', 'EACCES', 'EPERM', 'ENOENT'] as const;

export function isUnwritableDirError(err: unknown): boolean {
  const code = (err as NodeJS.ErrnoException)?.code;
  return (UNWRITABLE_DIR_CODES as readonly string[]).includes(code ?? '');
}

/** Ascending by timestamp. Array#sort is stable, so ties keep insertion order. */
function byAsc<T extends { createdAt: string }>(rows: T[]): T[] {
  return [...rows].sort((a, b) => a.createdAt.localeCompare(b.createdAt));
}

/** Descending by timestamp, with ties in reverse-insertion order (newest first). */
function byDesc<T extends { createdAt: string }>(rows: T[]): T[] {
  return [...rows].reverse().sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

/**
 * A JSON-file store so the project runs locally with **zero setup** — no
 * database to install before you can see the app work.
 *
 * Do NOT use this in production on a serverless host: each function instance has
 * its own throwaway filesystem, so writes are lost and not shared. `getStore()`
 * warns about this, and `src/lib/config.ts` surfaces it in the UI.
 */
export class FileStore implements Store {
  readonly kind = 'file' as const;
  private file: string;
  private dir: string;
  /** Set once we have had to fall back to a temporary directory. */
  private usingFallbackDir = false;
  /** Serialises all access so two overlapping requests cannot clobber the file. */
  private queue: Promise<unknown> = Promise.resolve();

  constructor(dir: string) {
    this.dir = path.resolve(dir);
    this.file = path.join(this.dir, 'store.json');
  }

  /**
   * Move to a writable temporary directory when the chosen one is read-only.
   *
   * Serverless hosts mount the deployment read-only, so an app deployed without a
   * DATABASE_URL cannot create `.data/` and would otherwise fail every request
   * with an unhelpful EROFS. Switching to the temp directory keeps the app usable
   * so the person can at least see it running and read the warning telling them to
   * add a database — which the dashboard and `/api/health` both show.
   */
  private switchToFallbackDir(cause: NodeJS.ErrnoException): void {
    if (this.usingFallbackDir) throw cause;
    this.usingFallbackDir = true;
    this.dir = path.join(tmpdir(), 'email-ai-agent-data');
    this.file = path.join(this.dir, 'store.json');
    console.warn(
      `[storage] ${this.dir} is being used because the working directory is not writable ` +
        `(${cause.code}). Data here does NOT survive and is not shared between server instances. ` +
        `Set DATABASE_URL to a Postgres connection string for anything real.`,
    );
  }

  private static isReadOnlyError(err: unknown): boolean {
    return isUnwritableDirError(err);
  }

  /** Run `fn` exclusively, whether or not the previous task succeeded. */
  private run<T>(fn: () => Promise<T>): Promise<T> {
    const next = this.queue.then(fn, fn);
    this.queue = next.then(
      () => undefined,
      () => undefined,
    );
    return next;
  }

  private async load(): Promise<FileData> {
    try {
      const raw = await readFile(this.file, 'utf8');
      const parsed = JSON.parse(raw) as Partial<FileData>;
      // Merge over a fresh shape so a file written by an older version still loads.
      const base = emptyData();
      return {
        ...base,
        ...parsed,
        settings: { ...base.settings, ...(parsed.settings ?? {}) },
      };
    } catch (err) {
      const code = (err as NodeJS.ErrnoException).code;
      if (code === 'ENOENT') return emptyData();
      if (err instanceof SyntaxError) {
        throw new Error(
          `The local data file at ${this.file} is corrupted and could not be parsed. ` +
            `Delete it to start fresh, or set DATABASE_URL to use Postgres instead.`,
        );
      }
      throw err;
    }
  }

  /** Write via a temp file + rename so a crash mid-write cannot truncate the store. */
  private async save(data: FileData): Promise<void> {
    const serialised = JSON.stringify(data, null, 2);

    const attempt = async () => {
      await mkdir(this.dir, { recursive: true });
      const tmp = `${this.file}.${process.pid}.tmp`;
      await writeFile(tmp, serialised, 'utf8');
      await rename(tmp, this.file);
    };

    try {
      await attempt();
    } catch (err) {
      if (!FileStore.isReadOnlyError(err)) throw err;
      this.switchToFallbackDir(err as NodeJS.ErrnoException);
      await attempt();
    }
  }

  /** Read-modify-write under the lock. Always re-reads from disk first. */
  private tx<T>(fn: (data: FileData) => T | Promise<T>): Promise<T> {
    return this.run(async () => {
      const data = await this.load();
      const result = await fn(data);
      await this.save(data);
      return result;
    });
  }

  /** Read-only access under the lock. */
  private read<T>(fn: (data: FileData) => T | Promise<T>): Promise<T> {
    return this.run(async () => fn(await this.load()));
  }

  async init(): Promise<void> {
    await this.run(async () => {
      try {
        await mkdir(this.dir, { recursive: true });
      } catch (err) {
        if (!FileStore.isReadOnlyError(err)) throw err;
        this.switchToFallbackDir(err as NodeJS.ErrnoException);
        await mkdir(this.dir, { recursive: true });
      }

      try {
        await readFile(this.file, 'utf8');
      } catch (err) {
        if ((err as NodeJS.ErrnoException).code === 'ENOENT') {
          await this.save(emptyData());
        }
      }
    });
  }

  async close(): Promise<void> {
    await this.queue.catch(() => undefined);
  }

  // ---- types ----

  async listTypes(opts: { includeInactive?: boolean } = {}): Promise<EmailType[]> {
    return this.read((d) =>
      clone(
        d.types
          .filter((t) => opts.includeInactive || t.active)
          .sort((a, b) => a.name.localeCompare(b.name)),
      ),
    );
  }

  async getType(id: string): Promise<EmailType | null> {
    return this.read((d) => clone(d.types.find((t) => t.id === id) ?? null));
  }

  async getTypeBySlug(slug: string): Promise<EmailType | null> {
    return this.read((d) => clone(d.types.find((t) => t.slug === slug) ?? null));
  }

  async createType(input: NewEmailType): Promise<EmailType> {
    return this.tx((d) => {
      const base = slugify(input.slug || input.name);
      let slug = base;
      for (let n = 2; d.types.some((t) => t.slug === slug); n++) slug = `${base}-${n}`;

      const at = nowIso();
      const type: EmailType = {
        id: newId(),
        name: input.name,
        slug,
        description: input.description ?? '',
        keywords: input.keywords ?? [],
        replySubject: input.replySubject ?? '',
        replyBody: input.replyBody ?? '',
        replyGuidance: input.replyGuidance ?? '',
        active: input.active ?? true,
        createdAt: at,
        updatedAt: at,
      };
      d.types.push(type);
      return clone(type);
    });
  }

  async updateType(id: string, patch: Partial<NewEmailType>): Promise<EmailType> {
    return this.tx((d) => {
      const type = d.types.find((t) => t.id === id);
      if (!type) throw new Error(`Email type ${id} not found`);

      if (patch.name !== undefined) type.name = patch.name;
      if (patch.slug !== undefined) type.slug = slugify(patch.slug);
      if (patch.description !== undefined) type.description = patch.description;
      if (patch.keywords !== undefined) type.keywords = patch.keywords;
      if (patch.replySubject !== undefined) type.replySubject = patch.replySubject;
      if (patch.replyBody !== undefined) type.replyBody = patch.replyBody;
      if (patch.replyGuidance !== undefined) type.replyGuidance = patch.replyGuidance;
      if (patch.active !== undefined) type.active = patch.active;
      type.updatedAt = nowIso();

      return clone(type);
    });
  }

  async deleteType(id: string): Promise<void> {
    await this.tx((d) => {
      d.types = d.types.filter((t) => t.id !== id);
      // Mirror ON DELETE CASCADE / SET NULL from the Postgres schema.
      d.samples = d.samples.filter((s) => s.typeId !== id);
      d.replyExamples = d.replyExamples.filter((s) => s.typeId !== id);
      for (const c of d.classifications) if (c.typeId === id) c.typeId = null;
      for (const dr of d.drafts) if (dr.typeId === id) dr.typeId = null;
      for (const r of d.reviews) if (r.resolvedTypeId === id) r.resolvedTypeId = null;
    });
  }

  // ---- input drafts ----

  async listSamples(typeId?: string): Promise<TypeSample[]> {
    return this.read((d) =>
      clone(byAsc(typeId ? d.samples.filter((s) => s.typeId === typeId) : d.samples)),
    );
  }

  async addSample(input: {
    typeId: string;
    subject: string;
    body: string;
    source?: SampleSource;
  }): Promise<TypeSample> {
    return this.tx((d) => {
      const sample: TypeSample = {
        id: newId(),
        typeId: input.typeId,
        subject: input.subject,
        body: input.body,
        source: input.source ?? 'manual',
        createdAt: nowIso(),
      };
      d.samples.push(sample);
      return clone(sample);
    });
  }

  async deleteSample(id: string): Promise<void> {
    await this.tx((d) => {
      d.samples = d.samples.filter((s) => s.id !== id);
    });
  }

  // ---- extra output drafts ----

  async listReplyExamples(typeId?: string): Promise<ReplyExample[]> {
    return this.read((d) =>
      clone(byAsc(typeId ? d.replyExamples.filter((s) => s.typeId === typeId) : d.replyExamples)),
    );
  }

  async addReplyExample(input: {
    typeId: string;
    subject: string;
    body: string;
    source?: SampleSource;
  }): Promise<ReplyExample> {
    return this.tx((d) => {
      const example: ReplyExample = {
        id: newId(),
        typeId: input.typeId,
        subject: input.subject,
        body: input.body,
        source: input.source ?? 'manual',
        createdAt: nowIso(),
      };
      d.replyExamples.push(example);
      return clone(example);
    });
  }

  async deleteReplyExample(id: string): Promise<void> {
    await this.tx((d) => {
      d.replyExamples = d.replyExamples.filter((s) => s.id !== id);
    });
  }

  // ---- emails ----

  async createEmail(input: NewEmail): Promise<EmailRecord> {
    return this.tx((d) => {
      const externalId = input.externalId ?? null;
      if (externalId && d.emails.some((e) => e.externalId === externalId)) {
        // Mirrors the partial unique index in Postgres.
        throw Object.assign(new Error(`Email with external id ${externalId} already exists`), {
          code: 'DUPLICATE_EXTERNAL_ID',
        });
      }
      const email: EmailRecord = {
        id: newId(),
        externalId,
        fromName: input.fromName ?? '',
        fromEmail: input.fromEmail,
        toEmail: input.toEmail ?? '',
        subject: input.subject,
        body: input.body,
        receivedAt: input.receivedAt ?? nowIso(),
        source: input.source ?? 'manual',
        status: input.status ?? 'classified',
        createdAt: nowIso(),
      };
      d.emails.push(email);
      return clone(email);
    });
  }

  async getEmail(id: string): Promise<EmailRecord | null> {
    return this.read((d) => clone(d.emails.find((e) => e.id === id) ?? null));
  }

  async findEmailByExternalId(externalId: string): Promise<EmailRecord | null> {
    if (!externalId) return null;
    return this.read((d) => clone(d.emails.find((e) => e.externalId === externalId) ?? null));
  }

  private filterEmails(d: FileData, opts: ListEmailsOptions): EmailRecord[] {
    let rows = d.emails;

    if (opts.status) rows = rows.filter((e) => e.status === opts.status);

    if (opts.typeId) {
      const ids = new Set(
        d.classifications.filter((c) => c.typeId === opts.typeId).map((c) => c.emailId),
      );
      rows = rows.filter((e) => ids.has(e.id));
    }

    if (opts.search) {
      const needle = opts.search.toLowerCase();
      rows = rows.filter(
        (e) =>
          e.subject.toLowerCase().includes(needle) ||
          e.body.toLowerCase().includes(needle) ||
          e.fromEmail.toLowerCase().includes(needle),
      );
    }

    return rows;
  }

  async listEmails(opts: ListEmailsOptions = {}): Promise<EmailRecord[]> {
    return this.read((d) => {
      const limit = Math.min(Math.max(opts.limit ?? 50, 1), 500);
      const offset = Math.max(opts.offset ?? 0, 0);
      return clone(byDesc(this.filterEmails(d, opts)).slice(offset, offset + limit));
    });
  }

  async countEmails(opts: ListEmailsOptions = {}): Promise<number> {
    return this.read((d) => this.filterEmails(d, opts).length);
  }

  async updateEmail(id: string, patch: Partial<Pick<EmailRecord, 'status'>>): Promise<EmailRecord> {
    return this.tx((d) => {
      const email = d.emails.find((e) => e.id === id);
      if (!email) throw new Error(`Email ${id} not found`);
      if (patch.status !== undefined) email.status = patch.status;
      return clone(email);
    });
  }

  async deleteEmail(id: string): Promise<void> {
    await this.tx((d) => {
      d.emails = d.emails.filter((e) => e.id !== id);
      d.classifications = d.classifications.filter((c) => c.emailId !== id);
      d.drafts = d.drafts.filter((x) => x.emailId !== id);
      d.reviews = d.reviews.filter((r) => r.emailId !== id);
    });
  }

  // ---- classifications ----

  async addClassification(input: NewClassification): Promise<Classification> {
    return this.tx((d) => {
      const row: Classification = {
        id: newId(),
        emailId: input.emailId,
        typeId: input.typeId,
        confidence: input.confidence,
        method: input.method,
        reasoning: input.reasoning,
        scores: input.scores ?? [],
        aiRaw: input.aiRaw ?? null,
        createdAt: nowIso(),
      };
      d.classifications.push(row);
      return clone(row);
    });
  }

  async getClassificationForEmail(emailId: string): Promise<Classification | null> {
    return this.read(
      (d) => clone(byDesc(d.classifications.filter((c) => c.emailId === emailId))[0] ?? null),
    );
  }

  // ---- drafts ----

  async addDraft(input: NewDraft): Promise<Draft> {
    return this.tx((d) => {
      const at = nowIso();
      const row: Draft = {
        id: newId(),
        emailId: input.emailId,
        typeId: input.typeId,
        subject: input.subject,
        body: input.body,
        generatedBy: input.generatedBy,
        unresolvedPlaceholders: input.unresolvedPlaceholders ?? [],
        status: input.status ?? 'draft',
        sentAt: null,
        sendError: null,
        createdAt: at,
        updatedAt: at,
      };
      d.drafts.push(row);
      return clone(row);
    });
  }

  async getDraft(id: string): Promise<Draft | null> {
    return this.read((d) => clone(d.drafts.find((x) => x.id === id) ?? null));
  }

  async getDraftForEmail(emailId: string): Promise<Draft | null> {
    return this.read((d) => clone(byDesc(d.drafts.filter((x) => x.emailId === emailId))[0] ?? null));
  }

  async updateDraft(
    id: string,
    patch: Partial<
      Pick<Draft, 'subject' | 'body' | 'status' | 'sentAt' | 'sendError' | 'unresolvedPlaceholders'>
    >,
  ): Promise<Draft> {
    return this.tx((d) => {
      const row = d.drafts.find((x) => x.id === id);
      if (!row) throw new Error(`Draft ${id} not found`);
      if (patch.subject !== undefined) row.subject = patch.subject;
      if (patch.body !== undefined) row.body = patch.body;
      if (patch.status !== undefined) row.status = patch.status;
      if (patch.sentAt !== undefined) row.sentAt = patch.sentAt;
      if (patch.sendError !== undefined) row.sendError = patch.sendError;
      if (patch.unresolvedPlaceholders !== undefined) {
        row.unresolvedPlaceholders = patch.unresolvedPlaceholders;
      }
      row.updatedAt = nowIso();
      return clone(row);
    });
  }

  // ---- review queue ----

  async addReview(input: NewReviewItem): Promise<ReviewItem> {
    return this.tx((d) => {
      const row: ReviewItem = {
        id: newId(),
        emailId: input.emailId,
        reason: input.reason,
        topScores: input.topScores ?? [],
        status: 'open',
        alertSentAt: null,
        alertError: null,
        resolution: null,
        resolvedTypeId: null,
        resolvedBy: null,
        resolutionNotes: '',
        resolvedAt: null,
        createdAt: nowIso(),
      };
      d.reviews.push(row);
      return clone(row);
    });
  }

  async getReview(id: string): Promise<ReviewItem | null> {
    return this.read((d) => clone(d.reviews.find((r) => r.id === id) ?? null));
  }

  async getReviewForEmail(emailId: string): Promise<ReviewItem | null> {
    return this.read((d) => clone(byDesc(d.reviews.filter((r) => r.emailId === emailId))[0] ?? null));
  }

  async listReviews(status?: ReviewStatus): Promise<ReviewItem[]> {
    return this.read((d) =>
      clone(byDesc(status ? d.reviews.filter((r) => r.status === status) : d.reviews)),
    );
  }

  async updateReview(id: string, patch: Partial<ReviewItem>): Promise<ReviewItem> {
    return this.tx((d) => {
      const row = d.reviews.find((r) => r.id === id);
      if (!row) throw new Error(`Review item ${id} not found`);

      if (patch.reason !== undefined) row.reason = patch.reason;
      if (patch.topScores !== undefined) row.topScores = patch.topScores;
      if (patch.status !== undefined) row.status = patch.status;
      if (patch.alertSentAt !== undefined) row.alertSentAt = patch.alertSentAt;
      if (patch.alertError !== undefined) row.alertError = patch.alertError;
      if (patch.resolution !== undefined) row.resolution = patch.resolution;
      if (patch.resolvedTypeId !== undefined) row.resolvedTypeId = patch.resolvedTypeId;
      if (patch.resolvedBy !== undefined) row.resolvedBy = patch.resolvedBy;
      if (patch.resolutionNotes !== undefined) row.resolutionNotes = patch.resolutionNotes;
      if (patch.resolvedAt !== undefined) row.resolvedAt = patch.resolvedAt;

      return clone(row);
    });
  }

  // ---- settings ----

  async getSettings(): Promise<Settings> {
    return this.read((d) => clone(d.settings));
  }

  async saveSettings(patch: Partial<Settings>): Promise<Settings> {
    return this.tx((d) => {
      d.settings = { ...d.settings, ...patch, updatedAt: nowIso() };
      return clone(d.settings);
    });
  }

  // ---- log ----

  async log(kind: string, message: string, meta?: Record<string, unknown>): Promise<void> {
    try {
      await this.tx((d) => {
        d.log.push({ id: newId(), at: nowIso(), kind, message, meta: meta ?? null });
        // Keep the file from growing without bound.
        if (d.log.length > 1000) d.log = d.log.slice(-1000);
      });
    } catch (err) {
      console.error('[log] failed:', (err as Error).message);
    }
  }

  async listLog(limit = 50): Promise<LogEntry[]> {
    const n = Math.min(Math.max(limit, 1), 500);
    return this.read((d) =>
      clone(
        [...d.log]
          .reverse()
          .sort((a, b) => b.at.localeCompare(a.at))
          .slice(0, n),
      ),
    );
  }

  // ---- dashboard ----

  async stats(): Promise<Stats> {
    return this.read((d) => {
      const counts = (status: string) => d.emails.filter((e) => e.status === status).length;
      const perType = d.types
        .map((t) => ({
          typeId: t.id,
          typeName: t.name,
          count: d.classifications.filter((c) => c.typeId === t.id).length,
        }))
        .sort((a, b) => b.count - a.count || a.typeName.localeCompare(b.typeName));

      return {
        totalEmails: d.emails.length,
        classified: counts('classified'),
        flaggedOpen: counts('flagged'),
        resolved: counts('resolved'),
        typeCount: d.types.filter((t) => t.active).length,
        sampleCount: d.samples.length,
        learnedSampleCount: d.samples.filter((s) => s.source === 'human_review').length,
        draftsSent: d.drafts.filter((x) => x.status === 'sent').length,
        perType,
      };
    });
  }

  async reset(): Promise<void> {
    await this.run(async () => {
      await this.save(emptyData());
    });
  }
}
