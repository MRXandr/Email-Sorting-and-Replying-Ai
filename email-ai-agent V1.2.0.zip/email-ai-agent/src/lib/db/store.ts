import type {
  Classification,
  Draft,
  EmailRecord,
  EmailType,
  LogEntry,
  NewClassification,
  NewDraft,
  NewEmail,
  NewEmailType,
  NewReviewItem,
  ReplyExample,
  ReviewItem,
  ReviewStatus,
  SampleSource,
  Settings,
  Stats,
  TypeSample,
} from '../types';

export interface ListEmailsOptions {
  status?: EmailRecord['status'];
  typeId?: string;
  limit?: number;
  offset?: number;
  search?: string;
}

/**
 * The single storage contract. Two implementations satisfy it:
 *
 *   - PostgresStore  (src/lib/db/postgres.ts) — used whenever DATABASE_URL is set.
 *                     This is what runs in production on Neon.
 *   - FileStore      (src/lib/db/filestore.ts) — a JSON file on disk, so the app
 *                     runs locally with zero setup. Not suitable for serverless
 *                     hosting, where the filesystem is ephemeral.
 *
 * Both are exercised by the same test suite so they cannot drift apart.
 */
export interface Store {
  readonly kind: 'postgres' | 'file';

  /** Create tables / data file if missing. Safe to call repeatedly. */
  init(): Promise<void>;
  close(): Promise<void>;

  // ---- email types (categories + their fed output drafts) ----
  listTypes(opts?: { includeInactive?: boolean }): Promise<EmailType[]>;
  getType(id: string): Promise<EmailType | null>;
  getTypeBySlug(slug: string): Promise<EmailType | null>;
  createType(input: NewEmailType): Promise<EmailType>;
  updateType(id: string, patch: Partial<NewEmailType>): Promise<EmailType>;
  deleteType(id: string): Promise<void>;

  // ---- input drafts (example incoming emails per type) ----
  listSamples(typeId?: string): Promise<TypeSample[]>;
  addSample(input: {
    typeId: string;
    subject: string;
    body: string;
    source?: SampleSource;
  }): Promise<TypeSample>;
  deleteSample(id: string): Promise<void>;

  // ---- extra output drafts (example replies per type) ----
  listReplyExamples(typeId?: string): Promise<ReplyExample[]>;
  addReplyExample(input: {
    typeId: string;
    subject: string;
    body: string;
    source?: SampleSource;
  }): Promise<ReplyExample>;
  deleteReplyExample(id: string): Promise<void>;

  // ---- incoming emails ----
  createEmail(input: NewEmail): Promise<EmailRecord>;
  getEmail(id: string): Promise<EmailRecord | null>;
  findEmailByExternalId(externalId: string): Promise<EmailRecord | null>;
  listEmails(opts?: ListEmailsOptions): Promise<EmailRecord[]>;
  countEmails(opts?: ListEmailsOptions): Promise<number>;
  updateEmail(id: string, patch: Partial<Pick<EmailRecord, 'status'>>): Promise<EmailRecord>;
  deleteEmail(id: string): Promise<void>;

  // ---- classifications ----
  addClassification(input: NewClassification): Promise<Classification>;
  getClassificationForEmail(emailId: string): Promise<Classification | null>;

  // ---- drafted replies ----
  addDraft(input: NewDraft): Promise<Draft>;
  getDraft(id: string): Promise<Draft | null>;
  getDraftForEmail(emailId: string): Promise<Draft | null>;
  updateDraft(
    id: string,
    patch: Partial<
      Pick<
        Draft,
        'subject' | 'body' | 'status' | 'sentAt' | 'sendError' | 'unresolvedPlaceholders'
      >
    >,
  ): Promise<Draft>;

  // ---- human review queue ----
  addReview(input: NewReviewItem): Promise<ReviewItem>;
  getReview(id: string): Promise<ReviewItem | null>;
  getReviewForEmail(emailId: string): Promise<ReviewItem | null>;
  listReviews(status?: ReviewStatus): Promise<ReviewItem[]>;
  updateReview(id: string, patch: Partial<ReviewItem>): Promise<ReviewItem>;

  // ---- settings ----
  getSettings(): Promise<Settings>;
  saveSettings(patch: Partial<Settings>): Promise<Settings>;

  // ---- audit log ----
  log(kind: string, message: string, meta?: Record<string, unknown>): Promise<void>;
  listLog(limit?: number): Promise<LogEntry[]>;

  // ---- dashboard ----
  stats(): Promise<Stats>;

  /** Wipe everything. Used by "reset & reseed" and by the test suite. */
  reset(): Promise<void>;
}

export const DEFAULT_SETTINGS: Omit<Settings, 'updatedAt'> = {
  companyName: 'Northwind Retail',
  supportSignature: 'Customer Care Team\nNorthwind Retail',
  reviewTeamEmail: '',
  /** Models are confident when they are right; 0.6 rejects genuine hedging. */
  confidenceThreshold: 0.6,
  /**
   * Calibrated: on the seeded data, known mail scores 0.27-0.55 and unknown mail
   * scores below 0.13. 0.22 sits in that gap with room on both sides.
   * Re-run `npm run calibrate` after changing types or keywords.
   */
  heuristicThreshold: 0.22,
  /** A winner this close to the runner-up is genuinely ambiguous — ask a human. */
  marginThreshold: 0.06,
  autoSendEnabled: false,
};
