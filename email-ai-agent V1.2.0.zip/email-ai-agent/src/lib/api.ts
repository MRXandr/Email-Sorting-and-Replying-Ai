import { NextResponse } from 'next/server';

/**
 * Shared plumbing for the API routes, so every endpoint reports success and
 * failure the same way and no route can crash with an unhandled exception.
 */

/** An error with an HTTP status attached, thrown from anywhere inside a handler. */
export class ApiError extends Error {
  readonly status: number;
  readonly details: unknown;

  constructor(message: string, status = 400, details?: unknown) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.details = details;
  }
}

export function ok<T>(data: T, status = 200): NextResponse {
  return NextResponse.json(data as object, { status });
}

export function fail(message: string, status = 400, details?: unknown): NextResponse {
  return NextResponse.json({ error: message, ...(details ? { details } : {}) }, { status });
}

/**
 * Wrap a route handler so any thrown error becomes a clean JSON response.
 *
 * Without this, one unexpected exception shows the user a blank 500 page with no
 * indication of what went wrong.
 */
export function route<A extends unknown[]>(
  handler: (...args: A) => Promise<NextResponse>,
): (...args: A) => Promise<NextResponse> {
  return async (...args: A) => {
    try {
      return await handler(...args);
    } catch (err) {
      if (err instanceof ApiError) {
        return fail(err.message, err.status, err.details);
      }

      const error = err as Error & { status?: number; code?: string };

      // Errors thrown by the pipeline carry a status for the client.
      if (typeof error.status === 'number') {
        return fail(error.message, error.status);
      }

      // Postgres connection problems are the most common deployment mistake, so
      // they get a specific explanation rather than a generic 500.
      const message = error.message || 'Unknown error';
      if (
        error.code === 'ECONNREFUSED' ||
        error.code === 'ENOTFOUND' ||
        /password authentication failed|no pg_hba|does not exist|SASL|self.signed/i.test(message)
      ) {
        console.error('[api] database error:', message);
        return fail(
          `Could not reach the database: ${message}. Check that DATABASE_URL is correct and ` +
            `that it is the pooled connection string from your database provider.`,
          503,
        );
      }

      console.error('[api] unhandled error:', error.stack || message);
      return fail(message, 500);
    }
  };
}

/** Parse a JSON body, with a clear message when it is missing or malformed. */
export async function readJson<T = Record<string, unknown>>(request: Request): Promise<T> {
  const text = await request.text();
  if (!text.trim()) throw new ApiError('A JSON request body is required.', 400);
  try {
    return JSON.parse(text) as T;
  } catch {
    throw new ApiError('The request body was not valid JSON.', 400);
  }
}

/** Require a non-empty string field. */
export function requireString(value: unknown, field: string, maxLength = 100_000): string {
  if (typeof value !== 'string' || !value.trim()) {
    throw new ApiError(`"${field}" is required.`, 400);
  }
  if (value.length > maxLength) {
    throw new ApiError(`"${field}" is too long (limit ${maxLength} characters).`, 413);
  }
  return value;
}

export function optionalString(value: unknown, field: string, maxLength = 100_000): string | undefined {
  if (value === undefined || value === null) return undefined;
  if (typeof value !== 'string') throw new ApiError(`"${field}" must be text.`, 400);
  if (value.length > maxLength) {
    throw new ApiError(`"${field}" is too long (limit ${maxLength} characters).`, 413);
  }
  return value;
}

/** Accept a keyword list as an array or as a comma/newline separated string. */
export function parseKeywords(value: unknown): string[] | undefined {
  if (value === undefined || value === null) return undefined;

  const list = Array.isArray(value)
    ? value.map((v) => String(v))
    : typeof value === 'string'
      ? value.split(/[,\n]/)
      : null;

  if (!list) throw new ApiError('"keywords" must be a list or a comma-separated string.', 400);

  const cleaned = [...new Set(list.map((k) => k.trim().toLowerCase()).filter(Boolean))];
  if (cleaned.length > 200) throw new ApiError('A type can have at most 200 keywords.', 400);
  return cleaned;
}

export function parseNumber(
  value: unknown,
  field: string,
  { min, max }: { min: number; max: number },
): number | undefined {
  if (value === undefined || value === null || value === '') return undefined;
  const n = Number(value);
  if (!Number.isFinite(n)) throw new ApiError(`"${field}" must be a number.`, 400);
  if (n < min || n > max) throw new ApiError(`"${field}" must be between ${min} and ${max}.`, 400);
  return n;
}

export function parseBoolean(value: unknown, field: string): boolean | undefined {
  if (value === undefined || value === null) return undefined;
  if (typeof value === 'boolean') return value;
  if (value === 'true') return true;
  if (value === 'false') return false;
  throw new ApiError(`"${field}" must be true or false.`, 400);
}
