'use client';

/**
 * The browser's single door to the API.
 *
 * Every page goes through this, so error handling is consistent: a failed request
 * always throws an Error whose message is the server's own explanation, which the
 * pages then show verbatim. That is why the API messages are written for humans.
 */

export class RequestError extends Error {
  readonly status: number;
  readonly details: unknown;

  constructor(message: string, status: number, details?: unknown) {
    super(message);
    this.name = 'RequestError';
    this.status = status;
    this.details = details;
  }
}

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  let response: Response;

  try {
    response = await fetch(path, {
      // Always hit the server: this data changes on every action.
      cache: 'no-store',
      credentials: 'same-origin',
      ...init,
    });
  } catch (err) {
    throw new RequestError(
      `Could not reach the server (${(err as Error).message}). Is it still running?`,
      0,
    );
  }

  // The login redirect would otherwise show up as a confusing JSON parse error.
  if (response.status === 401) {
    throw new RequestError('Your session has expired. Reload the page and sign in again.', 401);
  }

  const text = await response.text();
  let data: unknown = null;
  if (text) {
    try {
      data = JSON.parse(text);
    } catch {
      if (!response.ok) {
        throw new RequestError(
          `The server returned an error (${response.status}) that was not JSON: ${text.slice(0, 300)}`,
          response.status,
        );
      }
    }
  }

  if (!response.ok) {
    const payload = data as { error?: string; details?: unknown } | null;
    throw new RequestError(
      payload?.error || `Request failed with status ${response.status}.`,
      response.status,
      payload?.details,
    );
  }

  return data as T;
}

export function apiGet<T>(path: string): Promise<T> {
  return request<T>(path);
}

export function apiPost<T>(path: string, body?: unknown): Promise<T> {
  return request<T>(path, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body ?? {}),
  });
}

export function apiPatch<T>(path: string, body: unknown): Promise<T> {
  return request<T>(path, {
    method: 'PATCH',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  });
}

export function apiDelete<T>(path: string): Promise<T> {
  return request<T>(path, { method: 'DELETE' });
}

export function apiUpload<T>(path: string, form: FormData): Promise<T> {
  // No content-type header: the browser must set the multipart boundary itself.
  return request<T>(path, { method: 'POST', body: form });
}
