import type { EmailRecord, Settings } from '../types';
import { displayName, firstName } from '../util';

/**
 * Placeholder filling for the fed output drafts.
 *
 * A reply template can contain `{{placeholder}}` tokens. Anything this module can
 * work out from the incoming email or from Settings is substituted. Anything it
 * cannot is deliberately LEFT IN PLACE and reported as unresolved, so the person
 * approving the draft can see exactly what still needs a human decision. Silently
 * inventing a delivery date or a refund amount would be far worse than showing a
 * gap.
 */

/** Placeholders the system knows how to fill, for the UI's help text. */
export const KNOWN_PLACEHOLDERS = [
  'customer_name',
  'customer_first_name',
  'customer_email',
  'subject',
  'order_id',
  'invoice_id',
  'tracking_id',
  'company_name',
  'signature',
  'today',
] as const;

export interface ExtractedEntities {
  orderId: string | null;
  invoiceId: string | null;
  trackingId: string | null;
}

/**
 * Pull reference numbers out of the email text.
 *
 * Kept deliberately conservative: a wrong order number in a reply is worse than
 * no order number, because the customer will act on it. Patterns require an
 * explicit label ("order", "invoice", "tracking") near the number, except for the
 * unambiguous `ABC-12345` form.
 */
export function extractEntities(subject: string, body: string): ExtractedEntities {
  const haystack = `${subject}\n${body}`;

  const firstMatch = (patterns: RegExp[]): string | null => {
    for (const pattern of patterns) {
      // Fresh regex each time so the global flag's lastIndex never leaks between calls.
      const re = new RegExp(pattern.source, pattern.flags.replace('g', ''));
      const m = haystack.match(re);
      if (m?.[1]) return m[1].toUpperCase().replace(/[.,;:]+$/, '');
    }
    return null;
  };

  const orderId = firstMatch([
    // "order 88213", "order no. 88213", "order #88213", "order id: ORD-4019"
    /\border\s*(?:no\.?|number|num|id|#|ref(?:erence)?)?\s*[:#-]?\s*((?:[A-Za-z]{2,5}-)?\d{4,12})\b/i,
    // "ORD-40192" or "SO-9912" appearing on its own
    /\b([A-Za-z]{2,5}-\d{4,12})\b/,
    // "my order is 88213"
    /\border\b[^.\n]{0,20}?\b(\d{5,12})\b/i,
  ]);

  const invoiceId = firstMatch([
    /\binvoice\s*(?:no\.?|number|num|id|#)?\s*[:#-]?\s*((?:[A-Za-z]{2,5}[-/])?\d{3,12})\b/i,
    /\b(?:inv|bill)\s*[:#-]?\s*((?:[A-Za-z]{2,5}-)?\d{3,12})\b/i,
  ]);

  const trackingId = firstMatch([
    /\b(?:tracking|awb|consignment|waybill)\s*(?:no\.?|number|num|id|#)?\s*[:#-]?\s*([A-Za-z0-9]{8,22})\b/i,
  ]);

  return { orderId, invoiceId, trackingId };
}

/** Drop any number of leading Re:/RE:/Fwd: prefixes so replies do not stack them. */
export function stripReplyPrefix(subject: string): string {
  let out = (subject || '').trim();
  let changed = true;
  while (changed) {
    const next = out.replace(/^\s*(re|fw|fwd|aw|sv)\s*(\[\d+\])?\s*:\s*/i, '');
    changed = next !== out;
    out = next;
  }
  return out.trim();
}

/** The values available to `{{placeholder}}` tokens for one email. */
export function buildPlaceholderValues(
  email: Pick<EmailRecord, 'fromName' | 'fromEmail' | 'subject' | 'body'>,
  settings: Settings,
): Record<string, string> {
  const entities = extractEntities(email.subject, email.body);
  const full = displayName(email.fromName, email.fromEmail);

  const values: Record<string, string> = {
    customer_name: full,
    customer_first_name: firstName(full),
    customer_email: email.fromEmail,
    subject: stripReplyPrefix(email.subject) || '(no subject)',
    company_name: settings.companyName,
    signature: settings.supportSignature,
    today: new Date().toISOString().slice(0, 10),
  };

  // Only define these when actually found, so a missing one is reported as
  // unresolved instead of quietly becoming an empty string.
  if (entities.orderId) values.order_id = entities.orderId;
  if (entities.invoiceId) values.invoice_id = entities.invoiceId;
  if (entities.trackingId) values.tracking_id = entities.trackingId;

  return values;
}

const PLACEHOLDER_RE = /\{\{\s*([a-zA-Z0-9_.-]+)\s*\}\}/g;

export interface FillResult {
  text: string;
  /** Placeholder names that had no value and were left in the text. */
  unresolved: string[];
}

/** Substitute every `{{token}}` that has a value; leave the rest visible. */
export function fillTemplate(template: string, values: Record<string, string>): FillResult {
  const unresolved = new Set<string>();

  const text = (template || '').replace(PLACEHOLDER_RE, (match, rawName: string) => {
    const name = rawName.trim();
    const value = values[name] ?? values[name.toLowerCase()];
    if (value === undefined || value === null || value === '') {
      unresolved.add(name);
      return match;
    }
    return value;
  });

  return { text, unresolved: [...unresolved] };
}

/** Find placeholders still present in a finished draft (including AI output). */
export function findPlaceholders(text: string): string[] {
  const found = new Set<string>();
  for (const match of (text || '').matchAll(PLACEHOLDER_RE)) {
    found.add(match[1].trim());
  }
  return [...found];
}
