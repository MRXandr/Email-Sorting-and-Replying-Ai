import { resolveAiProvider } from '../ai';
import { AiError } from '../ai/provider';
import { stripQuotedText } from '../classify/text';
import type { EmailRecord, EmailType, ReplyExample, Settings } from '../types';
import { extractJson, truncate } from '../util';
import {
  buildPlaceholderValues,
  fillTemplate,
  findPlaceholders,
  stripReplyPrefix,
} from './templates';

export interface DraftResult {
  subject: string;
  body: string;
  /** "gemini:gemini-2.0-flash" when the model wrote it, "template" when filled offline. */
  generatedBy: string;
  unresolvedPlaceholders: string[];
  /** Set when an AI provider was configured but the call failed. */
  aiError: string | null;
}

const EMAIL_CHARS = 2600;
const EXAMPLE_CHARS = 1200;

const SYSTEM_PROMPT = `You write customer support replies for a company, on behalf of its support team.

You are given:
  1. An APPROVED REPLY TEMPLATE that the company has written for this exact category of email. This is the company's own wording and it is authoritative.
  2. Optional extra examples of approved replies in the same category.
  3. Any specific guidance for this category.
  4. The actual incoming customer email.
  5. A list of known values (customer name, order number, and so on) already extracted from that email.

Your job is to produce the reply that the template intends, adapted to what this particular customer actually asked.

Rules, in order of importance:

1. NEVER invent facts. Do not state a delivery date, refund amount, tracking number, order number, stock date, or policy figure unless it appears in the template, the guidance, or the customer's own email. This is the most important rule: a fabricated detail in a support reply does real damage.

2. If the template contains a {{placeholder}} you cannot fill from the information given, LEAVE THE {{placeholder}} EXACTLY AS IT IS in your output. A human will fill it in before sending. Do not guess, and do not quietly delete the sentence containing it.

3. Follow the template's structure, tone, and level of formality closely. Keep its paragraphs and any numbered steps. You may reorder or trim a paragraph that is clearly irrelevant to this customer, and you should address anything specific they asked that the template does not cover.

4. Address the customer's actual question. If they asked three things, answer three things. If the template covers only one of them, add a short, careful sentence for the others that commits to finding out rather than inventing an answer.

5. End with the signature exactly as it appears in the template.

6. Write plain text, not HTML or markdown. No bullet characters other than "-" and numbered lists as "1." style.

Respond with a single JSON object in exactly this shape:
{
  "subject": "<the reply subject line>",
  "body": "<the full reply body as plain text, with real newlines>"
}`;

function buildPrompt(
  email: Pick<EmailRecord, 'fromName' | 'fromEmail' | 'subject' | 'body'>,
  type: EmailType,
  replyExamples: ReplyExample[],
  values: Record<string, string>,
  filledSubject: string,
  filledBody: string,
  settings: Settings,
): string {
  const parts: string[] = [];

  parts.push(`COMPANY: ${settings.companyName}`);
  parts.push(`EMAIL CATEGORY: ${type.name}`);
  if (type.description) parts.push(`WHAT THIS CATEGORY COVERS: ${type.description}`);
  if (type.replyGuidance) parts.push(`GUIDANCE FOR THIS CATEGORY: ${type.replyGuidance}`);

  parts.push('');
  parts.push('APPROVED REPLY TEMPLATE — subject line:');
  parts.push(type.replySubject || 'Re: {{subject}}');
  parts.push('');
  parts.push('APPROVED REPLY TEMPLATE — body:');
  parts.push(type.replyBody || '(no template body has been set for this category)');

  if (replyExamples.length) {
    parts.push('');
    parts.push('ADDITIONAL APPROVED REPLY EXAMPLES IN THIS CATEGORY:');
    replyExamples.slice(0, 2).forEach((example, i) => {
      parts.push(`Example ${i + 1} subject: ${truncate(example.subject, 160)}`);
      parts.push(`Example ${i + 1} body: ${truncate(example.body, EXAMPLE_CHARS)}`);
    });
  }

  parts.push('');
  parts.push('THE SAME TEMPLATE WITH KNOWN VALUES ALREADY SUBSTITUTED (use this as your base):');
  parts.push(`Subject: ${filledSubject}`);
  parts.push('Body:');
  parts.push(filledBody);

  parts.push('');
  parts.push('KNOWN VALUES EXTRACTED FROM THIS EMAIL:');
  const shown = Object.entries(values)
    .filter(([key]) => key !== 'signature')
    .map(([key, value]) => `  ${key} = ${value.replace(/\n/g, ' / ')}`);
  parts.push(shown.length ? shown.join('\n') : '  (none)');
  parts.push(`  signature (use verbatim at the end) = ${(values.signature ?? '').replace(/\n/g, ' / ')}`);

  parts.push('');
  parts.push('--- THE INCOMING CUSTOMER EMAIL ---');
  parts.push(`From: ${email.fromName || email.fromEmail} <${email.fromEmail}>`);
  parts.push(`Subject: ${truncate(email.subject || '(no subject)', 300)}`);
  parts.push('Body:');
  parts.push(truncate(stripQuotedText(email.body) || '(empty body)', EMAIL_CHARS));

  parts.push('');
  parts.push(
    'Now write the reply. Remember: invent nothing, and keep any {{placeholder}} you cannot fill.',
  );

  return parts.join('\n');
}

/**
 * Produce a reply for one email, using the output draft fed for its type.
 *
 * Two routes, and both are fully supported:
 *   - AI route: the model adapts the approved template to this specific customer.
 *   - Offline route: the template is placeholder-filled and returned as-is. Less
 *     personal, but correct, free, and it always works.
 *
 * Either way the output draft supplies the wording, so the reply stays on-message.
 */
export async function draftReply(
  email: Pick<EmailRecord, 'fromName' | 'fromEmail' | 'subject' | 'body'>,
  type: EmailType,
  replyExamples: ReplyExample[],
  settings: Settings,
): Promise<DraftResult> {
  const values = buildPlaceholderValues(email, settings);

  // Always compute the offline version first: it is the AI's starting point and
  // the fallback if the AI call fails.
  const subjectTemplate = type.replySubject?.trim() || 'Re: {{subject}}';
  const filledSubject = fillTemplate(subjectTemplate, values);
  const filledBody = fillTemplate(type.replyBody ?? '', values);

  const templateResult: DraftResult = {
    subject: filledSubject.text || `Re: ${stripReplyPrefix(email.subject)}`,
    body: filledBody.text,
    generatedBy: 'template',
    unresolvedPlaceholders: [...new Set([...filledSubject.unresolved, ...filledBody.unresolved])],
    aiError: null,
  };

  const provider = resolveAiProvider();
  if (!provider) return templateResult;

  try {
    const raw = await provider.complete({
      system: SYSTEM_PROMPT,
      prompt: buildPrompt(
        email,
        type,
        replyExamples,
        values,
        filledSubject.text,
        filledBody.text,
        settings,
      ),
      json: true,
      temperature: 0.3,
      maxTokens: 2000,
    });

    const parsed = extractJson(raw) as Record<string, unknown> | null;
    const body = typeof parsed?.body === 'string' ? parsed.body.trim() : '';
    const subject = typeof parsed?.subject === 'string' ? parsed.subject.trim() : '';

    // A suspiciously short body means the model failed at the task; the filled
    // template is genuinely better than a two-line non-answer.
    if (!body || body.length < 40) {
      return {
        ...templateResult,
        aiError: 'the model returned an empty or unusably short reply; used the template instead',
      };
    }

    return {
      subject: subject || templateResult.subject,
      body,
      generatedBy: `${provider.name}:${provider.model}`,
      // Re-scan the model's output: it may have kept placeholders (as instructed)
      // or introduced ones the template did not have.
      unresolvedPlaceholders: findPlaceholders(`${subject}\n${body}`),
      aiError: null,
    };
  } catch (err) {
    const message =
      err instanceof AiError
        ? `${err.provider}: ${err.message}`
        : `unexpected error: ${(err as Error).message}`;
    console.error('[draft] AI call failed, falling back to the filled template:', message);
    return { ...templateResult, aiError: message };
  }
}
