import type { Classification, EmailRecord, ReviewItem, Settings } from './types';
import { fileSafe } from './util';

/**
 * Build the file that accompanies a flagged email.
 *
 * The brief calls for the unmatched email to be written to a file and forwarded
 * to the human team. This produces that file: a self-contained, readable record
 * that makes sense to somebody who has never opened the app. It is attached to
 * the alert email and downloadable from the Review page.
 *
 * The content is generated on demand from the stored records rather than saved as
 * a blob, so it never goes stale and there is nothing extra to back up.
 */
export function buildFlagFile(args: {
  email: EmailRecord;
  classification: Classification | null;
  review: ReviewItem | null;
  settings: Settings;
  baseUrl: string;
}): { filename: string; content: string } {
  const { email, classification, review, settings, baseUrl } = args;

  const shortId = email.id.slice(0, 8);
  const datePart = email.receivedAt.slice(0, 10);
  const filename = `flagged-email-${datePart}-${fileSafe(shortId)}.txt`;

  const rule = '='.repeat(78);
  const thinRule = '-'.repeat(78);
  const lines: string[] = [];

  lines.push(rule);
  lines.push('UNCLASSIFIED EMAIL — HUMAN REVIEW REQUIRED');
  lines.push(rule);
  lines.push('');
  lines.push(`Company:            ${settings.companyName}`);
  lines.push(`Generated:          ${new Date().toISOString()}`);
  lines.push(`Internal email ID:  ${email.id}`);
  if (review) lines.push(`Review item ID:     ${review.id}`);
  lines.push('');

  lines.push(thinRule);
  lines.push('WHY THIS EMAIL WAS FLAGGED');
  lines.push(thinRule);
  lines.push('');
  lines.push(wrap(review?.reason || classification?.reasoning || 'No reason was recorded.'));
  lines.push('');
  if (classification) {
    lines.push(`Decision method:    ${describeMethod(classification.method)}`);
    lines.push(`Confidence:         ${classification.confidence.toFixed(3)}`);
    lines.push(`AI confidence gate: ${settings.confidenceThreshold.toFixed(2)}`);
    lines.push(`Matcher gate:       ${settings.heuristicThreshold.toFixed(2)}`);
    lines.push('');
    if (classification.reasoning && classification.reasoning !== review?.reason) {
      lines.push('Reasoning recorded at the time:');
      lines.push(wrap(classification.reasoning, 2));
      lines.push('');
    }
  }

  const scores = review?.topScores?.length ? review.topScores : (classification?.scores ?? []);
  if (scores.length) {
    lines.push(thinRule);
    lines.push('CLOSEST EXISTING TYPES (none passed the threshold)');
    lines.push(thinRule);
    lines.push('');
    scores.slice(0, 5).forEach((score, i) => {
      lines.push(`  ${i + 1}. ${score.typeName}  —  score ${score.score.toFixed(3)}`);
      if (score.matchedKeywords?.length) {
        lines.push(`     phrases that matched: ${score.matchedKeywords.slice(0, 8).join(', ')}`);
      }
    });
    lines.push('');
  }

  lines.push(thinRule);
  lines.push('THE ORIGINAL EMAIL, IN FULL');
  lines.push(thinRule);
  lines.push('');
  lines.push(`From:      ${email.fromName ? `${email.fromName} <${email.fromEmail}>` : email.fromEmail}`);
  if (email.toEmail) lines.push(`To:        ${email.toEmail}`);
  lines.push(`Received:  ${email.receivedAt}`);
  lines.push(`Source:    ${describeSource(email.source)}`);
  if (email.externalId) lines.push(`Message-ID: ${email.externalId}`);
  lines.push(`Subject:   ${email.subject || '(no subject)'}`);
  lines.push('');
  lines.push('Body:');
  lines.push('');
  lines.push(email.body || '(the message had no body text)');
  lines.push('');

  lines.push(thinRule);
  lines.push('WHAT TO DO NEXT');
  lines.push(thinRule);
  lines.push('');
  lines.push(`Open the review queue:  ${baseUrl}/review`);
  if (review) lines.push(`This item directly:     ${baseUrl}/review/${review.id}`);
  lines.push('');
  lines.push('You have two options there:');
  lines.push('');
  lines.push('  1. IT BELONGS TO A TYPE WE ALREADY HAVE.');
  lines.push('     Pick that type. The system stores this email as a new training');
  lines.push('     example for it, so emails like it are recognised automatically from');
  lines.push('     now on, and it drafts a reply using that type\'s approved template.');
  lines.push('');
  lines.push('  2. IT IS A NEW KIND OF EMAIL.');
  lines.push('     Create a new type. You give it a name, a short description, and the');
  lines.push('     reply template that should be used for it. This email becomes its');
  lines.push('     first training example and a reply is drafted immediately.');
  lines.push('');
  lines.push('Either way, no reply has been sent to the sender yet.');
  lines.push('');
  lines.push(rule);
  lines.push('END OF FILE');
  lines.push(rule);

  return { filename, content: lines.join('\n') };
}

function describeMethod(method: string): string {
  switch (method) {
    case 'ai':
      return 'AI model';
    case 'heuristic':
      return 'offline keyword matcher';
    case 'ai+heuristic':
      return 'AI model, agreed with by the offline matcher';
    case 'human':
      return 'assigned by a person';
    default:
      return method;
  }
}

function describeSource(source: string): string {
  switch (source) {
    case 'imap':
      return 'fetched from the connected mailbox';
    case 'upload':
      return 'uploaded file';
    case 'manual':
      return 'pasted into the app';
    case 'seed':
      return 'demo sample';
    default:
      return source;
  }
}

/** Soft-wrap prose to 76 columns so the file reads well in any text editor. */
function wrap(text: string, indent = 0): string {
  const pad = ' '.repeat(indent);
  const width = 76 - indent;
  const out: string[] = [];

  for (const paragraph of (text || '').split('\n')) {
    let line = '';
    for (const word of paragraph.split(/\s+/).filter(Boolean)) {
      if (line && line.length + word.length + 1 > width) {
        out.push(pad + line);
        line = word;
      } else {
        line = line ? `${line} ${word}` : word;
      }
    }
    out.push(pad + line);
  }

  return out.join('\n');
}
