'use client';

import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { apiGet, apiPost } from '@/lib/client';

interface ConfigResponse {
  aiProvider: string;
  aiReady: boolean;
  authEnabled: boolean;
  stats?: { flaggedOpen: number };
}

const LINKS = [
  { href: '/', label: 'Dashboard' },
  { href: '/inbox', label: 'Inbox' },
  { href: '/review', label: 'Review' },
  { href: '/types', label: 'Email types' },
  { href: '/mailbox', label: 'Mailbox' },
  { href: '/settings', label: 'Settings' },
];

export function NavBar() {
  const pathname = usePathname();
  const router = useRouter();
  const [config, setConfig] = useState<ConfigResponse | null>(null);
  const [open, setOpen] = useState(false);

  // The flagged count in the nav is the main signal that a human is needed, so it
  // refreshes on every navigation.
  useEffect(() => {
    if (pathname === '/login') return;
    let cancelled = false;
    apiGet<ConfigResponse>('/api/config')
      .then((data) => {
        if (!cancelled) setConfig(data);
      })
      .catch(() => {
        /* the page itself will report the problem */
      });
    return () => {
      cancelled = true;
    };
  }, [pathname]);

  if (pathname === '/login') return null;

  const flagged = config?.stats?.flaggedOpen ?? 0;

  const isActive = (href: string) =>
    href === '/' ? pathname === '/' : pathname === href || pathname.startsWith(`${href}/`);

  return (
    <header className="sticky top-0 z-20 border-b border-slate-200 bg-white/95 backdrop-blur">
      <div className="mx-auto flex w-full max-w-6xl items-center gap-4 px-4 py-3 sm:px-6">
        <Link href="/" className="flex shrink-0 items-center gap-2 font-semibold text-slate-900">
          <span className="grid h-7 w-7 place-items-center rounded-md bg-brand-600 text-sm text-white">
            ✉
          </span>
          <span className="hidden sm:inline">Email Triage Agent</span>
        </Link>

        <nav className="hidden flex-1 items-center gap-1 md:flex">
          {LINKS.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className={`rounded-lg px-3 py-1.5 text-sm font-medium transition-colors ${
                isActive(link.href)
                  ? 'bg-brand-50 text-brand-700'
                  : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              {link.label}
              {link.href === '/review' && flagged > 0 ? (
                <span className="ml-1.5 rounded-full bg-amber-500 px-1.5 py-0.5 text-[11px] font-semibold text-white">
                  {flagged}
                </span>
              ) : null}
            </Link>
          ))}
        </nav>

        <div className="ml-auto flex items-center gap-3">
          {config ? (
            <span
              className="hidden items-center gap-1.5 text-xs text-slate-500 lg:flex"
              title={
                config.aiReady
                  ? `Using the ${config.aiProvider} model to classify and draft.`
                  : 'No AI key is set, so the built-in offline matcher and plain template filling are used.'
              }
            >
              <span
                className={`h-2 w-2 rounded-full ${config.aiReady ? 'bg-emerald-500' : 'bg-slate-300'}`}
              />
              {config.aiReady ? config.aiProvider : 'offline mode'}
            </span>
          ) : null}

          {config?.authEnabled ? (
            <button
              type="button"
              className="btn-secondary btn-sm"
              onClick={async () => {
                await apiPost('/api/logout').catch(() => undefined);
                router.push('/login');
              }}
            >
              Sign out
            </button>
          ) : null}

          <button
            type="button"
            className="btn-secondary btn-sm md:hidden"
            onClick={() => setOpen((v) => !v)}
            aria-expanded={open}
            aria-label="Toggle navigation"
          >
            Menu
          </button>
        </div>
      </div>

      {open ? (
        <nav className="border-t border-slate-200 bg-white px-4 py-2 md:hidden">
          {LINKS.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              onClick={() => setOpen(false)}
              className={`block rounded-lg px-3 py-2 text-sm font-medium ${
                isActive(link.href) ? 'bg-brand-50 text-brand-700' : 'text-slate-700'
              }`}
            >
              {link.label}
              {link.href === '/review' && flagged > 0 ? ` (${flagged})` : ''}
            </Link>
          ))}
        </nav>
      ) : null}
    </header>
  );
}
