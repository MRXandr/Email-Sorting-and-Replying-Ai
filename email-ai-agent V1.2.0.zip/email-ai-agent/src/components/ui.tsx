'use client';

import { useEffect, useState, type ReactNode } from 'react';

/** Wrapper for a page's heading and optional actions. */
export function PageHeader({
  title,
  description,
  actions,
}: {
  title: string;
  description?: ReactNode;
  actions?: ReactNode;
}) {
  return (
    <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight text-slate-900">{title}</h1>
        {description ? <p className="mt-1.5 max-w-3xl text-sm text-slate-600">{description}</p> : null}
      </div>
      {actions ? <div className="flex flex-wrap items-center gap-2">{actions}</div> : null}
    </div>
  );
}

export function Card({
  title,
  description,
  actions,
  children,
  className = '',
}: {
  title?: ReactNode;
  description?: ReactNode;
  actions?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  return (
    <section className={`card ${className}`}>
      {title || actions ? (
        <header className="flex flex-col gap-2 border-b border-slate-200 px-5 py-4 sm:flex-row sm:items-center sm:justify-between sm:px-6">
          <div>
            <h2 className="text-sm font-semibold text-slate-900">{title}</h2>
            {description ? <p className="mt-1 text-xs text-slate-500">{description}</p> : null}
          </div>
          {actions ? <div className="flex flex-wrap items-center gap-2">{actions}</div> : null}
        </header>
      ) : null}
      <div className="card-pad">{children}</div>
    </section>
  );
}

const STATUS_STYLES: Record<string, string> = {
  classified: 'bg-emerald-100 text-emerald-800',
  flagged: 'bg-amber-100 text-amber-900',
  resolved: 'bg-sky-100 text-sky-800',
  open: 'bg-amber-100 text-amber-900',
  draft: 'bg-slate-100 text-slate-700',
  edited: 'bg-indigo-100 text-indigo-800',
  sent: 'bg-emerald-100 text-emerald-800',
  discarded: 'bg-slate-100 text-slate-500',
};

const STATUS_LABELS: Record<string, string> = {
  classified: 'Classified',
  flagged: 'Needs review',
  resolved: 'Resolved by a person',
  open: 'Open',
  draft: 'Draft',
  edited: 'Edited',
  sent: 'Sent',
  discarded: 'Discarded',
};

export function StatusBadge({ status }: { status: string }) {
  return (
    <span className={`badge ${STATUS_STYLES[status] ?? 'bg-slate-100 text-slate-700'}`}>
      {STATUS_LABELS[status] ?? status}
    </span>
  );
}

export function MethodBadge({ method }: { method: string | null }) {
  if (!method) return null;
  const labels: Record<string, string> = {
    ai: 'decided by AI',
    'ai+heuristic': 'AI, matcher agreed',
    heuristic: 'offline matcher',
    human: 'assigned by a person',
  };
  return (
    <span className="badge bg-slate-100 text-slate-600" title="How this decision was reached">
      {labels[method] ?? method}
    </span>
  );
}

/**
 * A 0..1 value drawn as a bar.
 *
 * `showValue` prints the number alongside, which is what you want for a
 * classification score. Turn it off where the bar represents a proportion — a
 * share of total printed as "0.200" reads like a confidence score, which is
 * misleading.
 */
export function ScoreBar({
  score,
  highlight = false,
  showValue = true,
}: {
  score: number;
  highlight?: boolean;
  showValue?: boolean;
}) {
  const pct = Math.round(Math.min(Math.max(score, 0), 1) * 100);
  return (
    <div className="flex items-center gap-2">
      <div className="h-1.5 w-24 overflow-hidden rounded-full bg-slate-200">
        <div
          className={`h-full rounded-full ${highlight ? 'bg-brand-600' : 'bg-slate-400'}`}
          style={{ width: `${pct}%` }}
        />
      </div>
      {showValue ? <span className="tabular-nums text-xs text-slate-600">{score.toFixed(3)}</span> : null}
    </div>
  );
}

/** Inline message for errors, warnings, successes and plain notes. */
export function Notice({
  kind = 'info',
  title,
  children,
  onDismiss,
}: {
  kind?: 'info' | 'success' | 'warning' | 'error';
  title?: ReactNode;
  children?: ReactNode;
  onDismiss?: () => void;
}) {
  const styles = {
    info: 'border-sky-200 bg-sky-50 text-sky-900',
    success: 'border-emerald-200 bg-emerald-50 text-emerald-900',
    warning: 'border-amber-200 bg-amber-50 text-amber-900',
    error: 'border-red-200 bg-red-50 text-red-900',
  }[kind];

  return (
    <div className={`rounded-lg border px-4 py-3 text-sm ${styles}`} role={kind === 'error' ? 'alert' : undefined}>
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          {title ? <p className="font-semibold">{title}</p> : null}
          {children ? <div className={title ? 'mt-1 leading-relaxed' : 'leading-relaxed'}>{children}</div> : null}
        </div>
        {onDismiss ? (
          <button
            type="button"
            onClick={onDismiss}
            className="shrink-0 rounded px-1 text-xs opacity-60 hover:opacity-100"
            aria-label="Dismiss"
          >
            ✕
          </button>
        ) : null}
      </div>
    </div>
  );
}

export function Spinner({ label = 'Loading' }: { label?: string }) {
  return (
    <span className="inline-flex items-center gap-2 text-sm text-slate-500">
      <span
        className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-slate-300 border-t-brand-600"
        aria-hidden
      />
      {label}…
    </span>
  );
}

export function EmptyState({
  title,
  children,
  action,
}: {
  title: string;
  children?: ReactNode;
  action?: ReactNode;
}) {
  return (
    <div className="rounded-lg border border-dashed border-slate-300 bg-slate-50 px-6 py-10 text-center">
      <p className="text-sm font-medium text-slate-700">{title}</p>
      {children ? <p className="mx-auto mt-1.5 max-w-md text-sm text-slate-500">{children}</p> : null}
      {action ? <div className="mt-4 flex justify-center">{action}</div> : null}
    </div>
  );
}

export function Stat({
  label,
  value,
  hint,
  tone = 'default',
}: {
  label: string;
  value: ReactNode;
  hint?: string;
  tone?: 'default' | 'warning' | 'success';
}) {
  const valueTone = {
    default: 'text-slate-900',
    warning: 'text-amber-700',
    success: 'text-emerald-700',
  }[tone];

  return (
    <div className="card card-pad">
      <p className="text-xs font-medium uppercase tracking-wide text-slate-500">{label}</p>
      <p className={`mt-1.5 text-2xl font-semibold tabular-nums ${valueTone}`}>{value}</p>
      {hint ? <p className="mt-1 text-xs text-slate-500">{hint}</p> : null}
    </div>
  );
}

/** Highlight {{placeholder}} tokens so unfilled gaps are impossible to miss. */
export function TextWithPlaceholders({ text }: { text: string }) {
  const parts = (text || '').split(/(\{\{\s*[a-zA-Z0-9_.-]+\s*\}\})/g);
  return (
    <div className="email-body">
      {parts.map((part, i) =>
        /^\{\{\s*[a-zA-Z0-9_.-]+\s*\}\}$/.test(part) ? (
          <mark key={i} className="rounded bg-amber-200 px-1 font-medium text-amber-900">
            {part}
          </mark>
        ) : (
          <span key={i}>{part}</span>
        ),
      )}
    </div>
  );
}

/** Relative time that renders identically on server and client to avoid hydration mismatch. */
export function TimeAgo({ iso }: { iso: string }) {
  const [text, setText] = useState(() => iso.slice(0, 16).replace('T', ' '));

  useEffect(() => {
    const format = () => {
      const then = new Date(iso).getTime();
      if (!Number.isFinite(then)) return iso;
      const seconds = Math.floor((Date.now() - then) / 1000);
      if (seconds < 45) return 'just now';
      if (seconds < 90) return 'a minute ago';
      if (seconds < 3600) return `${Math.floor(seconds / 60)} minutes ago`;
      if (seconds < 7200) return 'an hour ago';
      if (seconds < 86400) return `${Math.floor(seconds / 3600)} hours ago`;
      if (seconds < 172800) return 'yesterday';
      if (seconds < 2592000) return `${Math.floor(seconds / 86400)} days ago`;
      return new Date(iso).toLocaleDateString();
    };

    setText(format());
    const timer = setInterval(() => setText(format()), 30_000);
    return () => clearInterval(timer);
  }, [iso]);

  return (
    <time dateTime={iso} title={new Date(iso).toLocaleString()} suppressHydrationWarning>
      {text}
    </time>
  );
}

/** Confirm-before-acting button, so nothing destructive happens on one click. */
export function ConfirmButton({
  onConfirm,
  children,
  confirmLabel = 'Really?',
  className = 'btn-danger btn-sm',
  disabled = false,
}: {
  onConfirm: () => void;
  children: ReactNode;
  confirmLabel?: string;
  className?: string;
  disabled?: boolean;
}) {
  const [armed, setArmed] = useState(false);

  useEffect(() => {
    if (!armed) return;
    const timer = setTimeout(() => setArmed(false), 4000);
    return () => clearTimeout(timer);
  }, [armed]);

  return (
    <button
      type="button"
      disabled={disabled}
      className={className}
      onClick={() => {
        if (armed) {
          setArmed(false);
          onConfirm();
        } else {
          setArmed(true);
        }
      }}
    >
      {armed ? confirmLabel : children}
    </button>
  );
}
