import { NextResponse, type NextRequest } from 'next/server';
import { isPublicPath, safeEqual, SESSION_COOKIE, sessionToken } from '@/lib/auth';

/**
 * Gate the whole app behind APP_PASSWORD, when one is set.
 *
 * With no APP_PASSWORD the middleware does nothing, so local development needs no
 * login. Once the app is deployed to a public URL, setting APP_PASSWORD is the
 * single step that stops strangers reading the mailbox.
 *
 * Note the environment variables are read here as direct, literal property
 * accesses rather than through `src/lib/config.ts`. Middleware runs on the Edge
 * runtime, where the bundler inlines only statically analysable references like
 * `process.env.APP_PASSWORD` — the dynamic `process.env[name]` lookup that
 * config.ts uses returns undefined there. Reading it dynamically would silently
 * disable the password gate while appearing to work, which is the worst possible
 * failure for an access check, so it is spelled out literally here.
 */
export async function middleware(request: NextRequest) {
  const password = (process.env.APP_PASSWORD ?? '').trim();
  const secret = (process.env.AUTH_SECRET ?? '').trim() || 'change-me-in-production';

  // No password configured → the site is open.
  if (!password) return NextResponse.next();

  const { pathname } = request.nextUrl;
  if (isPublicPath(pathname)) return NextResponse.next();

  const expected = await sessionToken(password, secret);
  const provided = request.cookies.get(SESSION_COOKIE)?.value ?? '';

  if (provided && safeEqual(provided, expected)) return NextResponse.next();

  // API calls get a status code; page requests get sent to the login screen.
  if (pathname.startsWith('/api/')) {
    return NextResponse.json(
      { error: 'Not signed in. POST your password to /api/login first.' },
      { status: 401 },
    );
  }

  const loginUrl = new URL('/login', request.url);
  if (pathname !== '/') loginUrl.searchParams.set('next', pathname);
  return NextResponse.redirect(loginUrl);
}

export const config = {
  // Everything except Next's own static assets.
  matcher: ['/((?!_next/static|_next/image|favicon.ico).*)'],
};
