'use client';

import Link from 'next/link';
import { useCallback, useEffect, useState } from 'react';
import { Card, EmptyState, Notice, PageHeader, Spinner } from '@/components/ui';
import { apiGet, apiPost } from '@/lib/client';

interface VerifyResponse {
  imap: {
    configured: boolean;
    ok: boolean;
    error: string | null;
    host: string | null;
    port: number;
    secure: boolean;
    user: string | null;
    mailbox: string;
  };
  smtp: {
    configured: boolean;
    ok: boolean;
    error: string | null;
    host: string | null;
    port: number;
    secure: boolean;
    user: string | null;
    from: string | null;
  };
}

interface FetchResponse {
  ok: boolean;
  configured: boolean;
  mailbox?: string;
  unseenTotal?: number;
  fetched?: number;
  processed?: number;
  skipped?: number;
  classified?: number;
  flagged?: number;
  failed?: number;
  notes?: string[];
  error?: string | null;
  outcomes?: Array<{
    subject: string;
    from: string;
    ok: boolean;
    flagged?: boolean;
    typeName?: string | null;
    duplicate?: boolean;
    error?: string;
  }>;
}

export default function MailboxPage() {
  const [config, setConfig] = useState<{ imapConfigured: boolean; smtpConfigured: boolean } | null>(
    null,
  );
  const [verify, setVerify] = useState<VerifyResponse | null>(null);
  const [result, setResult] = useState<FetchResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      setConfig(await apiGet('/api/config'));
    } catch (err) {
      setError((err as Error).message);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const runVerify = async () => {
    setBusy('verify');
    setError(null);
    try {
      setVerify(await apiPost<VerifyResponse>('/api/mailbox/verify'));
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(null);
    }
  };

  const runFetch = async () => {
    setBusy('fetch');
    setError(null);
    setResult(null);
    try {
      setResult(await apiPost<FetchResponse>('/api/mailbox/fetch'));
    } catch (err) {
      // A failed fetch still returns a useful body; surface whatever we got.
      setError((err as Error).message);
    } finally {
      setBusy(null);
    }
  };

  return (
    <>
      <PageHeader
        title="Mailbox"
        description="Read unread mail straight from a real inbox and run it through the agent."
        actions={
          <>
            <button
              type="button"
              className="btn-secondary"
              onClick={() => void runVerify()}
              disabled={busy !== null}
            >
              {busy === 'verify' ? 'Testing…' : 'Test the connection'}
            </button>
            <button
              type="button"
              className="btn-primary"
              onClick={() => void runFetch()}
              disabled={busy !== null || !config?.imapConfigured}
            >
              {busy === 'fetch' ? 'Fetching…' : 'Fetch new mail'}
            </button>
          </>
        }
      />

      <div className="space-y-6">
        {error ? (
          <Notice kind="error" onDismiss={() => setError(null)}>
            {error}
          </Notice>
        ) : null}

        {config && !config.imapConfigured ? (
          <Notice kind="info" title="No mailbox is connected yet">
            <p>
              To read real email, set <code>IMAP_HOST</code>, <code>IMAP_USER</code> and{' '}
              <code>IMAP_PASSWORD</code> in your environment file and restart the app. For Gmail that
              means <code>imap.gmail.com</code> on port 993, with a 16-character App Password rather
              than your normal account password.
            </p>
            <p className="mt-1.5">
              Nothing else depends on this —{' '}
              <Link href="/inbox" className="font-medium underline">
                paste or upload emails
              </Link>{' '}
              to use the agent without connecting a mailbox.
            </p>
          </Notice>
        ) : null}

        {verify ? (
          <div className="grid gap-6 md:grid-cols-2">
            <Card title="Reading mail (IMAP)">
              <ConnectionStatus
                configured={verify.imap.configured}
                ok={verify.imap.ok}
                error={verify.imap.error}
                rows={[
                  ['Server', verify.imap.host ?? '—'],
                  ['Port', String(verify.imap.port)],
                  ['TLS', verify.imap.secure ? 'on' : 'off'],
                  ['Username', verify.imap.user ?? '—'],
                  ['Folder', verify.imap.mailbox],
                ]}
              />
            </Card>

            <Card title="Sending mail (SMTP)">
              <ConnectionStatus
                configured={verify.smtp.configured}
                ok={verify.smtp.ok}
                error={verify.smtp.error}
                rows={[
                  ['Server', verify.smtp.host ?? '—'],
                  ['Port', String(verify.smtp.port)],
                  ['TLS', verify.smtp.secure ? 'implicit (465)' : 'STARTTLS (587)'],
                  ['Username', verify.smtp.user ?? '—'],
                  ['Sends as', verify.smtp.from ?? '—'],
                ]}
              />
            </Card>
          </div>
        ) : null}

        {result ? (
          <Card
            title="What came in"
            description={
              result.ok
                ? `${result.unseenTotal ?? 0} unread in ${result.mailbox}; handled ${result.fetched ?? 0} this run`
                : 'The fetch did not complete'
            }
          >
            {result.error ? (
              <div className="mb-4">
                <Notice kind="error" title="Could not read the mailbox">
                  {result.error}
                </Notice>
              </div>
            ) : null}

            {result.notes?.length ? (
              <div className="mb-4">
                <Notice kind="info">
                  <ul className="list-inside list-disc space-y-1">
                    {result.notes.map((note, i) => (
                      <li key={i}>{note}</li>
                    ))}
                  </ul>
                </Notice>
              </div>
            ) : null}

            {result.outcomes?.length ? (
              <>
                <div className="mb-4 flex flex-wrap gap-4 text-sm">
                  <span className="text-emerald-700">
                    <strong className="tabular-nums">{result.classified ?? 0}</strong> sorted
                  </span>
                  <span className="text-amber-700">
                    <strong className="tabular-nums">{result.flagged ?? 0}</strong> flagged for a
                    person
                  </span>
                  {result.skipped ? (
                    <span className="text-slate-500">
                      <strong className="tabular-nums">{result.skipped}</strong> already seen
                    </span>
                  ) : null}
                  {result.failed ? (
                    <span className="text-red-700">
                      <strong className="tabular-nums">{result.failed}</strong> failed
                    </span>
                  ) : null}
                </div>

                <ul className="divide-y divide-slate-100">
                  {result.outcomes.map((outcome, i) => (
                    <li key={i} className="flex flex-wrap items-start justify-between gap-2 py-2.5">
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm text-slate-900">{outcome.subject}</p>
                        <p className="truncate text-xs text-slate-500">{outcome.from}</p>
                        {outcome.error ? (
                          <p className="mt-1 text-xs text-red-600">{outcome.error}</p>
                        ) : null}
                      </div>
                      <span className="shrink-0">
                        {!outcome.ok ? (
                          <span className="badge bg-red-100 text-red-800">failed</span>
                        ) : outcome.duplicate ? (
                          <span className="badge bg-slate-100 text-slate-600">already seen</span>
                        ) : outcome.flagged ? (
                          <span className="badge bg-amber-100 text-amber-900">needs review</span>
                        ) : (
                          <span className="badge bg-emerald-100 text-emerald-800">
                            {outcome.typeName}
                          </span>
                        )}
                      </span>
                    </li>
                  ))}
                </ul>

                <div className="mt-4 flex flex-wrap gap-2">
                  <Link href="/inbox" className="btn-secondary btn-sm">
                    See everything in the inbox
                  </Link>
                  {result.flagged ? (
                    <Link href="/review" className="btn-primary btn-sm">
                      Review the {result.flagged} flagged
                    </Link>
                  ) : null}
                </div>
              </>
            ) : result.ok ? (
              <EmptyState title="No unread mail">
                Everything in {result.mailbox} has already been read. Send yourself a test email and
                try again.
              </EmptyState>
            ) : null}
          </Card>
        ) : null}

        <Card title="How this works">
          <ul className="space-y-2.5 text-sm leading-relaxed text-slate-700">
            <li>
              <strong>Only unread messages are fetched.</strong> A message is marked read on the
              server only after the agent has finished with it, so if anything fails partway the
              message stays unread and is picked up next time rather than being lost.
            </li>
            <li>
              <strong>Each run handles a few messages.</strong> The default is five, because reading
              mail plus two model calls per message has to finish inside the hosting platform&apos;s
              request time limit. Click again to work through a backlog, or raise{' '}
              <code>IMAP_BATCH_SIZE</code>.
            </li>
            <li>
              <strong>The same message is never processed twice,</strong> even if it is fetched again
              — messages are matched on their Message-ID.
            </li>
            <li>
              <strong>Nothing is replied to automatically</strong> unless you switch auto-send on in{' '}
              <Link href="/settings" className="underline">
                Settings
              </Link>
              . By default every reply waits for a person to approve it.
            </li>
          </ul>
        </Card>
      </div>
    </>
  );
}

function ConnectionStatus({
  configured,
  ok,
  error,
  rows,
}: {
  configured: boolean;
  ok: boolean;
  error: string | null;
  rows: Array<[string, string]>;
}) {
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <span
          className={`h-2.5 w-2.5 rounded-full ${
            !configured ? 'bg-slate-300' : ok ? 'bg-emerald-500' : 'bg-red-500'
          }`}
        />
        <span className="text-sm font-medium text-slate-900">
          {!configured ? 'Not configured' : ok ? 'Connected' : 'Could not connect'}
        </span>
      </div>

      {error && configured ? <Notice kind="error">{error}</Notice> : null}

      {configured ? (
        <dl className="space-y-1.5 text-xs">
          {rows.map(([label, value]) => (
            <div key={label} className="flex justify-between gap-3">
              <dt className="text-slate-500">{label}</dt>
              <dd className="truncate font-mono text-slate-800">{value}</dd>
            </div>
          ))}
        </dl>
      ) : null}
    </div>
  );
}
