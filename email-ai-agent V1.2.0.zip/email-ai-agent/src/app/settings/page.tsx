'use client';

import Link from 'next/link';
import { useCallback, useEffect, useState } from 'react';
import { Card, ConfirmButton, Notice, PageHeader, Spinner } from '@/components/ui';
import { apiGet, apiPatch, apiPost } from '@/lib/client';
import type { Settings, Stats } from '@/lib/types';

interface ConfigResponse {
  aiProvider: string;
  aiModel: string | null;
  aiReady: boolean;
  storage: string;
  storageWarning: string | null;
  imapConfigured: boolean;
  smtpConfigured: boolean;
  authEnabled: boolean;
  settings: Settings;
  stats: Stats;
  effectiveReviewEmail: string;
  reviewEmailFromEnv: boolean;
}

export default function SettingsPage() {
  const [config, setConfig] = useState<ConfigResponse | null>(null);
  const [form, setForm] = useState<Settings | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [dirty, setDirty] = useState(false);

  const load = useCallback(async () => {
    setError(null);
    try {
      const data = await apiGet<ConfigResponse>('/api/config');
      setConfig(data);
      setForm(data.settings);
      setDirty(false);
    } catch (err) {
      setError((err as Error).message);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const update = (patch: Partial<Settings>) => {
    setForm((current) => (current ? { ...current, ...patch } : current));
    setDirty(true);
  };

  const save = async () => {
    if (!form) return;
    setBusy('save');
    setError(null);
    setNotice(null);
    try {
      await apiPatch('/api/settings', {
        companyName: form.companyName,
        supportSignature: form.supportSignature,
        reviewTeamEmail: form.reviewTeamEmail,
        confidenceThreshold: form.confidenceThreshold,
        heuristicThreshold: form.heuristicThreshold,
        marginThreshold: form.marginThreshold,
        autoSendEnabled: form.autoSendEnabled,
      });
      setNotice('Settings saved.');
      await load();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(null);
    }
  };

  const reseed = async () => {
    setBusy('seed');
    setError(null);
    setNotice(null);
    try {
      const result = await apiPost<{ message: string }>('/api/seed', { confirm: true });
      setNotice(result.message);
      await load();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(null);
    }
  };

  if (!config || !form) {
    return (
      <div className="py-20 text-center">
        {error ? <Notice kind="error">{error}</Notice> : <Spinner label="Loading settings" />}
      </div>
    );
  }

  return (
    <>
      <PageHeader
        title="Settings"
        description="Things you can change here take effect immediately. Anything that needs an environment variable is marked as such and needs a restart or redeploy."
        actions={
          <button
            type="button"
            className="btn-primary"
            onClick={() => void save()}
            disabled={busy !== null || !dirty}
          >
            {busy === 'save' ? 'Saving…' : dirty ? 'Save changes' : 'Saved'}
          </button>
        }
      />

      <div className="space-y-6">
        {error ? (
          <Notice kind="error" onDismiss={() => setError(null)}>
            {error}
          </Notice>
        ) : null}
        {notice ? (
          <Notice kind="success" onDismiss={() => setNotice(null)}>
            {notice}
          </Notice>
        ) : null}
        {dirty ? <Notice kind="warning">You have unsaved changes.</Notice> : null}

        <Card title="Your company" description="Used to fill placeholders in every reply template">
          <div className="space-y-4">
            <div>
              <label className="label" htmlFor="companyName">
                Company name
              </label>
              <input
                id="companyName"
                className="input"
                value={form.companyName}
                onChange={(e) => update({ companyName: e.target.value })}
              />
              <p className="hint">
                Fills <code>{'{{company_name}}'}</code>.
              </p>
            </div>

            <div>
              <label className="label" htmlFor="signature">
                Email signature
              </label>
              <textarea
                id="signature"
                className="input min-h-[90px] font-mono text-[13px]"
                value={form.supportSignature}
                onChange={(e) => update({ supportSignature: e.target.value })}
              />
              <p className="hint">
                Fills <code>{'{{signature}}'}</code>. Line breaks are kept.
              </p>
            </div>
          </div>
        </Card>

        <Card
          title="Where flagged emails go"
          description="When nothing matches, the agent writes a file describing the email and sends it here"
        >
          <div className="space-y-4">
            <div>
              <label className="label" htmlFor="reviewEmail">
                Review team email address
              </label>
              <input
                id="reviewEmail"
                type="email"
                className="input"
                placeholder="support-leads@yourcompany.com"
                value={form.reviewTeamEmail}
                onChange={(e) => update({ reviewTeamEmail: e.target.value })}
              />
              <p className="hint">
                Leave blank for no alert emails — flagged mail still collects in the{' '}
                <Link href="/review" className="underline">
                  Review queue
                </Link>
                , nothing is lost either way.
              </p>
            </div>

            {config.reviewEmailFromEnv ? (
              <Notice kind="info">
                Nothing is saved here, so alerts are going to{' '}
                <strong>{config.effectiveReviewEmail}</strong>, which comes from the{' '}
                <code>REVIEW_TEAM_EMAIL</code> environment variable. Typing an address above
                overrides it.
              </Notice>
            ) : null}

            {config.effectiveReviewEmail && !config.smtpConfigured ? (
              <Notice kind="warning">
                An address is set but SMTP is not configured, so no alert can actually be sent. Set{' '}
                <code>SMTP_HOST</code>, <code>SMTP_USER</code> and <code>SMTP_PASSWORD</code>, then{' '}
                <Link href="/mailbox" className="font-medium underline">
                  test the connection
                </Link>
                .
              </Notice>
            ) : null}
          </div>
        </Card>

        <Card
          title="How careful the agent should be"
          description="Lower numbers mean it acts on weaker evidence. Higher numbers mean it asks a person more often."
        >
          <div className="space-y-6">
            <ThresholdSlider
              id="confidence"
              label="AI confidence needed to act"
              value={form.confidenceThreshold}
              onChange={(v) => update({ confidenceThreshold: v })}
              help="Applies when an AI model is in use. If the model reports less confidence than this in its own answer, the email is flagged rather than answered on a guess."
            />
            <ThresholdSlider
              id="heuristic"
              label="Offline matcher score needed to act"
              value={form.heuristicThreshold}
              onChange={(v) => update({ heuristicThreshold: v })}
              help="Applies when no AI key is set, or when the model could not be reached. It is a separate number because the two are not on the same scale: a model says 0.9 for an obvious match, while the matcher's score for the same email is nearer 0.5. The default sits in the measured gap between known and unknown mail."
            />
            <ThresholdSlider
              id="margin"
              label="How far ahead the winner must be"
              value={form.marginThreshold}
              onChange={(v) => update({ marginThreshold: v })}
              max={0.5}
              help="If the top two types score within this of each other, the email is genuinely ambiguous, so it goes to a person instead. Raise it if you are seeing confident-looking mistakes between two similar types."
            />

            <Notice kind="info">
              These thresholds are why unknown email gets flagged instead of being forced into the
              nearest category. Run <code>npm run calibrate</code> after changing your types to see
              how much room there is between mail the agent knows and mail it does not.
            </Notice>
          </div>
        </Card>

        <Card title="Sending replies">
          <label className="flex items-start gap-3">
            <input
              type="checkbox"
              className="mt-0.5 h-4 w-4 rounded border-slate-300"
              checked={form.autoSendEnabled}
              onChange={(e) => update({ autoSendEnabled: e.target.checked })}
            />
            <span className="text-sm">
              <span className="font-medium text-slate-900">
                Send drafted replies automatically, without anyone checking
              </span>
              <span className="mt-1 block text-slate-600">
                Off by default, and worth leaving off. With it on, any email that matches a type gets
                a reply sent straight to the customer in your company&apos;s name. A draft that still
                has unfilled placeholders is never sent automatically, whatever this is set to.
              </span>
            </span>
          </label>

          {form.autoSendEnabled ? (
            <div className="mt-4">
              <Notice kind="warning" title="Real emails will go out to real people">
                {config.smtpConfigured
                  ? 'SMTP is configured, so this is live as soon as you save.'
                  : 'SMTP is not configured, so nothing can actually be sent yet. The agent will tell you so rather than failing quietly.'}
              </Notice>
            </div>
          ) : null}
        </Card>

        <Card
          title="How this deployment is configured"
          description="Set through environment variables, so changing any of these needs a restart or redeploy"
        >
          <dl className="divide-y divide-slate-100 text-sm">
            <EnvRow
              label="AI provider"
              value={config.aiReady ? `${config.aiProvider} · ${config.aiModel}` : 'None — offline mode'}
              ok={config.aiReady}
              detail={
                config.aiReady
                  ? 'Classification and reply writing both go through this model.'
                  : 'The offline matcher and plain template filling are used. Everything works; replies are just less tailored. Set GEMINI_API_KEY to switch a model on.'
              }
            />
            <EnvRow
              label="Database"
              value={config.storage === 'postgres' ? 'Postgres' : 'Local JSON file'}
              ok={config.storage === 'postgres'}
              detail={
                config.storageWarning ??
                (config.storage === 'postgres'
                  ? 'DATABASE_URL is set.'
                  : 'Fine for local use. A hosted site needs Postgres, because serverless instances do not share a filesystem.')
              }
            />
            <EnvRow
              label="Reads mail (IMAP)"
              value={config.imapConfigured ? 'Configured' : 'Not configured'}
              ok={config.imapConfigured}
              detail="IMAP_HOST, IMAP_USER, IMAP_PASSWORD"
            />
            <EnvRow
              label="Sends mail (SMTP)"
              value={config.smtpConfigured ? 'Configured' : 'Not configured'}
              ok={config.smtpConfigured}
              detail="SMTP_HOST, SMTP_USER, SMTP_PASSWORD, SMTP_FROM"
            />
            <EnvRow
              label="Password protection"
              value={config.authEnabled ? 'On' : 'Off — anyone with the link can open this'}
              ok={config.authEnabled}
              detail="Set APP_PASSWORD (and a long random AUTH_SECRET) before sharing a public URL."
            />
          </dl>

          <div className="mt-4">
            <Link href="/mailbox" className="btn-secondary btn-sm">
              Test the mail connections
            </Link>
          </div>
        </Card>

        <Card title="Start over" description="Replaces everything with the demo company">
          <div className="flex flex-wrap items-center gap-3">
            <ConfirmButton
              onConfirm={() => void reseed()}
              confirmLabel="Erase everything and reload the demo?"
              className="btn-danger"
              disabled={busy !== null}
            >
              {busy === 'seed' ? 'Working…' : 'Reset and load demo data'}
            </ConfirmButton>
            <p className="text-xs text-slate-500">
              Deletes every email, type, draft and review item, then loads the five demo types again.
              There is no undo.
            </p>
          </div>
        </Card>
      </div>
    </>
  );
}

function ThresholdSlider({
  id,
  label,
  value,
  onChange,
  help,
  max = 1,
}: {
  id: string;
  label: string;
  value: number;
  onChange: (value: number) => void;
  help: string;
  max?: number;
}) {
  return (
    <div>
      <div className="mb-1.5 flex items-baseline justify-between gap-3">
        <label className="text-sm font-medium text-slate-700" htmlFor={id}>
          {label}
        </label>
        <span className="tabular-nums text-sm font-semibold text-brand-700">{value.toFixed(2)}</span>
      </div>
      <input
        id={id}
        type="range"
        min={0}
        max={max}
        step={0.01}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="w-full accent-brand-600"
      />
      <p className="hint">{help}</p>
    </div>
  );
}

function EnvRow({
  label,
  value,
  ok,
  detail,
}: {
  label: string;
  value: string;
  ok: boolean;
  detail: string;
}) {
  return (
    <div className="flex flex-col gap-1 py-3 sm:flex-row sm:items-start sm:justify-between sm:gap-4">
      <dt className="shrink-0 font-medium text-slate-700 sm:w-48">{label}</dt>
      <dd className="min-w-0 flex-1">
        <span className="flex items-center gap-2 font-medium text-slate-900">
          <span className={`h-2 w-2 shrink-0 rounded-full ${ok ? 'bg-emerald-500' : 'bg-amber-400'}`} />
          {value}
        </span>
        <span className="mt-0.5 block text-xs leading-relaxed text-slate-500">{detail}</span>
      </dd>
    </div>
  );
}
