'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { Card, Notice, PageHeader } from '@/components/ui';
import { apiPost } from '@/lib/client';
import type { EmailType } from '@/lib/types';

const DEFAULT_TEMPLATE = `Hi {{customer_first_name}},

Thank you for getting in touch with {{company_name}}.

[Write what should be said to everyone who sends this kind of email.]

Best regards,
{{signature}}`;

interface SampleDraft {
  subject: string;
  body: string;
}

export default function NewTypePage() {
  const router = useRouter();

  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [keywords, setKeywords] = useState('');
  const [replySubject, setReplySubject] = useState('Re: {{subject}}');
  const [replyBody, setReplyBody] = useState(DEFAULT_TEMPLATE);
  const [replyGuidance, setReplyGuidance] = useState('');
  const [samples, setSamples] = useState<SampleDraft[]>([{ subject: '', body: '' }]);

  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const updateSample = (index: number, patch: Partial<SampleDraft>) => {
    setSamples((current) => current.map((s, i) => (i === index ? { ...s, ...patch } : s)));
  };

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const result = await apiPost<{ type: EmailType }>('/api/types', {
        name,
        description,
        keywords,
        replySubject,
        replyBody,
        replyGuidance,
        samples: samples.filter((s) => s.subject.trim() || s.body.trim()),
      });
      router.push(`/types/${result.type.id}`);
    } catch (err) {
      setError((err as Error).message);
      setBusy(false);
    }
  };

  const filledSamples = samples.filter((s) => s.subject.trim() || s.body.trim()).length;

  return (
    <>
      <PageHeader
        title="Add an email type"
        description="A type is one kind of email your company receives, plus the reply you want sent for it."
        actions={
          <Link href="/types" className="btn-secondary btn-sm">
            Cancel
          </Link>
        }
      />

      <form onSubmit={submit} className="space-y-6">
        {error ? (
          <Notice kind="error" title="Could not save" onDismiss={() => setError(null)}>
            {error}
          </Notice>
        ) : null}

        <Card title="1. What is it?" description="How the agent will recognise this kind of email">
          <div className="space-y-4">
            <div>
              <label className="label" htmlFor="name">
                Name
              </label>
              <input
                id="name"
                className="input"
                placeholder="Order Status &amp; Delivery"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
                autoFocus
              />
            </div>

            <div>
              <label className="label" htmlFor="description">
                Description
              </label>
              <textarea
                id="description"
                className="input min-h-[100px]"
                placeholder="A customer who has already placed an order wants to know where it is: has it shipped, when will it arrive, why is it late. The order already exists and payment has gone through."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
              />
              <p className="hint">
                Write it as you would explain it to a new colleague. This is the main thing the AI
                reads when deciding, so saying what is <em>not</em> included is just as useful as
                saying what is.
              </p>
            </div>

            <div>
              <label className="label" htmlFor="keywords">
                Telltale words and phrases
              </label>
              <input
                id="keywords"
                className="input"
                placeholder="where is my order, tracking, not arrived, delivery date, courier"
                value={keywords}
                onChange={(e) => setKeywords(e.target.value)}
              />
              <p className="hint">
                Comma separated. These drive the offline matcher, which keeps the app working when no
                AI key is set or the model is unreachable. Phrases like &ldquo;where is my
                order&rdquo; count for more than single words.
              </p>
            </div>
          </div>
        </Card>

        <Card
          title="2. Example emails of this kind"
          description="The input drafts — real examples teach the agent far more than a description alone"
          actions={
            <button
              type="button"
              className="btn-secondary btn-sm"
              onClick={() => setSamples((s) => [...s, { subject: '', body: '' }])}
            >
              Add another
            </button>
          }
        >
          <div className="space-y-4">
            {samples.map((sample, index) => (
              <div key={index} className="rounded-lg border border-slate-200 p-4">
                <div className="mb-3 flex items-center justify-between">
                  <span className="text-xs font-semibold uppercase tracking-wide text-slate-500">
                    Example {index + 1}
                  </span>
                  {samples.length > 1 ? (
                    <button
                      type="button"
                      className="text-xs text-red-600 hover:underline"
                      onClick={() => setSamples((s) => s.filter((_, i) => i !== index))}
                    >
                      Remove
                    </button>
                  ) : null}
                </div>
                <input
                  className="input mb-2"
                  placeholder="Subject line, e.g. Where is my order 88213?"
                  value={sample.subject}
                  onChange={(e) => updateSample(index, { subject: e.target.value })}
                />
                <textarea
                  className="input min-h-[120px] font-mono text-[13px]"
                  placeholder="Paste a real email of this kind here…"
                  value={sample.body}
                  onChange={(e) => updateSample(index, { body: e.target.value })}
                />
              </div>
            ))}

            {filledSamples < 2 ? (
              <Notice kind="info">
                Two or three real examples make a noticeable difference. One is enough to start, and
                you can add more at any time — including automatically, every time someone resolves a
                flagged email as this type.
              </Notice>
            ) : null}
          </div>
        </Card>

        <Card
          title="3. The reply to send"
          description="The output draft — the approved wording the agent answers with"
        >
          <div className="space-y-4">
            <div>
              <label className="label" htmlFor="replySubject">
                Subject line
              </label>
              <input
                id="replySubject"
                className="input font-mono text-[13px]"
                value={replySubject}
                onChange={(e) => setReplySubject(e.target.value)}
              />
            </div>

            <div>
              <label className="label" htmlFor="replyBody">
                Reply body
              </label>
              <textarea
                id="replyBody"
                className="input min-h-[300px] font-mono text-[13px]"
                value={replyBody}
                onChange={(e) => setReplyBody(e.target.value)}
                required
              />
              <p className="hint">
                Placeholders the agent fills in for you: <code>{'{{customer_first_name}}'}</code>,{' '}
                <code>{'{{customer_name}}'}</code>, <code>{'{{customer_email}}'}</code>,{' '}
                <code>{'{{subject}}'}</code>, <code>{'{{order_id}}'}</code>,{' '}
                <code>{'{{invoice_id}}'}</code>, <code>{'{{tracking_id}}'}</code>,{' '}
                <code>{'{{company_name}}'}</code>, <code>{'{{signature}}'}</code>,{' '}
                <code>{'{{today}}'}</code>.
              </p>
              <p className="hint">
                You can invent your own too, such as <code>{'{{expected_date}}'}</code>. The agent
                will not guess at those — it leaves them highlighted in the draft and blocks sending
                until a person fills them in. That is deliberate: a made-up delivery date is worse
                than a visible gap.
              </p>
            </div>

            <div>
              <label className="label" htmlFor="replyGuidance">
                Anything the agent should be careful about
              </label>
              <input
                id="replyGuidance"
                className="input"
                placeholder="Never promise a delivery date that logistics has not confirmed."
                value={replyGuidance}
                onChange={(e) => setReplyGuidance(e.target.value)}
              />
              <p className="hint">Passed to the AI alongside the template, when an AI key is set.</p>
            </div>
          </div>
        </Card>

        <div className="flex flex-wrap gap-3">
          <button type="submit" className="btn-primary" disabled={busy || !name.trim()}>
            {busy ? 'Saving…' : 'Create this type'}
          </button>
          <Link href="/types" className="btn-secondary">
            Cancel
          </Link>
        </div>
      </form>
    </>
  );
}
