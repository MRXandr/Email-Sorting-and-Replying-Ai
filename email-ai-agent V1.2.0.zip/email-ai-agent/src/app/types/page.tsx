'use client';

import Link from 'next/link';
import { useCallback, useEffect, useState } from 'react';
import { Card, EmptyState, Notice, PageHeader, Spinner } from '@/components/ui';
import { apiGet } from '@/lib/client';
import type { EmailType } from '@/lib/types';

interface TypeRow extends EmailType {
  sampleCount: number;
  learnedSampleCount: number;
  replyExampleCount: number;
  classifiedCount: number;
}

export default function TypesPage() {
  const [types, setTypes] = useState<TypeRow[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await apiGet<{ types: TypeRow[] }>('/api/types?includeInactive=true');
      setTypes(data.types);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  return (
    <>
      <PageHeader
        title="Email types"
        description="Your categories. Each one holds example incoming emails, which are how the agent recognises the type, and a reply template, which is what it answers with."
        actions={
          <Link href="/types/new" className="btn-primary">
            Add a type
          </Link>
        }
      />

      <div className="space-y-6">
        {error ? (
          <Notice kind="error" onDismiss={() => setError(null)}>
            {error}
          </Notice>
        ) : null}

        {loading ? (
          <Card>
            <Spinner label="Loading types" />
          </Card>
        ) : types.length ? (
          <>
            <div className="grid gap-4 md:grid-cols-2">
              {types.map((type) => (
                <Link
                  key={type.id}
                  href={`/types/${type.id}`}
                  className="card card-pad transition-shadow hover:shadow-md"
                >
                  <div className="flex items-start justify-between gap-3">
                    <h2 className="text-sm font-semibold text-slate-900">{type.name}</h2>
                    {!type.active ? (
                      <span className="badge shrink-0 bg-slate-100 text-slate-500">off</span>
                    ) : null}
                  </div>

                  <p className="mt-1.5 line-clamp-3 text-xs leading-relaxed text-slate-600">
                    {type.description || 'No description yet — the AI relies on this, so it is worth adding.'}
                  </p>

                  <dl className="mt-4 flex flex-wrap gap-x-5 gap-y-1.5 text-xs text-slate-500">
                    <div className="flex gap-1.5">
                      <dt>Examples</dt>
                      <dd className="font-semibold tabular-nums text-slate-800">{type.sampleCount}</dd>
                    </div>
                    {type.learnedSampleCount > 0 ? (
                      <div className="flex gap-1.5" title="Added when someone corrected the agent">
                        <dt>Learned</dt>
                        <dd className="font-semibold tabular-nums text-indigo-700">
                          {type.learnedSampleCount}
                        </dd>
                      </div>
                    ) : null}
                    <div className="flex gap-1.5">
                      <dt>Keywords</dt>
                      <dd className="font-semibold tabular-nums text-slate-800">
                        {type.keywords.length}
                      </dd>
                    </div>
                    <div className="flex gap-1.5">
                      <dt>Sorted here</dt>
                      <dd className="font-semibold tabular-nums text-slate-800">
                        {type.classifiedCount}
                      </dd>
                    </div>
                  </dl>

                  {!type.replyBody?.trim() ? (
                    <p className="mt-3 rounded bg-amber-50 px-2 py-1.5 text-[11px] text-amber-800">
                      No reply template yet — emails sorted here will get an empty draft.
                    </p>
                  ) : null}
                </Link>
              ))}
            </div>

            <Notice kind="info" title="How the agent uses all this">
              <p>
                To decide <strong>which</strong> type an email is, it compares the new email against
                the example incoming emails and keywords you store here. To decide{' '}
                <strong>what to say</strong>, it works from that type&apos;s reply template.
              </p>
              <p className="mt-1.5">
                So the more real examples you add, the better it sorts. The clearer the reply
                template, the better the drafts.
              </p>
            </Notice>
          </>
        ) : (
          <Card>
            <EmptyState
              title="No email types yet"
              action={
                <Link href="/types/new" className="btn-primary btn-sm">
                  Add your first type
                </Link>
              }
            >
              Until at least one exists, every email will be flagged for a person. You can also load
              five ready-made types from the Dashboard to see how they are put together.
            </EmptyState>
          </Card>
        )}
      </div>
    </>
  );
}
