'use client';

import Link from 'next/link';
import { useParams, useRouter } from 'next/navigation';
import { useCallback, useEffect, useState } from 'react';
import {
  Card,
  ConfirmButton,
  Notice,
  PageHeader,
  Spinner,
  TextWithPlaceholders,
  TimeAgo,
} from '@/components/ui';
import { apiDelete, apiGet, apiPatch, apiPost } from '@/lib/client';
import type { EmailType, ReplyExample, TypeSample } from '@/lib/types';

interface TypeDetailResponse {
  type: EmailType;
  samples: TypeSample[];
  replyExamples: ReplyExample[];
  classifiedCount: number;
}

export default function TypeDetailPage() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const id = params.id;

  const [data, setData] = useState<TypeDetailResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);

  const [form, setForm] = useState({
    name: '',
    description: '',
    keywords: '',
    replySubject: '',
    replyBody: '',
    replyGuidance: '',
    active: true,
  });
  const [dirty, setDirty] = useState(false);

  const [newSample, setNewSample] = useState({ subject: '', body: '' });
  const [newReply, setNewReply] = useState({ subject: '', body: '' });

  const load = useCallback(async () => {
    setError(null);
    try {
      const detail = await apiGet<TypeDetailResponse>(`/api/types/${id}`);
      setData(detail);
      setForm({
        name: detail.type.name,
        description: detail.type.description,
        keywords: detail.type.keywords.join(', '),
        replySubject: detail.type.replySubject,
        replyBody: detail.type.replyBody,
        replyGuidance: detail.type.replyGuidance,
        active: detail.type.active,
      });
      setDirty(false);
    } catch (err) {
      setError((err as Error).message);
    }
  }, [id]);

  useEffect(() => {
    void load();
  }, [load]);

  const update = (patch: Partial<typeof form>) => {
    setForm((current) => ({ ...current, ...patch }));
    setDirty(true);
  };

  const save = async () => {
    setBusy('save');
    setError(null);
    setNotice(null);
    try {
      await apiPatch(`/api/types/${id}`, form);
      setNotice('Saved. New emails will be judged against this straight away.');
      await load();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(null);
    }
  };

  const addSample = async () => {
    setBusy('sample');
    setError(null);
    try {
      await apiPost(`/api/types/${id}/samples`, newSample);
      setNewSample({ subject: '', body: '' });
      setNotice('Example added. The agent will use it from the next email onwards.');
      await load();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(null);
    }
  };

  const removeSample = async (sampleId: string) => {
    try {
      await apiDelete(`/api/types/${id}/samples/${sampleId}`);
      await load();
    } catch (err) {
      setError((err as Error).message);
    }
  };

  const addReplyExample = async () => {
    setBusy('reply');
    setError(null);
    try {
      await apiPost(`/api/types/${id}/reply-examples`, newReply);
      setNewReply({ subject: '', body: '' });
      setNotice('Example reply added.');
      await load();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(null);
    }
  };

  const removeReplyExample = async (exampleId: string) => {
    try {
      await apiDelete(`/api/types/${id}/reply-examples/${exampleId}`);
      await load();
    } catch (err) {
      setError((err as Error).message);
    }
  };

  const removeType = async () => {
    setBusy('delete');
    try {
      await apiDelete(`/api/types/${id}`);
      router.push('/types');
    } catch (err) {
      setError((err as Error).message);
      setBusy(null);
    }
  };

  if (error && !data) {
    return (
      <>
        <PageHeader title="Email type" />
        <Notice kind="error" title="Could not load this type">
          {error}{' '}
          <Link href="/types" className="font-medium underline">
            Back to types
          </Link>
        </Notice>
      </>
    );
  }

  if (!data) {
    return (
      <div className="py-20 text-center">
        <Spinner label="Loading the type" />
      </div>
    );
  }

  const learnedCount = data.samples.filter((s) => s.source === 'human_review').length;

  return (
    <>
      <PageHeader
        title={data.type.name}
        description={
          <>
            <code className="rounded bg-slate-100 px-1.5 py-0.5 text-xs">{data.type.slug}</code> ·{' '}
            {data.samples.length} example email{data.samples.length === 1 ? '' : 's'}
            {learnedCount > 0 ? ` (${learnedCount} learned from people)` : ''} ·{' '}
            {data.classifiedCount} email{data.classifiedCount === 1 ? '' : 's'} sorted here
          </>
        }
        actions={
          <>
            <Link href="/types" className="btn-secondary btn-sm">
              Back
            </Link>
            <button
              type="button"
              className="btn-primary btn-sm"
              onClick={() => void save()}
              disabled={busy !== null || !dirty}
            >
              {busy === 'save' ? 'Saving…' : dirty ? 'Save changes' : 'Saved'}
            </button>
            <ConfirmButton
              onConfirm={() => void removeType()}
              confirmLabel="Delete this type?"
              disabled={busy !== null}
            >
              Delete
            </ConfirmButton>
          </>
        }
      />

      <div className="space-y-6">
        {error ? (
          <Notice kind="error" onDismiss={() => setError(null)}>
            {error}
          </Notice>
        ) : null}
        {notice ? (
          <Notice kind="success" onDismiss={() => setNotice(null)}>
            {notice}
          </Notice>
        ) : null}
        {dirty ? <Notice kind="warning">You have unsaved changes.</Notice> : null}

        <Card title="How the agent recognises this type">
          <div className="space-y-4">
            <div>
              <label className="label" htmlFor="name">
                Name
              </label>
              <input
                id="name"
                className="input"
                value={form.name}
                onChange={(e) => update({ name: e.target.value })}
              />
            </div>

            <div>
              <label className="label" htmlFor="description">
                Description
              </label>
              <textarea
                id="description"
                className="input min-h-[110px]"
                value={form.description}
                onChange={(e) => update({ description: e.target.value })}
              />
              <p className="hint">The main thing the AI reads when deciding whether an email belongs here.</p>
            </div>

            <div>
              <label className="label" htmlFor="keywords">
                Telltale words and phrases
              </label>
              <textarea
                id="keywords"
                className="input min-h-[80px] font-mono text-[13px]"
                value={form.keywords}
                onChange={(e) => update({ keywords: e.target.value })}
              />
              <p className="hint">
                Comma separated. Used by the offline matcher. Phrases beat single words, and a word
                shorter than five letters only matches as a whole word, so &ldquo;vat&rdquo; will not
                fire on &ldquo;Vatican&rdquo;.
              </p>
            </div>

            <label className="flex items-center gap-2.5 text-sm text-slate-700">
              <input
                type="checkbox"
                className="h-4 w-4 rounded border-slate-300"
                checked={form.active}
                onChange={(e) => update({ active: e.target.checked })}
              />
              <span>
                Active
                <span className="ml-2 text-xs text-slate-500">
                  Turn off to stop matching against this type without deleting its examples.
                </span>
              </span>
            </label>
          </div>
        </Card>

        <Card
          title="The reply template"
          description="What the agent says to emails of this kind"
        >
          <div className="space-y-4">
            <div>
              <label className="label" htmlFor="replySubject">
                Subject line
              </label>
              <input
                id="replySubject"
                className="input font-mono text-[13px]"
                value={form.replySubject}
                onChange={(e) => update({ replySubject: e.target.value })}
              />
            </div>

            <div>
              <label className="label" htmlFor="replyBody">
                Reply body
              </label>
              <textarea
                id="replyBody"
                className="input min-h-[320px] font-mono text-[13px]"
                value={form.replyBody}
                onChange={(e) => update({ replyBody: e.target.value })}
              />
              <p className="hint">
                Available placeholders: <code>{'{{customer_first_name}}'}</code>,{' '}
                <code>{'{{customer_name}}'}</code>, <code>{'{{customer_email}}'}</code>,{' '}
                <code>{'{{subject}}'}</code>, <code>{'{{order_id}}'}</code>,{' '}
                <code>{'{{invoice_id}}'}</code>, <code>{'{{tracking_id}}'}</code>,{' '}
                <code>{'{{company_name}}'}</code>, <code>{'{{signature}}'}</code>,{' '}
                <code>{'{{today}}'}</code>. Any other placeholder you write is left for a person to
                fill in rather than guessed.
              </p>
            </div>

            <div>
              <label className="label" htmlFor="replyGuidance">
                Guidance for the AI
              </label>
              <textarea
                id="replyGuidance"
                className="input min-h-[70px]"
                value={form.replyGuidance}
                onChange={(e) => update({ replyGuidance: e.target.value })}
              />
            </div>

            {form.replyBody.trim() ? (
              <div>
                <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-500">
                  Preview, with placeholders highlighted
                </p>
                <div className="rounded-lg border border-slate-200 bg-slate-50 p-4">
                  <TextWithPlaceholders text={form.replyBody} />
                </div>
              </div>
            ) : null}
          </div>
        </Card>

        <Card
          title={`Example incoming emails (${data.samples.length})`}
          description="What the agent compares new mail against"
        >
          <div className="space-y-4">
            {data.samples.length ? (
              <ul className="space-y-3">
                {data.samples.map((sample) => (
                  <li key={sample.id} className="rounded-lg border border-slate-200 p-4">
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0 flex-1">
                        <p className="text-sm font-medium text-slate-900">
                          {sample.subject || '(no subject)'}
                        </p>
                        <p className="mt-0.5 flex items-center gap-2 text-xs text-slate-500">
                          {sample.source === 'human_review' ? (
                            <span
                              className="badge bg-indigo-100 text-indigo-800"
                              title="Added when someone resolved a flagged email as this type"
                            >
                              learned from a person
                            </span>
                          ) : (
                            <span className="badge bg-slate-100 text-slate-600">{sample.source}</span>
                          )}
                          <TimeAgo iso={sample.createdAt} />
                        </p>
                      </div>
                      <ConfirmButton
                        onConfirm={() => void removeSample(sample.id)}
                        className="btn-danger btn-sm shrink-0"
                      >
                        Remove
                      </ConfirmButton>
                    </div>
                    <div className="mt-3 max-h-40 overflow-y-auto rounded bg-slate-50 p-3">
                      <p className="email-body text-xs">{sample.body}</p>
                    </div>
                  </li>
                ))}
              </ul>
            ) : (
              <Notice kind="warning">
                No examples yet. The agent can still match on the description and keywords, but real
                examples are what make it reliable.
              </Notice>
            )}

            <div className="rounded-lg border border-dashed border-slate-300 p-4">
              <p className="mb-3 text-xs font-semibold uppercase tracking-wide text-slate-500">
                Add another example
              </p>
              <input
                className="input mb-2"
                placeholder="Subject line"
                value={newSample.subject}
                onChange={(e) => setNewSample((s) => ({ ...s, subject: e.target.value }))}
              />
              <textarea
                className="input min-h-[110px] font-mono text-[13px]"
                placeholder="Paste a real email of this kind…"
                value={newSample.body}
                onChange={(e) => setNewSample((s) => ({ ...s, body: e.target.value }))}
              />
              <button
                type="button"
                className="btn-secondary btn-sm mt-3"
                onClick={() => void addSample()}
                disabled={busy !== null || (!newSample.subject.trim() && !newSample.body.trim())}
              >
                {busy === 'sample' ? 'Adding…' : 'Add example'}
              </button>
            </div>
          </div>
        </Card>

        <Card
          title={`Extra example replies (${data.replyExamples.length})`}
          description="Optional. Shows the AI more of the tone you want, beyond the single template above."
        >
          <div className="space-y-4">
            {data.replyExamples.length ? (
              <ul className="space-y-3">
                {data.replyExamples.map((example) => (
                  <li key={example.id} className="rounded-lg border border-slate-200 p-4">
                    <div className="flex items-start justify-between gap-3">
                      <p className="min-w-0 flex-1 text-sm font-medium text-slate-900">
                        {example.subject || '(no subject)'}
                      </p>
                      <ConfirmButton
                        onConfirm={() => void removeReplyExample(example.id)}
                        className="btn-danger btn-sm shrink-0"
                      >
                        Remove
                      </ConfirmButton>
                    </div>
                    <div className="mt-3 max-h-40 overflow-y-auto rounded bg-slate-50 p-3">
                      <p className="email-body text-xs">{example.body}</p>
                    </div>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-sm text-slate-500">
                None yet. The template above is used on its own, which is usually enough.
              </p>
            )}

            <div className="rounded-lg border border-dashed border-slate-300 p-4">
              <p className="mb-3 text-xs font-semibold uppercase tracking-wide text-slate-500">
                Add an example reply
              </p>
              <input
                className="input mb-2"
                placeholder="Subject line"
                value={newReply.subject}
                onChange={(e) => setNewReply((s) => ({ ...s, subject: e.target.value }))}
              />
              <textarea
                className="input min-h-[110px] font-mono text-[13px]"
                placeholder="Paste a reply your team actually sent and were happy with…"
                value={newReply.body}
                onChange={(e) => setNewReply((s) => ({ ...s, body: e.target.value }))}
              />
              <button
                type="button"
                className="btn-secondary btn-sm mt-3"
                onClick={() => void addReplyExample()}
                disabled={busy !== null || !newReply.body.trim()}
              >
                {busy === 'reply' ? 'Adding…' : 'Add example reply'}
              </button>
            </div>
          </div>
        </Card>
      </div>
    </>
  );
}
