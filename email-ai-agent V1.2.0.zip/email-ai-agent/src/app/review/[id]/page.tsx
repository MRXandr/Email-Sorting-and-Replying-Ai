'use client';

import Link from 'next/link';
import { useParams } from 'next/navigation';
import { useCallback, useEffect, useState } from 'react';
import {
  Card,
  MethodBadge,
  Notice,
  PageHeader,
  ScoreBar,
  Spinner,
  StatusBadge,
  TextWithPlaceholders,
  TimeAgo,
} from '@/components/ui';
import { apiGet, apiPost } from '@/lib/client';
import type { Classification, Draft, EmailRecord, EmailType, ReviewItem } from '@/lib/types';

interface ReviewDetailResponse {
  review: ReviewItem;
  email: EmailRecord | null;
  classification: Classification | null;
  draft: Draft | null;
  resolvedType: EmailType | null;
  availableTypes: Array<{ id: string; name: string; slug: string; description: string }>;
}

const DEFAULT_REPLY_TEMPLATE = `Hi {{customer_first_name}},

Thank you for getting in touch with {{company_name}}.

[Write what should be said to everyone who sends this kind of email.]

Best regards,
{{signature}}`;

export default function ReviewDetailPage() {
  const params = useParams<{ id: string }>();
  const id = params.id;

  const [data, setData] = useState<ReviewDetailResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const [mode, setMode] = useState<'existing' | 'new'>('existing');
  const [reviewer, setReviewer] = useState('');
  const [notes, setNotes] = useState('');
  const [learn, setLearn] = useState(true);

  const [existingTypeId, setExistingTypeId] = useState('');

  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [keywords, setKeywords] = useState('');
  const [replySubject, setReplySubject] = useState('Re: {{subject}}');
  const [replyBody, setReplyBody] = useState(DEFAULT_REPLY_TEMPLATE);
  const [replyGuidance, setReplyGuidance] = useState('');

  const load = useCallback(async () => {
    setError(null);
    try {
      const detail = await apiGet<ReviewDetailResponse>(`/api/review/${id}`);
      setData(detail);
      // Pre-select the agent's best guess: usually right, and one click to accept.
      if (!existingTypeId) {
        const best = detail.review.topScores[0]?.typeId;
        setExistingTypeId(best && detail.availableTypes.some((t) => t.id === best) ? best : detail.availableTypes[0]?.id ?? '');
      }
    } catch (err) {
      setError((err as Error).message);
    }
    // existingTypeId intentionally omitted: we only want the initial default.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  useEffect(() => {
    void load();
  }, [load]);

  const resolve = async (event: React.FormEvent) => {
    event.preventDefault();
    setBusy(true);
    setError(null);
    setSuccess(null);

    try {
      const payload =
        mode === 'existing'
          ? { mode, typeId: existingTypeId, resolvedBy: reviewer, notes, learn }
          : {
              mode,
              name,
              description,
              keywords,
              replySubject,
              replyBody,
              replyGuidance,
              resolvedBy: reviewer,
              notes,
              learn,
            };

      const result = await apiPost<{ message: string }>(`/api/review/${id}/resolve`, payload);
      setSuccess(result.message);
      await load();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  };

  if (error && !data) {
    return (
      <>
        <PageHeader title="Review" />
        <Notice kind="error" title="Could not load this item">
          {error}{' '}
          <Link href="/review" className="font-medium underline">
            Back to the queue
          </Link>
        </Notice>
      </>
    );
  }

  if (!data) {
    return (
      <div className="py-20 text-center">
        <Spinner label="Loading the review item" />
      </div>
    );
  }

  const { review, email, classification, draft, resolvedType, availableTypes } = data;
  const isResolved = review.status === 'resolved';

  return (
    <>
      <PageHeader
        title="What kind of email is this?"
        description="The agent could not place it. Your answer both handles this email and teaches the agent for next time."
        actions={
          <>
            <Link href="/review" className="btn-secondary btn-sm">
              Back to queue
            </Link>
            <a href={`/api/review/${id}/file`} className="btn-secondary btn-sm" download>
              Download the file
            </a>
            <StatusBadge status={review.status} />
          </>
        }
      />

      <div className="space-y-6">
        {error ? (
          <Notice kind="error" onDismiss={() => setError(null)}>
            {error}
          </Notice>
        ) : null}

        {success ? (
          <Notice kind="success" title="Done">
            {success}
            {email ? (
              <>
                {' '}
                <Link href={`/inbox/${email.id}`} className="font-medium underline">
                  See the drafted reply
                </Link>
              </>
            ) : null}
          </Notice>
        ) : null}

        <Notice kind={isResolved ? 'info' : 'warning'} title="Why this reached you">
          {review.reason}
          {review.alertError && !isResolved ? (
            <span className="mt-1.5 block text-xs">
              The alert email was not sent: {review.alertError}
            </span>
          ) : null}
          {review.alertSentAt ? (
            <span className="mt-1.5 block text-xs">
              The team was emailed <TimeAgo iso={review.alertSentAt} />, with the full email attached
              as a file.
            </span>
          ) : null}
        </Notice>

        <div className="grid gap-6 lg:grid-cols-2">
          <Card
            title="The email"
            description={
              email ? (
                <>
                  {email.fromName ? `${email.fromName} · ` : ''}
                  {email.fromEmail} · <TimeAgo iso={email.receivedAt} />
                </>
              ) : undefined
            }
          >
            {email ? (
              <>
                <p className="mb-3 text-sm font-semibold text-slate-900">
                  {email.subject || '(no subject)'}
                </p>
                <div className="max-h-[420px] overflow-y-auto rounded-lg bg-slate-50 p-4">
                  <TextWithPlaceholders text={email.body || '(no body text)'} />
                </div>
              </>
            ) : (
              <p className="text-sm text-slate-500">The email record is missing.</p>
            )}
          </Card>

          <Card
            title="What the agent thought"
            actions={<MethodBadge method={classification?.method ?? null} />}
          >
            {classification ? (
              <p className="mb-4 text-sm leading-relaxed text-slate-700">{classification.reasoning}</p>
            ) : null}

            {review.topScores.length ? (
              <>
                <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-500">
                  Closest existing types
                </p>
                <ul className="space-y-2.5">
                  {review.topScores.map((score) => (
                    <li key={score.typeId}>
                      <div className="flex items-center justify-between gap-3">
                        <span className="min-w-0 flex-1 truncate text-xs text-slate-600">
                          {score.typeName}
                        </span>
                        <ScoreBar score={score.score} />
                      </div>
                      {score.matchedKeywords?.length ? (
                        <p className="mt-0.5 truncate text-[11px] text-slate-400">
                          matched: {score.matchedKeywords.slice(0, 5).join(', ')}
                        </p>
                      ) : null}
                    </li>
                  ))}
                </ul>
                <p className="hint">
                  None of these scored high enough to act on, which is why it stopped and asked.
                </p>
              </>
            ) : (
              <p className="text-sm text-slate-500">No type came close enough to list.</p>
            )}
          </Card>
        </div>

        {isResolved ? (
          <Card title="How this was resolved">
            <dl className="grid gap-3 text-sm sm:grid-cols-2">
              <div>
                <dt className="text-xs uppercase tracking-wide text-slate-500">Filed under</dt>
                <dd className="mt-0.5 font-medium text-slate-900">
                  {resolvedType ? (
                    <Link href={`/types/${resolvedType.id}`} className="underline">
                      {resolvedType.name}
                    </Link>
                  ) : (
                    '—'
                  )}
                  {review.resolution === 'new_type' ? (
                    <span className="badge ml-2 bg-indigo-100 text-indigo-800">newly created</span>
                  ) : null}
                </dd>
              </div>
              <div>
                <dt className="text-xs uppercase tracking-wide text-slate-500">Decided by</dt>
                <dd className="mt-0.5 text-slate-900">{review.resolvedBy || '—'}</dd>
              </div>
              <div>
                <dt className="text-xs uppercase tracking-wide text-slate-500">When</dt>
                <dd className="mt-0.5 text-slate-900">
                  {review.resolvedAt ? <TimeAgo iso={review.resolvedAt} /> : '—'}
                </dd>
              </div>
              {review.resolutionNotes ? (
                <div className="sm:col-span-2">
                  <dt className="text-xs uppercase tracking-wide text-slate-500">Notes</dt>
                  <dd className="mt-0.5 text-slate-900">{review.resolutionNotes}</dd>
                </div>
              ) : null}
            </dl>

            {draft ? (
              <div className="mt-5 border-t border-slate-100 pt-5">
                <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-500">
                  The reply that was drafted
                </p>
                <div className="rounded-lg border border-slate-200 p-4">
                  <p className="mb-2 text-xs text-slate-500">Subject: {draft.subject}</p>
                  <TextWithPlaceholders text={draft.body} />
                </div>
                {email ? (
                  <Link href={`/inbox/${email.id}`} className="btn-secondary btn-sm mt-3">
                    Open it to edit or send
                  </Link>
                ) : null}
              </div>
            ) : null}
          </Card>
        ) : (
          <Card
            title="Your decision"
            description="Choose one of the two options below"
          >
            <form onSubmit={resolve} className="space-y-5">
              <div className="grid gap-3 sm:grid-cols-2">
                <ModeOption
                  selected={mode === 'existing'}
                  onSelect={() => setMode('existing')}
                  title="It is a type we already have"
                  body="Pick the right one. This email is stored as a new example for it, so emails like it are recognised automatically from now on."
                />
                <ModeOption
                  selected={mode === 'new'}
                  onSelect={() => setMode('new')}
                  title="It is a new kind of email"
                  body="Create a new type. You give it a name and the reply template to use, and this email becomes its first example."
                />
              </div>

              {mode === 'existing' ? (
                <div>
                  <label className="label" htmlFor="type">
                    Which type does it belong to?
                  </label>
                  {availableTypes.length ? (
                    <>
                      <select
                        id="type"
                        className="input"
                        value={existingTypeId}
                        onChange={(e) => setExistingTypeId(e.target.value)}
                        required
                      >
                        {availableTypes.map((type) => (
                          <option key={type.id} value={type.id}>
                            {type.name}
                          </option>
                        ))}
                      </select>
                      {availableTypes.find((t) => t.id === existingTypeId)?.description ? (
                        <p className="hint">
                          {availableTypes.find((t) => t.id === existingTypeId)?.description}
                        </p>
                      ) : null}
                    </>
                  ) : (
                    <Notice kind="warning">
                      There are no types to choose from yet. Use the other option to create the first
                      one.
                    </Notice>
                  )}
                </div>
              ) : (
                <div className="space-y-4 rounded-lg border border-slate-200 bg-slate-50 p-4">
                  <div>
                    <label className="label" htmlFor="name">
                      Name for this new type
                    </label>
                    <input
                      id="name"
                      className="input"
                      placeholder="Supplier &amp; Partnership Enquiry"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      required
                    />
                  </div>

                  <div>
                    <label className="label" htmlFor="description">
                      What belongs in it?
                    </label>
                    <textarea
                      id="description"
                      className="input min-h-[80px]"
                      placeholder="A business contacting us to sell us something or propose a partnership: suppliers, manufacturers, wholesale offers, reseller proposals."
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                    />
                    <p className="hint">
                      Write it as you would explain it to a new colleague. This is the main thing the
                      AI reads when deciding whether a future email belongs here, so being specific
                      about what is <em>not</em> included helps too.
                    </p>
                  </div>

                  <div>
                    <label className="label" htmlFor="keywords">
                      Telltale words and phrases
                    </label>
                    <input
                      id="keywords"
                      className="input"
                      placeholder="wholesale, partnership, rate card, minimum order quantity"
                      value={keywords}
                      onChange={(e) => setKeywords(e.target.value)}
                    />
                    <p className="hint">
                      Comma separated. Used by the offline matcher, which is what keeps things working
                      if the AI is unavailable. Multi-word phrases are stronger signals than single
                      words.
                    </p>
                  </div>

                  <div>
                    <label className="label" htmlFor="replySubject">
                      Reply subject line
                    </label>
                    <input
                      id="replySubject"
                      className="input font-mono text-[13px]"
                      value={replySubject}
                      onChange={(e) => setReplySubject(e.target.value)}
                    />
                  </div>

                  <div>
                    <label className="label" htmlFor="replyBody">
                      Reply template — what should be said to emails of this kind
                    </label>
                    <textarea
                      id="replyBody"
                      className="input min-h-[240px] font-mono text-[13px]"
                      value={replyBody}
                      onChange={(e) => setReplyBody(e.target.value)}
                      required
                    />
                    <p className="hint">
                      This is the important one — it is the approved wording the agent works from.
                      You can use{' '}
                      <code>{'{{customer_first_name}}'}</code>, <code>{'{{customer_name}}'}</code>,{' '}
                      <code>{'{{subject}}'}</code>, <code>{'{{order_id}}'}</code>,{' '}
                      <code>{'{{invoice_id}}'}</code>, <code>{'{{company_name}}'}</code>,{' '}
                      <code>{'{{signature}}'}</code> and <code>{'{{today}}'}</code>. Invent your own
                      too: anything the agent cannot fill is left visible in the draft for a person to
                      complete rather than guessed at.
                    </p>
                  </div>

                  <div>
                    <label className="label" htmlFor="replyGuidance">
                      Anything the agent should be careful about
                    </label>
                    <input
                      id="replyGuidance"
                      className="input"
                      placeholder="Polite but non-committal. Never agree to pricing or volumes."
                      value={replyGuidance}
                      onChange={(e) => setReplyGuidance(e.target.value)}
                    />
                  </div>
                </div>
              )}

              <div className="grid gap-4 border-t border-slate-100 pt-4 sm:grid-cols-2">
                <div>
                  <label className="label" htmlFor="reviewer">
                    Your name
                  </label>
                  <input
                    id="reviewer"
                    className="input"
                    placeholder="So the record shows who decided"
                    value={reviewer}
                    onChange={(e) => setReviewer(e.target.value)}
                  />
                </div>
                <div>
                  <label className="label" htmlFor="notes">
                    Note (optional)
                  </label>
                  <input
                    id="notes"
                    className="input"
                    placeholder="Why this was the right call"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                  />
                </div>
              </div>

              <label className="flex items-start gap-2.5 text-sm text-slate-700">
                <input
                  type="checkbox"
                  className="mt-0.5 h-4 w-4 rounded border-slate-300"
                  checked={learn}
                  onChange={(e) => setLearn(e.target.checked)}
                />
                <span>
                  Remember this email as an example for that type
                  <span className="mt-0.5 block text-xs text-slate-500">
                    Leave this on — it is what makes the agent handle the next email like this one by
                    itself. Turn it off only for a one-off you would not want it to learn from.
                  </span>
                </span>
              </label>

              <div className="flex flex-wrap gap-2 border-t border-slate-100 pt-4">
                <button
                  type="submit"
                  className="btn-primary"
                  disabled={busy || (mode === 'existing' && !existingTypeId)}
                >
                  {busy
                    ? 'Saving…'
                    : mode === 'existing'
                      ? 'File it and draft the reply'
                      : 'Create the type and draft the reply'}
                </button>
              </div>
            </form>
          </Card>
        )}
      </div>
    </>
  );
}

function ModeOption({
  selected,
  onSelect,
  title,
  body,
}: {
  selected: boolean;
  onSelect: () => void;
  title: string;
  body: string;
}) {
  return (
    <button
      type="button"
      onClick={onSelect}
      className={`rounded-lg border p-4 text-left transition-colors ${
        selected ? 'border-brand-500 bg-brand-50 ring-1 ring-brand-500' : 'border-slate-200 hover:bg-slate-50'
      }`}
    >
      <span className="flex items-center gap-2">
        <span
          className={`grid h-4 w-4 shrink-0 place-items-center rounded-full border ${
            selected ? 'border-brand-600 bg-brand-600' : 'border-slate-300'
          }`}
        >
          {selected ? <span className="h-1.5 w-1.5 rounded-full bg-white" /> : null}
        </span>
        <span className="text-sm font-semibold text-slate-900">{title}</span>
      </span>
      <span className="mt-1.5 block text-xs leading-relaxed text-slate-600">{body}</span>
    </button>
  );
}
