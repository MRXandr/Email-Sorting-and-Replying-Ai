'use client';

import Link from 'next/link';
import { useCallback, useEffect, useState } from 'react';
import { Card, EmptyState, Notice, PageHeader, Spinner, StatusBadge, TimeAgo } from '@/components/ui';
import { apiGet } from '@/lib/client';
import type { ReviewSummary } from '@/lib/detail';

interface ReviewListResponse {
  items: ReviewSummary[];
  openCount: number;
  availableTypes: Array<{ id: string; name: string; slug: string }>;
}

export default function ReviewQueuePage() {
  const [data, setData] = useState<ReviewListResponse | null>(null);
  const [status, setStatus] = useState<'open' | 'resolved'>('open');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      setData(await apiGet<ReviewListResponse>(`/api/review?status=${status}`));
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  }, [status]);

  useEffect(() => {
    void load();
  }, [load]);

  return (
    <>
      <PageHeader
        title="Human review"
        description="Emails the agent could not confidently place. Deciding one here also teaches the agent, so the next email like it is handled on its own."
        actions={
          <div className="flex rounded-lg border border-slate-300 p-0.5 text-xs">
            {(['open', 'resolved'] as const).map((option) => (
              <button
                key={option}
                type="button"
                onClick={() => setStatus(option)}
                className={`rounded px-3 py-1.5 font-medium capitalize ${
                  status === option ? 'bg-brand-600 text-white' : 'text-slate-600'
                }`}
              >
                {option}
                {option === 'open' && data?.openCount ? ` (${data.openCount})` : ''}
              </button>
            ))}
          </div>
        }
      />

      <div className="space-y-6">
        {error ? (
          <Notice kind="error" onDismiss={() => setError(null)}>
            {error}
          </Notice>
        ) : null}

        {!data?.availableTypes.length && !loading ? (
          <Notice kind="warning" title="No email types exist yet">
            Everything will be flagged until you define at least one type.{' '}
            <Link href="/types" className="font-medium underline">
              Add your types
            </Link>
          </Notice>
        ) : null}

        <Card>
          {loading ? (
            <Spinner label="Loading the queue" />
          ) : data?.items.length ? (
            <ul className="-mx-2 divide-y divide-slate-100">
              {data.items.map(({ review, email, resolvedTypeName }) => (
                <li key={review.id}>
                  <Link
                    href={`/review/${review.id}`}
                    className="block rounded-lg px-2 py-3.5 transition-colors hover:bg-slate-50"
                  >
                    <div className="flex flex-wrap items-start justify-between gap-3">
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-medium text-slate-900">
                          {email?.subject || '(no subject)'}
                        </p>
                        <p className="mt-0.5 truncate text-xs text-slate-500">
                          {email?.fromName ? `${email.fromName} · ` : ''}
                          {email?.fromEmail ?? 'unknown sender'} ·{' '}
                          <TimeAgo iso={review.createdAt} />
                        </p>
                        <p className="mt-1.5 line-clamp-2 text-xs leading-relaxed text-slate-600">
                          {review.reason}
                        </p>
                      </div>

                      <div className="flex shrink-0 flex-col items-end gap-1.5">
                        <StatusBadge status={review.status} />
                        {resolvedTypeName ? (
                          <span className="badge bg-brand-50 text-brand-700">{resolvedTypeName}</span>
                        ) : null}
                        {review.resolution === 'new_type' ? (
                          <span className="badge bg-indigo-100 text-indigo-800">new type created</span>
                        ) : null}
                        {review.status === 'open' && review.alertSentAt ? (
                          <span className="text-[11px] text-slate-400">team emailed</span>
                        ) : null}
                        {review.status === 'open' && review.alertError ? (
                          <span
                            className="text-[11px] text-amber-600"
                            title={review.alertError}
                          >
                            alert not sent
                          </span>
                        ) : null}
                      </div>
                    </div>

                    {review.topScores.length ? (
                      <p className="mt-2 text-[11px] text-slate-400">
                        Closest guesses:{' '}
                        {review.topScores
                          .slice(0, 3)
                          .map((s) => `${s.typeName} ${s.score.toFixed(2)}`)
                          .join(' · ')}
                      </p>
                    ) : null}
                  </Link>
                </li>
              ))}
            </ul>
          ) : (
            <EmptyState
              title={status === 'open' ? 'Nothing needs a person right now' : 'Nothing has been resolved yet'}
              action={
                status === 'open' ? (
                  <Link href="/inbox" className="btn-secondary btn-sm">
                    Process an email
                  </Link>
                ) : undefined
              }
            >
              {status === 'open'
                ? 'Every email so far has matched a known type. Anything the agent cannot place will appear here.'
                : 'Resolved items are kept as a record of what people decided and what the agent learned.'}
            </EmptyState>
          )}
        </Card>
      </div>
    </>
  );
}
