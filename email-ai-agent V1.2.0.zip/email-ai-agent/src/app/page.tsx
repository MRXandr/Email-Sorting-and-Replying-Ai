'use client';

import Link from 'next/link';
import { useCallback, useEffect, useState } from 'react';
import {
  Card,
  EmptyState,
  Notice,
  PageHeader,
  ScoreBar,
  Spinner,
  Stat,
  TimeAgo,
} from '@/components/ui';
import { apiGet, apiPost } from '@/lib/client';
import type { LogEntry, Settings, Stats } from '@/lib/types';

interface ConfigResponse {
  aiProvider: string;
  aiModel: string | null;
  aiReady: boolean;
  storage: string;
  storageWarning: string | null;
  imapConfigured: boolean;
  smtpConfigured: boolean;
  authEnabled: boolean;
  settings: Settings;
  stats: Stats;
  seeded: boolean;
  effectiveReviewEmail: string;
  reviewEmailFromEnv: boolean;
  storageError: string | null;
}

export default function DashboardPage() {
  const [config, setConfig] = useState<ConfigResponse | null>(null);
  const [log, setLog] = useState<LogEntry[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);

  const load = useCallback(async () => {
    setError(null);

    // These are fetched independently rather than with Promise.all. /api/config
    // is the one call that still succeeds when storage is unavailable, and it
    // carries the explanation this page needs to show. Bundling them meant a
    // failing /api/stats rejected both, so the user saw a bare error instead of
    // the panel telling them what to fix.
    let configData: ConfigResponse | null = null;
    try {
      configData = await apiGet<ConfigResponse>('/api/config');
      setConfig(configData);
    } catch (err) {
      setError((err as Error).message);
    }

    try {
      const statsData = await apiGet<{ log: LogEntry[] }>('/api/stats');
      setLog(statsData.log);
    } catch (err) {
      // Supplementary data. Only surface this if it is not already explained.
      if (!configData?.storageError) setError((err as Error).message);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const seed = async () => {
    setBusy('seed');
    setMessage(null);
    setError(null);
    try {
      const result = await apiPost<{ message: string }>('/api/seed', { confirm: true });
      setMessage(result.message);
      await load();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(null);
    }
  };

  const runDemo = async () => {
    setBusy('demo');
    setMessage(null);
    setError(null);
    try {
      const result = await apiPost<{ processed: number; classified: number; flagged: number }>(
        '/api/emails/demo',
        {},
      );
      setMessage(
        `Processed ${result.processed} demo emails: ${result.classified} matched a known type and ` +
          `${result.flagged} were flagged for a person to look at.`,
      );
      await load();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(null);
    }
  };

  if (!config && !error) {
    return (
      <div className="py-20 text-center">
        <Spinner label="Loading the dashboard" />
      </div>
    );
  }

  const stats = config?.stats;
  const settings = config?.settings;

  // Things that stop the app working properly, worst first. Suppressed entirely
  // when storage is unavailable, because every one of them would be a guess based
  // on data we could not read — and the storage panel above is the only thing
  // worth acting on.
  const setupIssues: Array<{ text: string; fix: string; href?: string }> = [];

  // All of these are suppressed when storage is unavailable: each would be a
  // guess based on data we could not read, and the error panel above is the only
  // thing worth acting on until a database exists.
  if (config && !config.storageError) {
    if (!config.seeded) {
      setupIssues.push({
        text: 'No email types are configured, so every email will be flagged.',
        fix: 'Load the demo company below, or add your own types.',
        href: '/types',
      });
    }
    if (config.storageWarning) {
      setupIssues.push({
        text: config.storageWarning,
        fix: 'Add a DATABASE_URL environment variable.',
      });
    }
    if (!config.aiReady) {
      setupIssues.push({
        text: 'No AI key is set, so the offline matcher and plain template filling are used.',
        fix: 'Everything works, but replies are less tailored. Add GEMINI_API_KEY to switch the model on.',
        href: '/settings',
      });
    }
    // Use the effective address, which includes the REVIEW_TEAM_EMAIL fallback —
    // otherwise this warns that nobody is emailed when in fact they are.
    if (!config.effectiveReviewEmail) {
      setupIssues.push({
        text: 'No review team address is set, so flagged emails are queued but nobody is emailed.',
        fix: 'Add one on the Settings page.',
        href: '/settings',
      });
    }
  }

  return (
    <>
      <PageHeader
        title="Dashboard"
        description="How the agent is sorting your mail, and what still needs a person."
        actions={
          <>
            <button type="button" className="btn-secondary" onClick={() => void load()}>
              Refresh
            </button>
            <Link href="/inbox" className="btn-primary">
              Process an email
            </Link>
          </>
        }
      />

      <div className="space-y-6">
        {config?.storageError ? (
          <Notice kind="error" title="This deployment needs a database before it can do anything">
            <p>{config.storageError}</p>
            <p className="mt-3 font-medium">To fix it:</p>
            <ol className="mt-1 list-decimal space-y-1 pl-5">
              <li>
                Create a free Postgres database at{' '}
                <a
                  href="https://neon.com"
                  target="_blank"
                  rel="noreferrer"
                  className="font-medium underline"
                >
                  neon.com
                </a>{' '}
                and copy its <strong>pooled</strong> connection string (the host contains{' '}
                <code>-pooler</code>).
              </li>
              <li>
                In Vercel, open your project → <strong>Settings</strong> →{' '}
                <strong>Environment Variables</strong>, and add{' '}
                <code>DATABASE_URL</code> with that value.
              </li>
              <li>
                Go to <strong>Deployments</strong>, click the ⋯ menu on the newest one, and choose{' '}
                <strong>Redeploy</strong>. Adding a variable does not affect the deployment already
                running.
              </li>
            </ol>
            <p className="mt-3">
              Full walkthrough in <code>docs/03-database.md</code>. Nothing is broken in the app
              itself — it simply has nowhere to store anything yet.
            </p>
          </Notice>
        ) : null}

        {error ? (
          <Notice kind="error" title="Something went wrong" onDismiss={() => setError(null)}>
            {error}
          </Notice>
        ) : null}

        {message ? (
          <Notice kind="success" onDismiss={() => setMessage(null)}>
            {message}
          </Notice>
        ) : null}

        {setupIssues.length ? (
          <Notice kind="warning" title="Worth setting up">
            <ul className="mt-1 space-y-2">
              {setupIssues.map((issue, i) => (
                <li key={i}>
                  <span className="font-medium">{issue.text}</span>{' '}
                  <span className="text-amber-800">{issue.fix}</span>{' '}
                  {issue.href ? (
                    <Link href={issue.href} className="font-medium underline">
                      Go there
                    </Link>
                  ) : null}
                </li>
              ))}
            </ul>
          </Notice>
        ) : null}

        {stats ? (
          <>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <Stat label="Emails processed" value={stats.totalEmails} />
              <Stat
                label="Sorted automatically"
                value={stats.classified + stats.resolved}
                tone="success"
                hint={`${stats.resolved} of those were settled by a person`}
              />
              <Stat
                label="Waiting for a person"
                value={stats.flaggedOpen}
                tone={stats.flaggedOpen > 0 ? 'warning' : 'default'}
                hint={stats.flaggedOpen > 0 ? 'Open the Review page' : 'Nothing outstanding'}
              />
              <Stat
                label="Learned from people"
                value={stats.learnedSampleCount}
                hint="Examples added when someone corrected the system"
              />
            </div>

            <div className="grid gap-6 lg:grid-cols-5">
              <Card
                className="lg:col-span-3"
                title="Where the mail is going"
                description={`${stats.typeCount} email types, trained on ${stats.sampleCount} example emails`}
                actions={
                  <Link href="/types" className="btn-secondary btn-sm">
                    Manage types
                  </Link>
                }
              >
                {stats.perType.length ? (
                  <ul className="space-y-3">
                    {stats.perType.map((row) => {
                      const total = stats.perType.reduce((sum, r) => sum + r.count, 0) || 1;
                      return (
                        <li key={row.typeId} className="flex items-center justify-between gap-4">
                          <Link
                            href={`/types/${row.typeId}`}
                            className="min-w-0 flex-1 truncate text-sm font-medium text-slate-700 hover:text-brand-700"
                          >
                            {row.typeName}
                          </Link>
                          <div className="flex shrink-0 items-center gap-3">
                            <ScoreBar
                              score={row.count / total}
                              highlight={row.count > 0}
                              showValue={false}
                            />
                            <span className="w-20 whitespace-nowrap text-right text-sm tabular-nums text-slate-600">
                              {row.count}
                              <span className="ml-1 text-xs text-slate-400">
                                {row.count === 1 ? 'email' : 'emails'}
                              </span>
                            </span>
                          </div>
                        </li>
                      );
                    })}
                  </ul>
                ) : (
                  <EmptyState title="No email types yet">
                    The agent needs to know your categories before it can sort anything.
                  </EmptyState>
                )}
              </Card>

              <Card className="lg:col-span-2" title="How it is set up">
                <dl className="space-y-3 text-sm">
                  <SetupRow
                    label="Model"
                    value={config.aiReady ? `${config.aiProvider} · ${config.aiModel}` : 'Offline matcher'}
                    ok={config.aiReady}
                    note={config.aiReady ? null : 'Works, but less accurate on unusual wording'}
                  />
                  <SetupRow
                    label="Storage"
                    value={config.storage === 'postgres' ? 'Postgres' : 'Local file'}
                    ok={config.storage === 'postgres'}
                    note={
                      config.storage === 'postgres'
                        ? null
                        : 'Fine locally; a hosted site needs Postgres'
                    }
                  />
                  <SetupRow
                    label="Reads mailbox"
                    value={config.imapConfigured ? 'Connected (IMAP)' : 'Not connected'}
                    ok={config.imapConfigured}
                    note={config.imapConfigured ? null : 'Paste or upload emails instead'}
                  />
                  <SetupRow
                    label="Sends email"
                    value={config.smtpConfigured ? 'Connected (SMTP)' : 'Not connected'}
                    ok={config.smtpConfigured}
                    note={config.smtpConfigured ? null : 'Drafts are created but cannot be sent'}
                  />
                  <SetupRow
                    label="Auto-send replies"
                    value={settings?.autoSendEnabled ? 'On' : 'Off — a person approves each one'}
                    ok={!settings?.autoSendEnabled}
                  />
                  <SetupRow
                    label="Password protected"
                    value={config.authEnabled ? 'Yes' : 'No — anyone with the link can open it'}
                    ok={config.authEnabled}
                  />
                </dl>
              </Card>
            </div>

            <div className="grid gap-6 lg:grid-cols-2">
              <Card
                title="Try it out"
                description="Built-in demo data, so you can see the whole loop without writing anything"
              >
                <div className="space-y-4">
                  <div>
                    <button
                      type="button"
                      className="btn-secondary"
                      onClick={() => void seed()}
                      disabled={busy !== null}
                    >
                      {busy === 'seed' ? 'Loading…' : '1. Load the demo company'}
                    </button>
                    <p className="hint">
                      Sets up five email types for a fictional retailer, each with example incoming
                      emails and an approved reply template.{' '}
                      <strong className="text-amber-700">This erases existing data.</strong>
                    </p>
                  </div>
                  <div>
                    <button
                      type="button"
                      className="btn-primary"
                      onClick={() => void runDemo()}
                      disabled={busy !== null || !config.seeded}
                    >
                      {busy === 'demo' ? 'Processing…' : '2. Run the seven demo emails'}
                    </button>
                    <p className="hint">
                      Five should match a type and get a drafted reply. Two are deliberately
                      unrelated — a supplier pitch and a job application — and should be flagged for
                      a person, which is what the Review page is for.
                    </p>
                  </div>
                </div>
              </Card>

              <Card title="Recent activity" description="The last dozen things the agent did">
                {log.length ? (
                  <ul className="divide-y divide-slate-100">
                    {log.map((entry) => (
                      <li key={entry.id} className="flex items-start gap-3 py-2.5 text-sm">
                        <span className={`mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full ${logColour(entry.kind)}`} />
                        <span className="min-w-0 flex-1 text-slate-700">{entry.message}</span>
                        <span className="shrink-0 text-xs text-slate-400">
                          <TimeAgo iso={entry.at} />
                        </span>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <EmptyState title="Nothing has happened yet">
                    Process an email and it will show up here.
                  </EmptyState>
                )}
              </Card>
            </div>
          </>
        ) : null}
      </div>
    </>
  );
}

function SetupRow({
  label,
  value,
  ok,
  note,
}: {
  label: string;
  value: string;
  ok: boolean;
  note?: string | null;
}) {
  return (
    <div className="flex items-start justify-between gap-3">
      <dt className="shrink-0 text-slate-500">{label}</dt>
      <dd className="text-right">
        <span className="flex items-center justify-end gap-1.5 font-medium text-slate-800">
          <span className={`h-2 w-2 rounded-full ${ok ? 'bg-emerald-500' : 'bg-amber-400'}`} />
          {value}
        </span>
        {note ? <span className="mt-0.5 block text-xs text-slate-500">{note}</span> : null}
      </dd>
    </div>
  );
}

function logColour(kind: string): string {
  if (kind === 'flagged') return 'bg-amber-400';
  if (kind.startsWith('learned')) return 'bg-indigo-500';
  if (kind === 'reply_sent') return 'bg-emerald-500';
  if (kind.includes('failed')) return 'bg-red-500';
  return 'bg-slate-300';
}
