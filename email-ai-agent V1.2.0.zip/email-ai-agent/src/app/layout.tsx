import type { Metadata } from 'next';
import './globals.css';
import { NavBar } from '@/components/nav-bar';

export const metadata: Metadata = {
  title: 'Email Triage Agent',
  description:
    'Sorts incoming email into learned categories, drafts a reply from the approved template for '
    + 'that category, and escalates anything it does not recognise to a person.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen">
        <NavBar />
        <main className="mx-auto w-full max-w-6xl px-4 py-8 sm:px-6">{children}</main>
        <footer className="mx-auto w-full max-w-6xl px-4 pb-10 pt-4 text-xs text-slate-400 sm:px-6">
          Email Triage Agent — replies are drafted for a person to approve, never sent without
          checking unless you explicitly turn that on.
        </footer>
      </body>
    </html>
  );
}
