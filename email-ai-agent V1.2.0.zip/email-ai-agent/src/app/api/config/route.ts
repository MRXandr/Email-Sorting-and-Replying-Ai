import { ok, route } from '@/lib/api';
import { publicConfigSummary, reviewTeamEmailDefault } from '@/lib/config';
import { getStore } from '@/lib/db';
import { resolveReviewEmail } from '@/lib/pipeline';
import { DEFAULT_SETTINGS } from '@/lib/db';
import type { Settings, Stats } from '@/lib/types';
import { nowIso } from '@/lib/util';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const EMPTY_STATS: Stats = {
  totalEmails: 0,
  classified: 0,
  flaggedOpen: 0,
  resolved: 0,
  typeCount: 0,
  sampleCount: 0,
  learnedSampleCount: 0,
  draftsSent: 0,
  perType: [],
};

/**
 * What the browser is allowed to know about how the server is set up.
 * Never includes an API key, password or connection string.
 *
 * This endpoint deliberately does NOT fail when storage is unavailable. It is
 * the first call every page makes, so if it errored the user would see a blank
 * screen with a raw message. Instead it returns `storageError`, which the UI
 * turns into an explanation of what to fix.
 */
export const GET = route(async () => {
  const summary = publicConfigSummary();

  let settings: Settings = { ...DEFAULT_SETTINGS, updatedAt: nowIso() };
  let stats: Stats = EMPTY_STATS;
  let storageError: string | null = null;

  try {
    const store = await getStore();
    [settings, stats] = await Promise.all([store.getSettings(), store.stats()]);
  } catch (err) {
    storageError = (err as Error).message;
    console.error('[config] storage unavailable:', storageError);
  }

  return ok({
    ...summary,
    settings,
    stats,
    seeded: stats.typeCount > 0,
    /**
     * Set when the app cannot reach its storage. Everything else in this
     * response is still valid, so the UI can render and explain the problem.
     */
    storageError,
    /**
     * The address alerts will actually go to: the saved setting, or the
     * REVIEW_TEAM_EMAIL environment variable when no setting has been saved.
     * The UI must use this rather than `settings.reviewTeamEmail`, or it warns
     * that nobody is being emailed when in fact they are.
     */
    effectiveReviewEmail: storageError ? '' : resolveReviewEmail(settings),
    reviewEmailFromEnv: !settings.reviewTeamEmail?.trim() && Boolean(reviewTeamEmailDefault()),
  });
});
