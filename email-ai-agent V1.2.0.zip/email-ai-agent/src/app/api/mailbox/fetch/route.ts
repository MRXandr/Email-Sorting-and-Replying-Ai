import { ok, parseNumber, route } from '@/lib/api';
import { imapConfig, imapConfigured } from '@/lib/config';
import { getStore } from '@/lib/db';
import { fetchNewMail } from '@/lib/mail/imap';
import { processEmail, type ProcessResult } from '@/lib/pipeline';
import { isValidEmail, truncate } from '@/lib/util';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
// IMAP connect + fetch + a model call per message. This is the slowest endpoint.
export const maxDuration = 60;

interface Outcome {
  subject: string;
  from: string;
  ok: boolean;
  flagged?: boolean;
  typeName?: string | null;
  duplicate?: boolean;
  error?: string;
}

/**
 * Pull unread mail from the configured mailbox and run each message through the
 * pipeline.
 *
 * A message is only marked read on the server after it has been processed
 * successfully, so nothing is silently lost if something goes wrong mid-run.
 */
export const POST = route(async (request: Request) => {
  if (!imapConfigured()) {
    return ok(
      {
        ok: false,
        error:
          'No mailbox is connected. Set IMAP_HOST, IMAP_USER and IMAP_PASSWORD to read real email. ' +
          'You can still paste or upload emails on the Inbox page.',
        configured: false,
      },
      400,
    );
  }

  const body = await request.json().catch(() => ({}) as { batchSize?: unknown });
  const batchSize = parseNumber(body.batchSize, 'batchSize', { min: 1, max: 25 });

  const store = await getStore();
  const outcomes: Outcome[] = [];

  const report = await fetchNewMail(
    async (message) => {
      const from = message.fromName
        ? `${message.fromName} <${message.fromEmail}>`
        : message.fromEmail;

      if (!isValidEmail(message.fromEmail)) {
        outcomes.push({
          subject: truncate(message.subject || '(no subject)', 90),
          from,
          ok: false,
          error: 'The sender address could not be read, so this message was left unread.',
        });
        // Not processed and not skipped → stays unread for a human to look at.
        return { processed: false };
      }

      try {
        const result: ProcessResult = await processEmail(store, {
          externalId: message.externalId,
          fromName: message.fromName,
          fromEmail: message.fromEmail,
          toEmail: message.toEmail,
          subject: message.subject,
          body: message.body,
          receivedAt: message.receivedAt,
          source: 'imap',
        });

        outcomes.push({
          subject: truncate(message.subject || '(no subject)', 90),
          from,
          ok: true,
          flagged: result.flagged,
          typeName: result.type?.name ?? null,
          duplicate: result.duplicate,
        });

        // A duplicate counts as "handled" so it gets marked read rather than
        // being fetched again forever.
        return { processed: !result.duplicate, skipped: result.duplicate };
      } catch (err) {
        outcomes.push({
          subject: truncate(message.subject || '(no subject)', 90),
          from,
          ok: false,
          error: (err as Error).message,
        });
        return { processed: false };
      }
    },
    batchSize ? { batchSize } : {},
  );

  if (report.ok) {
    await store.log(
      'mailbox_fetch',
      `Fetched ${report.fetched} message(s) from ${imapConfig().mailbox}`,
      { fetched: report.fetched, processed: report.processed, unseenTotal: report.unseenTotal },
    );
  }

  return ok(
    {
      ok: report.ok,
      configured: true,
      mailbox: imapConfig().mailbox,
      unseenTotal: report.unseenTotal,
      fetched: report.fetched,
      processed: report.processed,
      skipped: report.skipped,
      classified: outcomes.filter((o) => o.ok && !o.flagged && !o.duplicate).length,
      flagged: outcomes.filter((o) => o.ok && o.flagged).length,
      failed: outcomes.filter((o) => !o.ok).length,
      notes: report.notes,
      error: report.error,
      outcomes,
    },
    report.ok ? 200 : 502,
  );
});
