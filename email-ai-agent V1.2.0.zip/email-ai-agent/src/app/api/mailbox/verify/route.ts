import { ok, route } from '@/lib/api';
import { imapConfig, imapConfigured, smtpConfig, smtpConfigured } from '@/lib/config';
import { verifyImap } from '@/lib/mail/imap';
import { verifySmtp } from '@/lib/mail/smtp';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export const maxDuration = 60;

/**
 * Test the mailbox credentials without reading or sending anything.
 * This is the button to press first when email is not working — it separates
 * "wrong password" from "wrong port" from "not configured at all".
 */
export const POST = route(async () => {
  const [imap, smtp] = await Promise.all([
    imapConfigured() ? verifyImap() : Promise.resolve({ ok: false, error: 'Not configured.' }),
    smtpConfigured() ? verifySmtp() : Promise.resolve({ ok: false, error: 'Not configured.' }),
  ]);

  const imapCfg = imapConfig();
  const smtpCfg = smtpConfig();

  return ok({
    imap: {
      configured: imapConfigured(),
      ok: imap.ok,
      error: imap.error,
      // Echo the non-secret parts so a typo is easy to spot.
      host: imapCfg.host || null,
      port: imapCfg.port,
      secure: imapCfg.secure,
      user: imapCfg.user || null,
      mailbox: imapCfg.mailbox,
    },
    smtp: {
      configured: smtpConfigured(),
      ok: smtp.ok,
      error: smtp.error,
      host: smtpCfg.host || null,
      port: smtpCfg.port,
      secure: smtpCfg.secure,
      user: smtpCfg.user || null,
      from: smtpCfg.from || null,
    },
  });
});
