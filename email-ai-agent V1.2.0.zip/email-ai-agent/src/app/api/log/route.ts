import { ok, route } from '@/lib/api';
import { getStore } from '@/lib/db';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export const GET = route(async (request: Request) => {
  const limit = Number(new URL(request.url).searchParams.get('limit') ?? 50);
  const store = await getStore();
  return ok({ log: await store.listLog(Number.isFinite(limit) ? limit : 50) });
});
