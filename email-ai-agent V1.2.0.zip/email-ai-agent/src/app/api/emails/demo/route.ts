import { ok, route } from '@/lib/api';
import { getStore } from '@/lib/db';
import { processEmail, type ProcessResult } from '@/lib/pipeline';
import { SEED_INBOX } from '@/lib/seed';
import { parseAddress } from '@/lib/util';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export const maxDuration = 60;

/** The built-in demo emails, so the app can be tried without composing anything. */
export const GET = route(async () =>
  ok({
    samples: SEED_INBOX.map((sample, index) => ({
      index,
      from: sample.from,
      subject: sample.subject,
      body: sample.body,
      note: sample.note,
      expectFlag: Boolean(sample.expectFlag),
    })),
  }),
);

/**
 * Process the demo emails through the real pipeline.
 *
 * Five of them should match the seeded types; the last two should be flagged for
 * human review, which is what demonstrates the whole loop end to end.
 */
export const POST = route(async (request: Request) => {
  const body = await request
    .json()
    .catch(() => ({}) as { indexes?: number[]; onlyUnmatched?: boolean });

  const requested = Array.isArray(body.indexes) ? body.indexes : null;

  const chosen = SEED_INBOX.map((sample, index) => ({ sample, index })).filter(({ sample, index }) => {
    if (requested) return requested.includes(index);
    if (body.onlyUnmatched) return Boolean(sample.expectFlag);
    return true;
  });

  const store = await getStore();
  const results: Array<{ subject: string; note: string; result: ProcessResult }> = [];

  for (const { sample } of chosen) {
    const address = parseAddress(sample.from);
    const result = await processEmail(store, {
      fromName: address.name,
      fromEmail: address.email,
      subject: sample.subject,
      body: sample.body,
      source: 'seed',
    });
    results.push({ subject: sample.subject, note: sample.note, result });
  }

  return ok({
    processed: results.length,
    classified: results.filter((r) => !r.result.flagged).length,
    flagged: results.filter((r) => r.result.flagged).length,
    results,
  });
});
