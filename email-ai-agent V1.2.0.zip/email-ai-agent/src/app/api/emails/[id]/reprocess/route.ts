import { ok, parseBoolean, route } from '@/lib/api';
import { getStore } from '@/lib/db';
import { reprocessEmail } from '@/lib/pipeline';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export const maxDuration = 60;

type Ctx = { params: Promise<{ id: string }> };

/**
 * Run an email through classification and drafting again.
 *
 * Useful after teaching the system something: an email that was flagged before
 * may now match cleanly. The previous decision is kept as history.
 */
export const POST = route(async (request: Request, { params }: Ctx) => {
  const { id } = await params;
  const body = await request.json().catch(() => ({}) as { sendAlert?: unknown });

  const store = await getStore();
  const result = await reprocessEmail(store, id, {
    sendAlert: parseBoolean(body.sendAlert, 'sendAlert') ?? false,
  });

  return ok(result);
});
