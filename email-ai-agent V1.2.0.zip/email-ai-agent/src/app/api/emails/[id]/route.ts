import { ApiError, ok, route } from '@/lib/api';
import { getStore } from '@/lib/db';
import { getEmailDetail } from '@/lib/detail';
import { buildPlaceholderValues } from '@/lib/draft/templates';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

type Ctx = { params: Promise<{ id: string }> };

export const GET = route(async (_request: Request, { params }: Ctx) => {
  const { id } = await params;
  const store = await getStore();

  const detail = await getEmailDetail(store, id);
  if (!detail) throw new ApiError('That email does not exist.', 404);

  const settings = await store.getSettings();
  const types = await store.listTypes();

  return ok({
    ...detail,
    // Shown in the UI so you can see what the system extracted from the email.
    extracted: buildPlaceholderValues(detail.email, settings),
    availableTypes: types.map((t) => ({ id: t.id, name: t.name, slug: t.slug })),
  });
});

export const DELETE = route(async (_request: Request, { params }: Ctx) => {
  const { id } = await params;
  const store = await getStore();

  const email = await store.getEmail(id);
  if (!email) throw new ApiError('That email does not exist.', 404);

  await store.deleteEmail(id);
  await store.log('email_deleted', `Email "${email.subject}" deleted`, { emailId: id });

  return ok({ ok: true });
});
