import { ApiError, ok, route } from '@/lib/api';
import { getStore } from '@/lib/db';
import { parsePastedEmail } from '@/lib/mail/parse';
import { processEmail, type ProcessResult } from '@/lib/pipeline';
import { isValidEmail } from '@/lib/util';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export const maxDuration = 60;

const MAX_FILE_BYTES = 2 * 1024 * 1024;
const MAX_FILES = 10;

/**
 * Process one or more uploaded email files (.eml or .txt).
 *
 * Each file is handled independently so one unreadable file does not stop the
 * others, and the response reports per-file outcomes.
 */
export const POST = route(async (request: Request) => {
  const contentType = request.headers.get('content-type') ?? '';
  if (!contentType.includes('multipart/form-data')) {
    throw new ApiError('Send the files as multipart/form-data with a "files" field.', 415);
  }

  const form = await request.formData();
  const entries = form.getAll('files').filter((f): f is File => f instanceof File);

  if (!entries.length) throw new ApiError('No files were uploaded.', 400);
  if (entries.length > MAX_FILES) {
    throw new ApiError(`At most ${MAX_FILES} files at a time.`, 400);
  }

  const store = await getStore();
  const results: Array<{
    filename: string;
    ok: boolean;
    error?: string;
    result?: ProcessResult;
  }> = [];

  for (const file of entries) {
    const filename = file.name || 'upload';

    try {
      if (file.size > MAX_FILE_BYTES) {
        throw new ApiError(`"${filename}" is larger than 2 MB.`, 413);
      }
      if (file.size === 0) {
        throw new ApiError(`"${filename}" is empty.`, 400);
      }

      const text = await file.text();
      const parsed = await parsePastedEmail(text);

      if (!parsed.fromEmail || !isValidEmail(parsed.fromEmail)) {
        throw new ApiError(
          `"${filename}" has no usable sender address. A .eml file needs a From: header.`,
          400,
        );
      }

      const result = await processEmail(store, {
        fromName: parsed.fromName,
        fromEmail: parsed.fromEmail,
        toEmail: parsed.toEmail,
        subject: parsed.subject,
        body: parsed.body,
        receivedAt: parsed.receivedAt,
        externalId: parsed.externalId,
        source: 'upload',
      });

      results.push({ filename, ok: true, result });
    } catch (err) {
      results.push({ filename, ok: false, error: (err as Error).message });
    }
  }

  return ok({
    processed: results.filter((r) => r.ok).length,
    failed: results.filter((r) => !r.ok).length,
    results,
  });
});
