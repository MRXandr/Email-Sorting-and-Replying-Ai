import { ok, route } from '@/lib/api';
import { getStore } from '@/lib/db';
import { listEmailSummaries } from '@/lib/detail';
import type { EmailRecord } from '@/lib/types';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const VALID_STATUSES: EmailRecord['status'][] = ['classified', 'flagged', 'resolved'];

export const GET = route(async (request: Request) => {
  const params = new URL(request.url).searchParams;

  const statusParam = params.get('status');
  const status = VALID_STATUSES.includes(statusParam as EmailRecord['status'])
    ? (statusParam as EmailRecord['status'])
    : undefined;

  const limit = Number(params.get('limit') ?? 50);
  const offset = Number(params.get('offset') ?? 0);

  const store = await getStore();
  const { items, total } = await listEmailSummaries(store, {
    status,
    typeId: params.get('typeId') ?? undefined,
    search: params.get('search')?.trim() || undefined,
    limit: Number.isFinite(limit) ? limit : 50,
    offset: Number.isFinite(offset) ? offset : 0,
  });

  return ok({ items, total });
});
