import { ApiError, ok, optionalString, readJson, route } from '@/lib/api';
import { getStore } from '@/lib/db';
import { parsePastedEmail } from '@/lib/mail/parse';
import { processEmail } from '@/lib/pipeline';
import { isValidEmail, parseAddress } from '@/lib/util';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
// Classifying and drafting are two model calls; give them room.
export const maxDuration = 60;

/**
 * Run one email through the pipeline.
 *
 * Accepts either structured fields (`from`, `subject`, `body`) or a single `raw`
 * blob — a pasted email including its headers, or the contents of a .eml file.
 */
export const POST = route(async (request: Request) => {
  const body = await readJson<Record<string, unknown>>(request);

  const raw = optionalString(body.raw, 'raw', 500_000);
  const fromField = optionalString(body.from, 'from', 500);
  const subjectField = optionalString(body.subject, 'subject', 1000);
  const bodyField = optionalString(body.body, 'body', 200_000);

  let parsed: Awaited<ReturnType<typeof parsePastedEmail>>;

  if (raw?.trim()) {
    parsed = await parsePastedEmail(raw, { from: fromField, subject: subjectField });
  } else {
    if (!bodyField?.trim() && !subjectField?.trim()) {
      throw new ApiError('Provide either "raw", or a "subject" and "body".', 400);
    }
    const address = parseAddress(fromField ?? '');
    parsed = {
      externalId: null,
      fromName: address.name,
      fromEmail: address.email,
      toEmail: '',
      subject: subjectField ?? '',
      body: bodyField ?? '',
      receivedAt: new Date().toISOString(),
      messageId: null,
      references: null,
    };
  }

  if (!parsed.fromEmail) {
    throw new ApiError(
      'A sender email address is required — the reply has to go somewhere. Add a "From:" line or fill in the sender field.',
      400,
    );
  }
  if (!isValidEmail(parsed.fromEmail)) {
    throw new ApiError(`"${parsed.fromEmail}" is not a valid sender email address.`, 400);
  }

  const store = await getStore();
  const result = await processEmail(store, {
    fromName: parsed.fromName,
    fromEmail: parsed.fromEmail,
    toEmail: parsed.toEmail,
    subject: parsed.subject,
    body: parsed.body,
    receivedAt: parsed.receivedAt,
    externalId: parsed.externalId,
    source: raw?.trim() ? 'upload' : 'manual',
  });

  return ok(result, 201);
});
