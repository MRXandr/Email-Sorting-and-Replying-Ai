import { ok, route } from '@/lib/api';
import { getStore } from '@/lib/db';
import { listReviewSummaries } from '@/lib/detail';
import type { ReviewItem } from '@/lib/types';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export const GET = route(async (request: Request) => {
  const statusParam = new URL(request.url).searchParams.get('status');
  const status =
    statusParam === 'open' || statusParam === 'resolved' ? (statusParam as ReviewItem['status']) : undefined;

  const store = await getStore();
  const [items, types] = await Promise.all([listReviewSummaries(store, status), store.listTypes()]);

  return ok({
    items,
    openCount: (await store.listReviews('open')).length,
    // The resolve form needs the list of existing types to choose from.
    availableTypes: types.map((t) => ({ id: t.id, name: t.name, slug: t.slug })),
  });
});
