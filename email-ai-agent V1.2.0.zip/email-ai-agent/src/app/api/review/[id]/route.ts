import { ApiError, ok, route } from '@/lib/api';
import { getStore } from '@/lib/db';
import { getEmailDetail } from '@/lib/detail';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

type Ctx = { params: Promise<{ id: string }> };

/** One review item with its email, so the reviewer sees everything at once. */
export const GET = route(async (_request: Request, { params }: Ctx) => {
  const { id } = await params;
  const store = await getStore();

  const review = await store.getReview(id);
  if (!review) throw new ApiError('That review item does not exist.', 404);

  const [detail, types] = await Promise.all([
    getEmailDetail(store, review.emailId),
    store.listTypes(),
  ]);

  return ok({
    review,
    email: detail?.email ?? null,
    classification: detail?.classification ?? null,
    draft: detail?.draft ?? null,
    resolvedType: review.resolvedTypeId ? await store.getType(review.resolvedTypeId) : null,
    availableTypes: types.map((t) => ({
      id: t.id,
      name: t.name,
      slug: t.slug,
      description: t.description,
    })),
  });
});
