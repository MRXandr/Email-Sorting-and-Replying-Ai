import { ApiError, route } from '@/lib/api';
import { appBaseUrl } from '@/lib/config';
import { getStore } from '@/lib/db';
import { buildFlagFile } from '@/lib/flagfile';
import { NextResponse } from 'next/server';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

type Ctx = { params: Promise<{ id: string }> };

/**
 * Download the file describing a flagged email.
 *
 * Generated on demand from the stored records, so it is always current and there
 * is no blob to back up. The same content is attached to the alert email.
 */
export const GET = route(async (_request: Request, { params }: Ctx) => {
  const { id } = await params;
  const store = await getStore();

  const review = await store.getReview(id);
  if (!review) throw new ApiError('That review item does not exist.', 404);

  const email = await store.getEmail(review.emailId);
  if (!email) throw new ApiError('The email for this review item is missing.', 404);

  const [classification, settings] = await Promise.all([
    store.getClassificationForEmail(email.id),
    store.getSettings(),
  ]);

  const file = buildFlagFile({
    email,
    classification,
    review,
    settings,
    baseUrl: appBaseUrl(),
  });

  return new NextResponse(file.content, {
    status: 200,
    headers: {
      'content-type': 'text/plain; charset=utf-8',
      'content-disposition': `attachment; filename="${file.filename}"`,
      'cache-control': 'no-store',
    },
  });
});
