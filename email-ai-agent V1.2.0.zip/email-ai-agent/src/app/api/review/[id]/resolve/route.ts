import {
  ApiError,
  ok,
  optionalString,
  parseBoolean,
  parseKeywords,
  readJson,
  requireString,
  route,
} from '@/lib/api';
import { getStore } from '@/lib/db';
import { resolveReviewItem, type ResolvePayload } from '@/lib/pipeline';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export const maxDuration = 60;

type Ctx = { params: Promise<{ id: string }> };

interface Body {
  mode?: unknown;
  typeId?: unknown;
  name?: unknown;
  description?: unknown;
  keywords?: unknown;
  replySubject?: unknown;
  replyBody?: unknown;
  replyGuidance?: unknown;
  extraSamples?: unknown;
  replyExamples?: unknown;
  resolvedBy?: unknown;
  notes?: unknown;
  learn?: unknown;
}

function parseExamples(value: unknown, field: string): Array<{ subject: string; body: string }> {
  if (!Array.isArray(value)) return [];
  if (value.length > 50) throw new ApiError(`At most 50 entries in "${field}".`, 400);

  return value
    .map((raw) => {
      const item = raw as { subject?: unknown; body?: unknown };
      return {
        subject: optionalString(item.subject, `${field}[].subject`, 1000) ?? '',
        body: optionalString(item.body, `${field}[].body`, 50000) ?? '',
      };
    })
    .filter((item) => item.subject.trim() || item.body.trim());
}

/**
 * Apply a human decision to a flagged email — the step where the system learns.
 *
 * Two modes:
 *   {"mode":"existing","typeId":"..."}  → file it under a type we already have
 *   {"mode":"new","name":"...", ...}    → define a brand-new type, drafts included
 */
export const POST = route(async (request: Request, { params }: Ctx) => {
  const { id } = await params;
  const body = await readJson<Body>(request);
  const store = await getStore();

  const mode = body.mode;
  if (mode !== 'existing' && mode !== 'new') {
    throw new ApiError('"mode" must be either "existing" or "new".', 400);
  }

  const shared = {
    resolvedBy: optionalString(body.resolvedBy, 'resolvedBy', 200),
    notes: optionalString(body.notes, 'notes', 4000),
    learn: parseBoolean(body.learn, 'learn'),
  };

  let payload: ResolvePayload;

  if (mode === 'existing') {
    payload = {
      mode: 'existing',
      typeId: requireString(body.typeId, 'typeId', 100),
      ...shared,
    };
  } else {
    const replyBody = optionalString(body.replyBody, 'replyBody', 20000) ?? '';
    if (!replyBody.trim()) {
      throw new ApiError(
        'A new type needs a reply template ("replyBody"). That template is what the system uses ' +
          'to answer emails of this kind from now on.',
        400,
      );
    }

    payload = {
      mode: 'new',
      name: requireString(body.name, 'name', 200),
      description: optionalString(body.description, 'description', 4000),
      keywords: parseKeywords(body.keywords),
      replySubject: optionalString(body.replySubject, 'replySubject', 500) || 'Re: {{subject}}',
      replyBody,
      replyGuidance: optionalString(body.replyGuidance, 'replyGuidance', 4000),
      extraSamples: parseExamples(body.extraSamples, 'extraSamples'),
      replyExamples: parseExamples(body.replyExamples, 'replyExamples'),
      ...shared,
    };
  }

  const result = await resolveReviewItem(store, id, payload);

  return ok({
    ok: true,
    ...result,
    message:
      payload.mode === 'new'
        ? `Created the type "${result.resolvedType.name}" and drafted a reply. Emails like this one will be recognised automatically from now on.`
        : `Filed under "${result.resolvedType.name}"${result.learned ? ' and stored as a new example, so similar emails are recognised automatically from now on' : ''}.`,
  });
});
