import { ApiError, ok, optionalString, parseBoolean, parseNumber, readJson, route } from '@/lib/api';
import { getStore } from '@/lib/db';
import { isValidEmail } from '@/lib/util';
import type { Settings } from '@/lib/types';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export const GET = route(async () => {
  const store = await getStore();
  return ok({ settings: await store.getSettings() });
});

export const PATCH = route(async (request: Request) => {
  const body = await readJson<Record<string, unknown>>(request);
  const patch: Partial<Settings> = {};

  const companyName = optionalString(body.companyName, 'companyName', 200);
  if (companyName !== undefined) patch.companyName = companyName.trim();

  const signature = optionalString(body.supportSignature, 'supportSignature', 2000);
  if (signature !== undefined) patch.supportSignature = signature;

  const reviewEmail = optionalString(body.reviewTeamEmail, 'reviewTeamEmail', 254);
  if (reviewEmail !== undefined) {
    const trimmed = reviewEmail.trim();
    // An empty value is allowed: it means "no alert emails".
    if (trimmed && !isValidEmail(trimmed)) {
      throw new ApiError(`"${trimmed}" is not a valid email address.`, 400);
    }
    patch.reviewTeamEmail = trimmed;
  }

  const confidence = parseNumber(body.confidenceThreshold, 'confidenceThreshold', { min: 0, max: 1 });
  if (confidence !== undefined) patch.confidenceThreshold = confidence;

  const heuristic = parseNumber(body.heuristicThreshold, 'heuristicThreshold', { min: 0, max: 1 });
  if (heuristic !== undefined) patch.heuristicThreshold = heuristic;

  const margin = parseNumber(body.marginThreshold, 'marginThreshold', { min: 0, max: 1 });
  if (margin !== undefined) patch.marginThreshold = margin;

  const autoSend = parseBoolean(body.autoSendEnabled, 'autoSendEnabled');
  if (autoSend !== undefined) patch.autoSendEnabled = autoSend;

  if (!Object.keys(patch).length) throw new ApiError('Nothing to update.', 400);

  const store = await getStore();
  const settings = await store.saveSettings(patch);
  await store.log('settings', 'Settings updated', { fields: Object.keys(patch) });

  return ok({ ok: true, settings });
});
