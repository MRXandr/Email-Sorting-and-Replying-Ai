import { getStore } from '@/lib/db';
import { ok, route } from '@/lib/api';
import { publicConfigSummary } from '@/lib/config';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/**
 * Liveness check. Deliberately reachable without signing in, so you can confirm a
 * fresh deployment is up and see whether the database connected.
 */
export const GET = route(async () => {
  const config = publicConfigSummary();

  let database: { ok: boolean; kind: string; error: string | null };
  try {
    const store = await getStore();
    await store.stats();
    database = { ok: true, kind: store.kind, error: null };
  } catch (err) {
    database = { ok: false, kind: config.storage, error: (err as Error).message };
  }

  return ok(
    {
      status: database.ok ? 'ok' : 'degraded',
      time: new Date().toISOString(),
      database,
      ai: { provider: config.aiProvider, model: config.aiModel, ready: config.aiReady },
      mailbox: { imap: config.imapConfigured, smtp: config.smtpConfigured },
      authEnabled: config.authEnabled,
    },
    database.ok ? 200 : 503,
  );
});
