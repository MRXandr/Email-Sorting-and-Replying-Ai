import { ApiError, fail, ok, parseBoolean, route } from '@/lib/api';
import { getStore } from '@/lib/db';
import { sendMail } from '@/lib/mail/smtp';
import { isValidEmail, nowIso } from '@/lib/util';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export const maxDuration = 60;

type Ctx = { params: Promise<{ id: string }> };

/** Send an approved reply to the customer. */
export const POST = route(async (request: Request, { params }: Ctx) => {
  const { id } = await params;
  const body = await request.json().catch(() => ({}) as { force?: unknown });
  const force = parseBoolean(body.force, 'force') ?? false;

  const store = await getStore();

  const draft = await store.getDraft(id);
  if (!draft) throw new ApiError('That draft does not exist.', 404);
  if (draft.status === 'sent') {
    throw new ApiError('This reply has already been sent.', 409);
  }

  const email = await store.getEmail(draft.emailId);
  if (!email) throw new ApiError('The email this draft replies to is missing.', 404);

  if (!isValidEmail(email.fromEmail)) {
    throw new ApiError(
      `Cannot send: "${email.fromEmail}" is not a valid recipient address.`,
      400,
    );
  }

  // Refuse by default rather than mail a customer a literal "{{order_id}}".
  if (draft.unresolvedPlaceholders.length && !force) {
    return fail(
      `This draft still contains placeholders that nobody has filled in: ` +
        `${draft.unresolvedPlaceholders.map((p) => `{{${p}}}`).join(', ')}. ` +
        `Edit the reply first, or resend with {"force": true} if you really mean to.`,
      422,
      { unresolvedPlaceholders: draft.unresolvedPlaceholders },
    );
  }

  const result = await sendMail({
    to: email.fromEmail,
    subject: draft.subject,
    text: draft.body,
    // Thread the reply onto the original message where we know its Message-ID.
    inReplyTo: email.externalId?.startsWith('<') ? email.externalId : null,
    references: email.externalId?.startsWith('<') ? email.externalId : null,
  });

  const updated = await store.updateDraft(id, {
    status: result.ok ? 'sent' : draft.status,
    sentAt: result.ok ? nowIso() : null,
    sendError: result.error,
  });

  if (result.ok) {
    await store.log('reply_sent', `Reply sent to ${email.fromEmail}`, {
      emailId: email.id,
      draftId: id,
    });
    return ok({ ok: true, draft: updated, messageId: result.messageId });
  }

  await store.log('reply_send_failed', `Could not send reply to ${email.fromEmail}`, {
    emailId: email.id,
    draftId: id,
    error: result.error,
  });

  // 503 for "not configured / server unreachable", so the UI can distinguish it
  // from a bad request.
  return fail(result.error ?? 'The reply could not be sent.', result.skipped ? 503 : 502, {
    draft: updated,
  });
});
