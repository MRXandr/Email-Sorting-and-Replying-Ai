import { ApiError, ok, optionalString, readJson, route } from '@/lib/api';
import { getStore } from '@/lib/db';
import { findPlaceholders } from '@/lib/draft/templates';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

type Ctx = { params: Promise<{ id: string }> };

export const GET = route(async (_request: Request, { params }: Ctx) => {
  const { id } = await params;
  const store = await getStore();
  const draft = await store.getDraft(id);
  if (!draft) throw new ApiError('That draft does not exist.', 404);
  return ok({ draft });
});

/** Save edits a human made to a draft before sending it. */
export const PATCH = route(async (request: Request, { params }: Ctx) => {
  const { id } = await params;
  const body = await readJson<Record<string, unknown>>(request);
  const store = await getStore();

  const existing = await store.getDraft(id);
  if (!existing) throw new ApiError('That draft does not exist.', 404);
  if (existing.status === 'sent') {
    throw new ApiError('This reply has already been sent and cannot be edited.', 409);
  }

  const subject = optionalString(body.subject, 'subject', 1000);
  const draftBody = optionalString(body.body, 'body', 100_000);

  if (subject === undefined && draftBody === undefined) {
    throw new ApiError('Nothing to update.', 400);
  }

  const nextSubject = subject ?? existing.subject;
  const nextBody = draftBody ?? existing.body;

  const draft = await store.updateDraft(id, {
    subject: nextSubject,
    body: nextBody,
    status: 'edited',
    sendError: null,
    // Recomputed and stored, so filling a placeholder in really does clear the
    // warning rather than having it reappear on the next page load.
    unresolvedPlaceholders: findPlaceholders(`${nextSubject}\n${nextBody}`),
  });

  return ok({ ok: true, draft, unresolvedPlaceholders: draft.unresolvedPlaceholders });
});
