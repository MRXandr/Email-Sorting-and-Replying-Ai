import {
  ApiError,
  ok,
  optionalString,
  parseBoolean,
  parseKeywords,
  readJson,
  requireString,
  route,
} from '@/lib/api';
import { getStore } from '@/lib/db';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/** List every email type, with its input-draft and reply-example counts. */
export const GET = route(async (request: Request) => {
  const includeInactive = new URL(request.url).searchParams.get('includeInactive') === 'true';
  const store = await getStore();

  const [types, samples, replyExamples, stats] = await Promise.all([
    store.listTypes({ includeInactive }),
    store.listSamples(),
    store.listReplyExamples(),
    store.stats(),
  ]);

  const countBy = (rows: Array<{ typeId: string }>) => {
    const map = new Map<string, number>();
    for (const row of rows) map.set(row.typeId, (map.get(row.typeId) ?? 0) + 1);
    return map;
  };

  const sampleCounts = countBy(samples);
  const learnedCounts = countBy(samples.filter((s) => s.source === 'human_review'));
  const replyCounts = countBy(replyExamples);
  const classifiedCounts = new Map(stats.perType.map((p) => [p.typeId, p.count]));

  return ok({
    types: types.map((type) => ({
      ...type,
      sampleCount: sampleCounts.get(type.id) ?? 0,
      learnedSampleCount: learnedCounts.get(type.id) ?? 0,
      replyExampleCount: replyCounts.get(type.id) ?? 0,
      classifiedCount: classifiedCounts.get(type.id) ?? 0,
    })),
  });
});

/** Create a new email type, optionally with its input drafts in one go. */
export const POST = route(async (request: Request) => {
  const body = await readJson<Record<string, unknown>>(request);
  const store = await getStore();

  const name = requireString(body.name, 'name', 200).trim();

  const type = await store.createType({
    name,
    slug: optionalString(body.slug, 'slug', 80),
    description: optionalString(body.description, 'description', 4000) ?? '',
    keywords: parseKeywords(body.keywords) ?? [],
    replySubject: optionalString(body.replySubject, 'replySubject', 500) ?? 'Re: {{subject}}',
    replyBody: optionalString(body.replyBody, 'replyBody', 20000) ?? '',
    replyGuidance: optionalString(body.replyGuidance, 'replyGuidance', 4000) ?? '',
    active: parseBoolean(body.active, 'active') ?? true,
  });

  // Accept the example incoming emails alongside the type, so the UI can create
  // a fully-trained type in a single request.
  const samples = Array.isArray(body.samples) ? body.samples : [];
  if (samples.length > 100) throw new ApiError('At most 100 input drafts at a time.', 400);

  let sampleCount = 0;
  for (const raw of samples) {
    const sample = raw as { subject?: unknown; body?: unknown };
    const subject = optionalString(sample.subject, 'samples[].subject', 1000) ?? '';
    const sampleBody = optionalString(sample.body, 'samples[].body', 50000) ?? '';
    if (!subject.trim() && !sampleBody.trim()) continue;
    await store.addSample({ typeId: type.id, subject, body: sampleBody, source: 'manual' });
    sampleCount++;
  }

  const replyExamples = Array.isArray(body.replyExamples) ? body.replyExamples : [];
  for (const raw of replyExamples) {
    const example = raw as { subject?: unknown; body?: unknown };
    const subject = optionalString(example.subject, 'replyExamples[].subject', 1000) ?? '';
    const exampleBody = optionalString(example.body, 'replyExamples[].body', 50000) ?? '';
    if (!subject.trim() && !exampleBody.trim()) continue;
    await store.addReplyExample({ typeId: type.id, subject, body: exampleBody, source: 'manual' });
  }

  await store.log('type_created', `Email type "${type.name}" created`, {
    typeId: type.id,
    sampleCount,
  });

  return ok({ ok: true, type, sampleCount }, 201);
});
