import { ok, route } from '@/lib/api';
import { getStore } from '@/lib/db';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

type Ctx = { params: Promise<{ id: string; sampleId: string }> };

export const DELETE = route(async (_request: Request, { params }: Ctx) => {
  const { sampleId } = await params;
  const store = await getStore();
  await store.deleteSample(sampleId);
  return ok({ ok: true });
});
