import { ApiError, ok, optionalString, readJson, route } from '@/lib/api';
import { getStore } from '@/lib/db';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

type Ctx = { params: Promise<{ id: string }> };

/** List the input drafts (example incoming emails) for one type. */
export const GET = route(async (_request: Request, { params }: Ctx) => {
  const { id } = await params;
  const store = await getStore();
  return ok({ samples: await store.listSamples(id) });
});

/** Add an input draft. This is how you teach a type by hand. */
export const POST = route(async (request: Request, { params }: Ctx) => {
  const { id } = await params;
  const body = await readJson<Record<string, unknown>>(request);
  const store = await getStore();

  const type = await store.getType(id);
  if (!type) throw new ApiError('That email type does not exist.', 404);

  const subject = optionalString(body.subject, 'subject', 1000) ?? '';
  const sampleBody = optionalString(body.body, 'body', 50000) ?? '';

  if (!subject.trim() && !sampleBody.trim()) {
    throw new ApiError('An example email needs a subject or a body.', 400);
  }

  const sample = await store.addSample({ typeId: id, subject, body: sampleBody, source: 'manual' });
  await store.log('sample_added', `Example email added to "${type.name}"`, { typeId: id });

  return ok({ ok: true, sample }, 201);
});
