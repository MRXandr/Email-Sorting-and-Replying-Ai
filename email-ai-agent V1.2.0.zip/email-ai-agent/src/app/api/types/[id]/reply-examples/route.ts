import { ApiError, ok, optionalString, readJson, route } from '@/lib/api';
import { getStore } from '@/lib/db';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

type Ctx = { params: Promise<{ id: string }> };

/** List the extra output drafts (example approved replies) for one type. */
export const GET = route(async (_request: Request, { params }: Ctx) => {
  const { id } = await params;
  const store = await getStore();
  return ok({ replyExamples: await store.listReplyExamples(id) });
});

export const POST = route(async (request: Request, { params }: Ctx) => {
  const { id } = await params;
  const body = await readJson<Record<string, unknown>>(request);
  const store = await getStore();

  const type = await store.getType(id);
  if (!type) throw new ApiError('That email type does not exist.', 404);

  const subject = optionalString(body.subject, 'subject', 1000) ?? '';
  const exampleBody = optionalString(body.body, 'body', 50000) ?? '';

  if (!exampleBody.trim()) throw new ApiError('An example reply needs a body.', 400);

  const replyExample = await store.addReplyExample({
    typeId: id,
    subject,
    body: exampleBody,
    source: 'manual',
  });
  await store.log('reply_example_added', `Example reply added to "${type.name}"`, { typeId: id });

  return ok({ ok: true, replyExample }, 201);
});
