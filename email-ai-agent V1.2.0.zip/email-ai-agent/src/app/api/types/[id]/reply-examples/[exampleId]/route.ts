import { ok, route } from '@/lib/api';
import { getStore } from '@/lib/db';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

type Ctx = { params: Promise<{ id: string; exampleId: string }> };

export const DELETE = route(async (_request: Request, { params }: Ctx) => {
  const { exampleId } = await params;
  const store = await getStore();
  await store.deleteReplyExample(exampleId);
  return ok({ ok: true });
});
