import {
  ApiError,
  ok,
  optionalString,
  parseBoolean,
  parseKeywords,
  readJson,
  route,
} from '@/lib/api';
import { getStore } from '@/lib/db';
import { getTypeDetail } from '@/lib/detail';
import type { NewEmailType } from '@/lib/types';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

type Ctx = { params: Promise<{ id: string }> };

export const GET = route(async (_request: Request, { params }: Ctx) => {
  const { id } = await params;
  const store = await getStore();
  const detail = await getTypeDetail(store, id);
  if (!detail) throw new ApiError('That email type does not exist.', 404);
  return ok(detail);
});

export const PATCH = route(async (request: Request, { params }: Ctx) => {
  const { id } = await params;
  const body = await readJson<Record<string, unknown>>(request);
  const store = await getStore();

  const existing = await store.getType(id);
  if (!existing) throw new ApiError('That email type does not exist.', 404);

  const patch: Partial<NewEmailType> = {};
  const name = optionalString(body.name, 'name', 200);
  if (name !== undefined) {
    if (!name.trim()) throw new ApiError('"name" cannot be empty.', 400);
    patch.name = name.trim();
  }

  const description = optionalString(body.description, 'description', 4000);
  if (description !== undefined) patch.description = description;

  const keywords = parseKeywords(body.keywords);
  if (keywords !== undefined) patch.keywords = keywords;

  const replySubject = optionalString(body.replySubject, 'replySubject', 500);
  if (replySubject !== undefined) patch.replySubject = replySubject;

  const replyBody = optionalString(body.replyBody, 'replyBody', 20000);
  if (replyBody !== undefined) patch.replyBody = replyBody;

  const replyGuidance = optionalString(body.replyGuidance, 'replyGuidance', 4000);
  if (replyGuidance !== undefined) patch.replyGuidance = replyGuidance;

  const active = parseBoolean(body.active, 'active');
  if (active !== undefined) patch.active = active;

  if (!Object.keys(patch).length) throw new ApiError('Nothing to update.', 400);

  const type = await store.updateType(id, patch);
  await store.log('type_updated', `Email type "${type.name}" updated`, {
    typeId: id,
    fields: Object.keys(patch),
  });

  return ok({ ok: true, type });
});

export const DELETE = route(async (_request: Request, { params }: Ctx) => {
  const { id } = await params;
  const store = await getStore();

  const existing = await store.getType(id);
  if (!existing) throw new ApiError('That email type does not exist.', 404);

  await store.deleteType(id);
  await store.log('type_deleted', `Email type "${existing.name}" deleted`, { typeId: id });

  return ok({ ok: true });
});
