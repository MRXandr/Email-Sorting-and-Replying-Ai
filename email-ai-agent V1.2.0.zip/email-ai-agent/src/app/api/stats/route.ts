import { ok, route } from '@/lib/api';
import { getStore } from '@/lib/db';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export const GET = route(async () => {
  const store = await getStore();
  const [stats, log] = await Promise.all([store.stats(), store.listLog(12)]);
  return ok({ stats, log });
});
