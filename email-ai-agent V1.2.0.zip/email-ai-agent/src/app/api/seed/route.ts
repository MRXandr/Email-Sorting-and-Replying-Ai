import { ok, parseBoolean, readJson, route } from '@/lib/api';
import { getStore } from '@/lib/db';
import { seedDatabase } from '@/lib/seed';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export const maxDuration = 60;

/**
 * Wipe everything and load the demo company with its five email types.
 *
 * Destructive by design — it is the "start over" button. The UI asks for
 * confirmation before calling it.
 */
export const POST = route(async (request: Request) => {
  const body = await readJson<{ confirm?: boolean }>(request).catch(() => ({}) as { confirm?: boolean });

  if (parseBoolean(body.confirm, 'confirm') !== true) {
    return ok(
      {
        error:
          'This replaces all current data. Send {"confirm": true} to go ahead.',
      },
      400,
    );
  }

  const store = await getStore();
  const result = await seedDatabase(store);

  return ok({
    ok: true,
    ...result,
    message: `Loaded ${result.typeCount} email types with ${result.sampleCount} example incoming emails.`,
  });
});
