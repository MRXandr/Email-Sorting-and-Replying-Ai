import { fail, ok, readJson, route } from '@/lib/api';
import { safeEqual, SESSION_COOKIE, sessionToken } from '@/lib/auth';
import { authConfig, isProduction } from '@/lib/config';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export const POST = route(async (request: Request) => {
  const { password, secret } = authConfig();

  if (!password) {
    return ok({ ok: true, authEnabled: false, message: 'No password is configured; the app is open.' });
  }

  const body = await readJson<{ password?: string }>(request);
  const supplied = String(body.password ?? '');

  // Compare in constant time, and pad so length alone does not leak.
  const suppliedToken = await sessionToken(supplied, secret);
  const expectedToken = await sessionToken(password, secret);

  if (!safeEqual(suppliedToken, expectedToken)) {
    return fail('That password is not correct.', 401);
  }

  const response = ok({ ok: true, authEnabled: true });
  response.cookies.set(SESSION_COOKIE, expectedToken, {
    httpOnly: true,
    sameSite: 'lax',
    secure: isProduction(),
    path: '/',
    maxAge: 60 * 60 * 24 * 7,
  });
  return response;
});
