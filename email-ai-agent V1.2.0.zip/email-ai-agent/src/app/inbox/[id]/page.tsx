'use client';

import Link from 'next/link';
import { useParams, useRouter } from 'next/navigation';
import { useCallback, useEffect, useState } from 'react';
import {
  Card,
  ConfirmButton,
  MethodBadge,
  Notice,
  PageHeader,
  ScoreBar,
  Spinner,
  StatusBadge,
  TextWithPlaceholders,
  TimeAgo,
} from '@/components/ui';
import { apiDelete, apiGet, apiPatch, apiPost } from '@/lib/client';
import type { Classification, Draft, EmailRecord, EmailType, ReviewItem } from '@/lib/types';

interface DetailResponse {
  email: EmailRecord;
  classification: Classification | null;
  type: EmailType | null;
  draft: Draft | null;
  review: ReviewItem | null;
  extracted: Record<string, string>;
  availableTypes: Array<{ id: string; name: string; slug: string }>;
}

export default function EmailDetailPage() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const id = params.id;

  const [data, setData] = useState<DetailResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<{ kind: 'success' | 'warning'; text: string } | null>(null);
  const [busy, setBusy] = useState<string | null>(null);

  const [editing, setEditing] = useState(false);
  const [draftSubject, setDraftSubject] = useState('');
  const [draftBody, setDraftBody] = useState('');

  const load = useCallback(async () => {
    setError(null);
    try {
      const detail = await apiGet<DetailResponse>(`/api/emails/${id}`);
      setData(detail);
      setDraftSubject(detail.draft?.subject ?? '');
      setDraftBody(detail.draft?.body ?? '');
    } catch (err) {
      setError((err as Error).message);
    }
  }, [id]);

  useEffect(() => {
    void load();
  }, [load]);

  const saveDraft = async () => {
    if (!data?.draft) return;
    setBusy('save');
    setError(null);
    try {
      const result = await apiPatch<{ unresolvedPlaceholders: string[] }>(
        `/api/drafts/${data.draft.id}`,
        { subject: draftSubject, body: draftBody },
      );
      setEditing(false);
      setNotice({
        kind: result.unresolvedPlaceholders.length ? 'warning' : 'success',
        text: result.unresolvedPlaceholders.length
          ? `Saved, but there are still placeholders to fill: ${result.unresolvedPlaceholders
              .map((p) => `{{${p}}}`)
              .join(', ')}`
          : 'Saved. The reply is ready to send.',
      });
      await load();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(null);
    }
  };

  const send = async (force = false) => {
    if (!data?.draft) return;
    setBusy('send');
    setError(null);
    setNotice(null);
    try {
      await apiPost(`/api/drafts/${data.draft.id}/send`, { force });
      setNotice({ kind: 'success', text: `Reply sent to ${data.email.fromEmail}.` });
      await load();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(null);
    }
  };

  const reprocess = async () => {
    setBusy('reprocess');
    setError(null);
    setNotice(null);
    try {
      const result = await apiPost<{ flagged: boolean; type: EmailType | null }>(
        `/api/emails/${id}/reprocess`,
        {},
      );
      setNotice({
        kind: result.flagged ? 'warning' : 'success',
        text: result.flagged
          ? 'Reprocessed — it still does not match any type, so it is in the Review queue.'
          : `Reprocessed and sorted as "${result.type?.name}".`,
      });
      await load();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(null);
    }
  };

  const remove = async () => {
    setBusy('delete');
    try {
      await apiDelete(`/api/emails/${id}`);
      router.push('/inbox');
    } catch (err) {
      setError((err as Error).message);
      setBusy(null);
    }
  };

  if (error && !data) {
    return (
      <>
        <PageHeader title="Email" />
        <Notice kind="error" title="Could not load this email">
          {error}{' '}
          <Link href="/inbox" className="font-medium underline">
            Back to the inbox
          </Link>
        </Notice>
      </>
    );
  }

  if (!data) {
    return (
      <div className="py-20 text-center">
        <Spinner label="Loading the email" />
      </div>
    );
  }

  const { email, classification, type, draft, review, extracted } = data;
  const unresolved = draft?.unresolvedPlaceholders ?? [];
  const alreadySent = draft?.status === 'sent';

  return (
    <>
      <PageHeader
        title={email.subject || '(no subject)'}
        description={
          <>
            From <strong>{email.fromName || email.fromEmail}</strong> &lt;{email.fromEmail}&gt; ·{' '}
            <TimeAgo iso={email.receivedAt} /> · arrived via {sourceLabel(email.source)}
          </>
        }
        actions={
          <>
            <Link href="/inbox" className="btn-secondary btn-sm">
              Back
            </Link>
            <button
              type="button"
              className="btn-secondary btn-sm"
              onClick={() => void reprocess()}
              disabled={busy !== null}
            >
              {busy === 'reprocess' ? 'Working…' : 'Classify again'}
            </button>
            <ConfirmButton onConfirm={() => void remove()} disabled={busy !== null}>
              Delete
            </ConfirmButton>
          </>
        }
      />

      <div className="space-y-6">
        {error ? (
          <Notice kind="error" onDismiss={() => setError(null)}>
            {error}
          </Notice>
        ) : null}
        {notice ? (
          <Notice kind={notice.kind} onDismiss={() => setNotice(null)}>
            {notice.text}
          </Notice>
        ) : null}

        {email.status === 'flagged' && review ? (
          <Notice kind="warning" title="This email is waiting for a person">
            {review.reason}{' '}
            <Link href={`/review/${review.id}`} className="font-medium underline">
              Decide what it is
            </Link>
          </Notice>
        ) : null}

        <div className="grid gap-6 lg:grid-cols-2">
          <Card
            title="The email that arrived"
            actions={<StatusBadge status={email.status} />}
          >
            <div className="rounded-lg bg-slate-50 p-4">
              <TextWithPlaceholders text={email.body || '(no body text)'} />
            </div>

            {Object.keys(extracted).length ? (
              <div className="mt-4">
                <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-500">
                  What the agent pulled out of it
                </p>
                <dl className="grid grid-cols-1 gap-x-4 gap-y-1.5 text-xs sm:grid-cols-2">
                  {Object.entries(extracted)
                    .filter(([key]) => key !== 'signature')
                    .map(([key, value]) => (
                      <div key={key} className="flex gap-2">
                        <dt className="shrink-0 font-mono text-slate-500">{key}</dt>
                        <dd className="min-w-0 truncate text-slate-800">{value}</dd>
                      </div>
                    ))}
                </dl>
                <p className="hint">
                  These fill the <code>{'{{placeholders}}'}</code> in the reply template. Anything
                  missing here is left visible in the draft for you to complete.
                </p>
              </div>
            ) : null}
          </Card>

          <Card
            title="Why it decided that"
            actions={
              <>
                {type ? <span className="badge bg-brand-50 text-brand-700">{type.name}</span> : null}
                <MethodBadge method={classification?.method ?? null} />
              </>
            }
          >
            {classification ? (
              <div className="space-y-4">
                <div className="flex items-baseline gap-3">
                  <span className="text-3xl font-semibold tabular-nums text-slate-900">
                    {classification.confidence.toFixed(2)}
                  </span>
                  <span className="text-xs text-slate-500">
                    confidence
                    {type ? (
                      <>
                        {' '}
                        in{' '}
                        <Link href={`/types/${type.id}`} className="underline">
                          {type.name}
                        </Link>
                      </>
                    ) : null}
                  </span>
                </div>

                <p className="text-sm leading-relaxed text-slate-700">{classification.reasoning}</p>

                {classification.scores.length ? (
                  <div>
                    <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-500">
                      How every type scored
                    </p>
                    <ul className="space-y-2.5">
                      {classification.scores.map((score) => (
                        <li key={score.typeId}>
                          <div className="flex items-center justify-between gap-3">
                            <span
                              className={`min-w-0 flex-1 truncate text-xs ${
                                score.typeId === classification.typeId
                                  ? 'font-semibold text-slate-900'
                                  : 'text-slate-600'
                              }`}
                            >
                              {score.typeName}
                            </span>
                            <ScoreBar
                              score={score.score}
                              highlight={score.typeId === classification.typeId}
                            />
                          </div>
                          {score.matchedKeywords?.length ? (
                            <p className="mt-0.5 truncate text-[11px] text-slate-400">
                              matched: {score.matchedKeywords.slice(0, 5).join(', ')}
                            </p>
                          ) : null}
                        </li>
                      ))}
                    </ul>
                    <p className="hint">
                      These come from the offline matcher, which always runs. When an AI model is
                      configured its verdict takes precedence, but these numbers still show what the
                      wording alone suggests.
                    </p>
                  </div>
                ) : null}
              </div>
            ) : (
              <p className="text-sm text-slate-500">No decision has been recorded for this email.</p>
            )}
          </Card>
        </div>

        {draft ? (
          <Card
            title="The drafted reply"
            description={
              draft.generatedBy === 'template'
                ? 'Built by filling in the approved template for this type'
                : `Written by ${draft.generatedBy}, following the approved template`
            }
            actions={
              <>
                <StatusBadge status={draft.status} />
                {!alreadySent && !editing ? (
                  <button type="button" className="btn-secondary btn-sm" onClick={() => setEditing(true)}>
                    Edit
                  </button>
                ) : null}
                {!alreadySent ? (
                  <button
                    type="button"
                    className="btn-primary btn-sm"
                    onClick={() => void send(false)}
                    disabled={busy !== null || editing}
                  >
                    {busy === 'send' ? 'Sending…' : 'Send reply'}
                  </button>
                ) : null}
              </>
            }
          >
            {unresolved.length ? (
              <div className="mb-4">
                <Notice kind="warning" title="Fill these in before sending">
                  <p>
                    The template asks for {unresolved.map((p) => <code key={p} className="mx-0.5">{`{{${p}}}`}</code>)},
                    which the agent could not work out from the email. It deliberately left the gaps
                    rather than inventing a date or a figure.
                  </p>
                  <p className="mt-1.5">
                    Edit the reply to replace them. Sending is blocked until you do, unless you
                    override it.
                  </p>
                </Notice>
              </div>
            ) : null}

            {alreadySent ? (
              <Notice kind="success" title="Sent">
                Delivered to {data.email.fromEmail}
                {draft.sentAt ? (
                  <>
                    {' '}
                    <TimeAgo iso={draft.sentAt} />
                  </>
                ) : null}
                .
              </Notice>
            ) : null}

            {draft.sendError ? (
              <div className="mb-4">
                <Notice kind="error" title="The last send attempt failed">
                  {draft.sendError}
                </Notice>
              </div>
            ) : null}

            {editing ? (
              <div className="mt-4 space-y-4">
                <div>
                  <label className="label" htmlFor="draft-subject">
                    Subject
                  </label>
                  <input
                    id="draft-subject"
                    className="input"
                    value={draftSubject}
                    onChange={(e) => setDraftSubject(e.target.value)}
                  />
                </div>
                <div>
                  <label className="label" htmlFor="draft-body">
                    Reply
                  </label>
                  <textarea
                    id="draft-body"
                    className="input min-h-[360px] font-mono text-[13px]"
                    value={draftBody}
                    onChange={(e) => setDraftBody(e.target.value)}
                  />
                </div>
                <div className="flex gap-2">
                  <button
                    type="button"
                    className="btn-primary btn-sm"
                    onClick={() => void saveDraft()}
                    disabled={busy !== null}
                  >
                    {busy === 'save' ? 'Saving…' : 'Save changes'}
                  </button>
                  <button
                    type="button"
                    className="btn-secondary btn-sm"
                    onClick={() => {
                      setEditing(false);
                      setDraftSubject(draft.subject);
                      setDraftBody(draft.body);
                    }}
                  >
                    Cancel
                  </button>
                </div>
              </div>
            ) : (
              <div className="mt-4 space-y-3">
                <div className="rounded-lg border border-slate-200 bg-white">
                  <div className="border-b border-slate-100 px-4 py-2.5 text-xs text-slate-500">
                    <p>
                      <span className="font-medium text-slate-700">To:</span> {email.fromEmail}
                    </p>
                    <p className="mt-0.5">
                      <span className="font-medium text-slate-700">Subject:</span> {draft.subject}
                    </p>
                  </div>
                  <div className="px-4 py-4">
                    <TextWithPlaceholders text={draft.body} />
                  </div>
                </div>

                {!alreadySent && unresolved.length ? (
                  <ConfirmButton
                    onConfirm={() => void send(true)}
                    className="btn-secondary btn-sm"
                    confirmLabel="Send it anyway?"
                    disabled={busy !== null}
                  >
                    Send without filling the gaps
                  </ConfirmButton>
                ) : null}
              </div>
            )}
          </Card>
        ) : null}
      </div>
    </>
  );
}

function sourceLabel(source: string): string {
  return (
    {
      imap: 'the connected mailbox',
      upload: 'an uploaded file',
      manual: 'the paste box',
      seed: 'the demo samples',
    }[source] ?? source
  );
}
