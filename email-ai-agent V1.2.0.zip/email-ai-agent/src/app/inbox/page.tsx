'use client';

import Link from 'next/link';
import { useCallback, useEffect, useRef, useState } from 'react';
import {
  Card,
  EmptyState,
  MethodBadge,
  Notice,
  PageHeader,
  Spinner,
  StatusBadge,
  TimeAgo,
} from '@/components/ui';
import { apiGet, apiPost, apiUpload } from '@/lib/client';
import type { EmailSummary } from '@/lib/detail';
import type { ProcessResult } from '@/lib/pipeline';

interface ListResponse {
  items: EmailSummary[];
  total: number;
}

interface DemoSample {
  index: number;
  from: string;
  subject: string;
  body: string;
  note: string;
  expectFlag: boolean;
}

type Filter = 'all' | 'classified' | 'flagged' | 'resolved';

export default function InboxPage() {
  const [items, setItems] = useState<EmailSummary[]>([]);
  const [total, setTotal] = useState(0);
  const [filter, setFilter] = useState<Filter>('all');
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<{ kind: 'success' | 'warning'; text: string } | null>(null);

  const [from, setFrom] = useState('');
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');
  const [raw, setRaw] = useState('');
  const [mode, setMode] = useState<'fields' | 'raw'>('fields');
  const [submitting, setSubmitting] = useState(false);
  const [lastResult, setLastResult] = useState<ProcessResult | null>(null);

  const [samples, setSamples] = useState<DemoSample[]>([]);
  const fileInput = useRef<HTMLInputElement>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const params = new URLSearchParams({ limit: '100' });
      if (filter !== 'all') params.set('status', filter);
      if (search.trim()) params.set('search', search.trim());
      const data = await apiGet<ListResponse>(`/api/emails?${params}`);
      setItems(data.items);
      setTotal(data.total);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  }, [filter, search]);

  useEffect(() => {
    void load();
  }, [load]);

  useEffect(() => {
    apiGet<{ samples: DemoSample[] }>('/api/emails/demo')
      .then((data) => setSamples(data.samples))
      .catch(() => undefined);
  }, []);

  const describe = (result: ProcessResult) => {
    if (result.duplicate) {
      return { kind: 'warning' as const, text: 'That exact message had already been processed, so it was not added again.' };
    }
    if (result.flagged) {
      return {
        kind: 'warning' as const,
        text: `Flagged for a person: nothing in your types matched it. It is now in the Review queue${
          result.alert?.ok ? ' and the team has been emailed' : ''
        }.`,
      };
    }
    return {
      kind: 'success' as const,
      text: `Sorted as "${result.type?.name}" and a reply has been drafted for you to check.`,
    };
  };

  const process = async (event: React.FormEvent) => {
    event.preventDefault();
    setSubmitting(true);
    setError(null);
    setNotice(null);
    setLastResult(null);

    try {
      const payload =
        mode === 'raw' ? { raw } : { from, subject, body };
      const result = await apiPost<ProcessResult>('/api/emails/process', payload);
      setLastResult(result);
      setNotice(describe(result));
      if (!result.duplicate) {
        setFrom('');
        setSubject('');
        setBody('');
        setRaw('');
      }
      await load();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setSubmitting(false);
    }
  };

  const upload = async (files: FileList | null) => {
    if (!files?.length) return;
    setSubmitting(true);
    setError(null);
    setNotice(null);
    try {
      const form = new FormData();
      for (const file of Array.from(files)) form.append('files', file);
      const result = await apiUpload<{
        processed: number;
        failed: number;
        results: Array<{ filename: string; ok: boolean; error?: string }>;
      }>('/api/emails/upload', form);

      const failures = result.results.filter((r) => !r.ok);
      setNotice({
        kind: failures.length ? 'warning' : 'success',
        text:
          `${result.processed} file(s) processed` +
          (failures.length
            ? `. ${failures.length} could not be read: ${failures
                .map((f) => `${f.filename} — ${f.error}`)
                .join('; ')}`
            : '.'),
      });
      await load();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setSubmitting(false);
      if (fileInput.current) fileInput.current.value = '';
    }
  };

  const loadSample = (sample: DemoSample) => {
    setMode('fields');
    setFrom(sample.from);
    setSubject(sample.subject);
    setBody(sample.body);
    setNotice(null);
    setLastResult(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <>
      <PageHeader
        title="Inbox"
        description="Feed an email in and watch the agent decide what it is. Everything it has already handled is listed below."
        actions={
          <Link href="/mailbox" className="btn-secondary">
            Fetch from a real mailbox
          </Link>
        }
      />

      <div className="space-y-6">
        {error ? (
          <Notice kind="error" title="That did not work" onDismiss={() => setError(null)}>
            {error}
          </Notice>
        ) : null}

        {notice ? (
          <Notice kind={notice.kind} onDismiss={() => setNotice(null)}>
            {notice.text}{' '}
            {lastResult?.flagged && lastResult.review ? (
              <Link href={`/review/${lastResult.review.id}`} className="font-medium underline">
                Review it now
              </Link>
            ) : lastResult && !lastResult.flagged ? (
              <Link href={`/inbox/${lastResult.email.id}`} className="font-medium underline">
                See the draft
              </Link>
            ) : null}
            {lastResult?.aiError ? (
              <span className="mt-1 block text-xs">
                Note: the AI provider could not be reached ({lastResult.aiError}), so the offline
                matcher decided this one.
              </span>
            ) : null}
            {lastResult?.alert && !lastResult.alert.ok && lastResult.alert.error ? (
              <span className="mt-1 block text-xs">Alert email: {lastResult.alert.error}</span>
            ) : null}
          </Notice>
        ) : null}

        <div className="grid gap-6 lg:grid-cols-5">
          <Card
            className="lg:col-span-3"
            title="Process an email"
            description="Paste the text, or drop in a saved .eml file"
            actions={
              <div className="flex rounded-lg border border-slate-300 p-0.5 text-xs">
                <button
                  type="button"
                  onClick={() => setMode('fields')}
                  className={`rounded px-2.5 py-1 font-medium ${
                    mode === 'fields' ? 'bg-brand-600 text-white' : 'text-slate-600'
                  }`}
                >
                  Fields
                </button>
                <button
                  type="button"
                  onClick={() => setMode('raw')}
                  className={`rounded px-2.5 py-1 font-medium ${
                    mode === 'raw' ? 'bg-brand-600 text-white' : 'text-slate-600'
                  }`}
                >
                  Paste whole email
                </button>
              </div>
            }
          >
            <form onSubmit={process} className="space-y-4">
              {mode === 'fields' ? (
                <>
                  <div>
                    <label className="label" htmlFor="from">
                      From
                    </label>
                    <input
                      id="from"
                      className="input"
                      placeholder="Kavya Reddy &lt;kavya@example.com&gt;"
                      value={from}
                      onChange={(e) => setFrom(e.target.value)}
                      required
                    />
                    <p className="hint">Needed because the drafted reply has to be addressed to someone.</p>
                  </div>
                  <div>
                    <label className="label" htmlFor="subject">
                      Subject
                    </label>
                    <input
                      id="subject"
                      className="input"
                      placeholder="Still no sign of order 92771"
                      value={subject}
                      onChange={(e) => setSubject(e.target.value)}
                    />
                  </div>
                  <div>
                    <label className="label" htmlFor="body">
                      Message
                    </label>
                    <textarea
                      id="body"
                      className="input min-h-[180px] font-mono text-[13px]"
                      placeholder="Paste the email body here…"
                      value={body}
                      onChange={(e) => setBody(e.target.value)}
                      required
                    />
                  </div>
                </>
              ) : (
                <div>
                  <label className="label" htmlFor="raw">
                    The whole email, headers and all
                  </label>
                  <textarea
                    id="raw"
                    className="input min-h-[280px] font-mono text-[13px]"
                    placeholder={'From: Kavya Reddy <kavya@example.com>\nSubject: Still no sign of order 92771\n\nHi, order 92771 was due on the 12th…'}
                    value={raw}
                    onChange={(e) => setRaw(e.target.value)}
                    required
                  />
                  <p className="hint">
                    Understands a full .eml message as well as a simple From/Subject header block.
                  </p>
                </div>
              )}

              <div className="flex flex-wrap items-center gap-3 border-t border-slate-100 pt-4">
                <button type="submit" className="btn-primary" disabled={submitting}>
                  {submitting ? 'Working…' : 'Sort this email'}
                </button>

                <span className="text-xs text-slate-400">or</span>

                <label className="btn-secondary btn-sm cursor-pointer">
                  Upload .eml files
                  <input
                    ref={fileInput}
                    type="file"
                    accept=".eml,.txt,message/rfc822,text/plain"
                    multiple
                    className="hidden"
                    onChange={(e) => void upload(e.target.files)}
                    disabled={submitting}
                  />
                </label>
              </div>
            </form>
          </Card>

          <Card
            className="lg:col-span-2"
            title="Demo emails"
            description="Load one into the form to try it"
          >
            {samples.length ? (
              <ul className="space-y-2">
                {samples.map((sample) => (
                  <li key={sample.index}>
                    <button
                      type="button"
                      onClick={() => loadSample(sample)}
                      className="w-full rounded-lg border border-slate-200 p-3 text-left transition-colors hover:border-brand-300 hover:bg-brand-50"
                    >
                      <span className="flex items-start justify-between gap-2">
                        <span className="min-w-0 flex-1 truncate text-sm font-medium text-slate-800">
                          {sample.subject}
                        </span>
                        {sample.expectFlag ? (
                          <span className="badge shrink-0 bg-amber-100 text-amber-900">
                            should flag
                          </span>
                        ) : null}
                      </span>
                      <span className="mt-1 block text-xs text-slate-500">{sample.note}</span>
                    </button>
                  </li>
                ))}
              </ul>
            ) : (
              <Spinner label="Loading samples" />
            )}
          </Card>
        </div>

        <Card
          title={`Processed emails${total ? ` (${total})` : ''}`}
          actions={
            <div className="flex flex-wrap items-center gap-2">
              <input
                className="input w-44 py-1.5 text-xs"
                placeholder="Search…"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
              <div className="flex rounded-lg border border-slate-300 p-0.5 text-xs">
                {(['all', 'classified', 'flagged', 'resolved'] as Filter[]).map((option) => (
                  <button
                    key={option}
                    type="button"
                    onClick={() => setFilter(option)}
                    className={`rounded px-2.5 py-1 font-medium capitalize ${
                      filter === option ? 'bg-brand-600 text-white' : 'text-slate-600'
                    }`}
                  >
                    {option === 'flagged' ? 'needs review' : option}
                  </button>
                ))}
              </div>
            </div>
          }
        >
          {loading ? (
            <Spinner label="Loading emails" />
          ) : items.length ? (
            <ul className="-mx-2 divide-y divide-slate-100">
              {items.map(({ email, typeName, confidence, method, draftStatus, unresolvedCount, reviewId }) => (
                <li key={email.id}>
                  <Link
                    href={email.status === 'flagged' && reviewId ? `/review/${reviewId}` : `/inbox/${email.id}`}
                    className="block rounded-lg px-2 py-3 transition-colors hover:bg-slate-50"
                  >
                    <div className="flex flex-wrap items-start justify-between gap-2">
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-medium text-slate-900">
                          {email.subject || '(no subject)'}
                        </p>
                        <p className="mt-0.5 truncate text-xs text-slate-500">
                          {email.fromName ? `${email.fromName} · ` : ''}
                          {email.fromEmail} · <TimeAgo iso={email.receivedAt} />
                        </p>
                      </div>
                      <div className="flex shrink-0 flex-wrap items-center gap-1.5">
                        {typeName ? (
                          <span className="badge bg-brand-50 text-brand-700">{typeName}</span>
                        ) : null}
                        <StatusBadge status={email.status} />
                        {draftStatus ? <StatusBadge status={draftStatus} /> : null}
                        {unresolvedCount > 0 ? (
                          <span className="badge bg-amber-100 text-amber-900">
                            {unresolvedCount} to fill in
                          </span>
                        ) : null}
                        <MethodBadge method={method} />
                        {confidence !== null ? (
                          <span className="text-xs tabular-nums text-slate-400">
                            {confidence.toFixed(2)}
                          </span>
                        ) : null}
                      </div>
                    </div>
                  </Link>
                </li>
              ))}
            </ul>
          ) : (
            <EmptyState title="No emails here yet">
              {filter === 'all'
                ? 'Process one above, or load a demo email to see how it works.'
                : `Nothing with the "${filter}" status.`}
            </EmptyState>
          )}
        </Card>
      </div>
    </>
  );
}
