'use client';

import { useRouter, useSearchParams } from 'next/navigation';
import { Suspense, useState } from 'react';
import { Notice } from '@/components/ui';
import { apiPost } from '@/lib/client';

function LoginForm() {
  const router = useRouter();
  const params = useSearchParams();
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await apiPost('/api/login', { password });
      // Only allow internal paths, so `?next=` cannot be used to bounce elsewhere.
      const next = params.get('next');
      const target = next && next.startsWith('/') && !next.startsWith('//') ? next : '/';
      router.push(target);
      router.refresh();
    } catch (err) {
      setError((err as Error).message);
      setBusy(false);
    }
  };

  return (
    <div className="mx-auto max-w-sm py-16">
      <div className="mb-8 text-center">
        <span className="mx-auto mb-3 grid h-11 w-11 place-items-center rounded-xl bg-brand-600 text-lg text-white">
          ✉
        </span>
        <h1 className="text-xl font-semibold text-slate-900">Email Triage Agent</h1>
        <p className="mt-1 text-sm text-slate-600">This site is password protected.</p>
      </div>

      <form onSubmit={submit} className="card card-pad space-y-4">
        {error ? <Notice kind="error">{error}</Notice> : null}

        <div>
          <label className="label" htmlFor="password">
            Password
          </label>
          <input
            id="password"
            type="password"
            className="input"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            autoFocus
            autoComplete="current-password"
            required
          />
          <p className="hint">This is the value of the APP_PASSWORD environment variable.</p>
        </div>

        <button type="submit" className="btn-primary w-full" disabled={busy || !password}>
          {busy ? 'Checking…' : 'Sign in'}
        </button>
      </form>
    </div>
  );
}

export default function LoginPage() {
  // useSearchParams needs a Suspense boundary during prerendering.
  return (
    <Suspense fallback={<div className="py-16 text-center text-sm text-slate-500">Loading…</div>}>
      <LoginForm />
    </Suspense>
  );
}
