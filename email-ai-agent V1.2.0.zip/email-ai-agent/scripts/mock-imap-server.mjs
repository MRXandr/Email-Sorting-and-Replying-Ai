/**
 * A minimal IMAP server holding a few fixed messages, used to test the
 * mailbox-fetching path without a real mail account.
 *
 *   node scripts/mock-imap-server.mjs            # listens on 1143
 *
 *   IMAP_HOST=127.0.0.1 IMAP_PORT=1143 IMAP_SECURE=false \
 *   IMAP_USER=test IMAP_PASSWORD=test npm start
 *
 * It serves seven messages — five ordinary customer emails and two that no
 * seeded type covers — so a fetch exercises both the classify and the flag paths.
 * Messages start unread; marking one \Seen sticks for the life of the process,
 * which is what lets a test prove the same message is not fetched twice.
 *
 * This implements only the small subset of IMAP4rev1 that the client uses. It is a
 * test double, not a mail server — never expose it to a network.
 */
import { createServer } from 'node:net';

const PORT = Number(process.env.MOCK_IMAP_PORT || 1143);
const VERBOSE = process.env.MOCK_IMAP_VERBOSE === '1';

function message({ from, subject, body, date = 'Mon, 15 Sep 2026 09:30:00 +0000', id }) {
  // CRLF line endings throughout, as the protocol requires.
  return [
    `Return-Path: <${from.match(/<(.+)>/)?.[1] ?? from}>`,
    `From: ${from}`,
    'To: support@northwind-retail.example',
    `Subject: ${subject}`,
    `Date: ${date}`,
    `Message-ID: <${id}@mock.example>`,
    'MIME-Version: 1.0',
    'Content-Type: text/plain; charset=utf-8',
    'Content-Transfer-Encoding: 8bit',
    '',
    body,
    '',
  ].join('\r\n');
}

/** The mailbox contents. `seen` is mutated by STORE. */
const MAILBOX = [
  {
    uid: 1,
    seen: false,
    expect: 'order-status',
    raw: message({
      id: 'mock-order-1',
      from: 'Kavya Reddy <kavya.reddy@example.com>',
      subject: 'Still no sign of order 92771',
      body: 'Hi,\n\nOrder 92771 was supposed to arrive on the 12th. The tracking link has said "in transit" for six days and the courier helpline just puts me on hold.\n\nCan you find out where the parcel actually is?\n\nThanks,\nKavya',
    }),
  },
  {
    uid: 2,
    seen: false,
    expect: 'returns-refunds',
    raw: message({
      id: 'mock-return-1',
      from: 'Tom Brady <t.brady@example.com>',
      subject: 'Jacket is the wrong size, need to send it back',
      body: 'Hello,\n\nThe jacket from order 80145 arrived today but it is far too big — I ordered a medium and this is clearly an XL.\n\nI would like to return it for the correct size, or a refund if you have no mediums left. How do I arrange that?\n\nTom',
    }),
  },
  {
    uid: 3,
    seen: false,
    expect: 'product-info',
    raw: message({
      id: 'mock-presales-1',
      from: 'Lucia Moretti <lucia.m@example.com>',
      subject: 'Question about the desk before I order',
      body: 'Good morning,\n\nI am about to buy the sit-stand desk but I need to check two things first. What is the desktop thickness, and is the walnut finish real veneer or laminate?\n\nAlso, do you ship to Italy, and is the warranty valid there? I have not placed an order yet.\n\nKind regards,\nLucia',
    }),
  },
  {
    uid: 4,
    seen: false,
    expect: 'billing-payment',
    raw: message({
      id: 'mock-billing-1',
      from: 'Ahmed Farouk <ahmed.farouk@example.com>',
      subject: 'Two charges on my card for one order',
      body: 'Hello,\n\nI placed order 31556 yesterday. My bank statement shows the amount deducted twice — 2,150 on both lines, same date, same merchant.\n\nPlease refund the duplicate charge and confirm in writing.\n\nRegards,\nAhmed Farouk',
    }),
  },
  {
    uid: 5,
    seen: false,
    expect: 'complaint-escalation',
    raw: message({
      id: 'mock-complaint-1',
      from: 'Ruth Delaney <r.delaney@example.com>',
      subject: 'Fourth email, still nothing, I want a manager',
      body: 'This is now my fourth email.\n\nNobody has replied to a single one. Two of your agents promised a callback and neither happened. I have been waiting nineteen days.\n\nI want this escalated to a manager today. If not, I will be disputing the charge with my bank and taking this to the consumer forum.\n\nThis is the worst service I have ever dealt with.\n\nRuth Delaney',
    }),
  },
  {
    uid: 6,
    seen: false,
    expect: 'FLAG',
    raw: message({
      id: 'mock-supplier-1',
      from: 'Priyanka Chandra <priyanka@brightpackaging.example>',
      subject: 'Wholesale partnership proposal - sustainable packaging',
      body: 'Dear Procurement Team,\n\nI am writing on behalf of Bright Packaging, a manufacturer of compostable retail packaging based in Pune.\n\nOur minimum order quantity is 5,000 units and we can hold buffer stock at our Mumbai warehouse. I have attached our catalogue and current rate card.\n\nWould your buying team be open to a 20-minute call next week to discuss volume pricing and a trial shipment?\n\nWarm regards,\nPriyanka Chandra\nHead of Business Development, Bright Packaging Pvt Ltd',
    }),
  },
  {
    uid: 7,
    seen: false,
    expect: 'FLAG',
    raw: message({
      id: 'mock-jobs-1',
      from: 'Joel Mensah <joel.mensah.cv@example.com>',
      subject: 'Application for Warehouse Supervisor position',
      body: 'Dear Hiring Manager,\n\nI would like to apply for the Warehouse Supervisor role advertised on your careers page (reference WH-114).\n\nI have seven years of experience in distribution centre operations, including four years supervising a team of twelve. My CV is attached.\n\nThank you for considering my application.\n\nYours sincerely,\nJoel Mensah',
    }),
  },
];

const FLAGS = '\\Answered \\Flagged \\Deleted \\Seen \\Draft';

/** Expand an IMAP UID set such as "1:3,5,7:*" into concrete uids we hold. */
function expandUidSet(set) {
  const maxUid = Math.max(...MAILBOX.map((m) => m.uid));
  const out = new Set();

  for (const part of String(set).split(',')) {
    const range = part.split(':');
    if (range.length === 2) {
      const start = range[0] === '*' ? maxUid : Number(range[0]);
      const end = range[1] === '*' ? maxUid : Number(range[1]);
      for (let uid = Math.min(start, end); uid <= Math.max(start, end); uid++) out.add(uid);
    } else {
      out.add(part === '*' ? maxUid : Number(part));
    }
  }

  return MAILBOX.filter((m) => out.has(m.uid));
}

const server = createServer((socket) => {
  let buffer = '';
  let authenticated = false;
  let selected = false;

  const write = (line) => {
    if (VERBOSE) console.log(`[mock-imap] S: ${line.slice(0, 120)}`);
    socket.write(`${line}\r\n`);
  };

  write(`* OK [CAPABILITY IMAP4rev1 UIDPLUS LITERAL+ ID] mock-imap ready`);

  socket.on('data', (chunk) => {
    buffer += chunk.toString('utf8');

    while (true) {
      const end = buffer.indexOf('\r\n');
      if (end === -1) return;

      const line = buffer.slice(0, end);
      buffer = buffer.slice(end + 2);
      if (!line.trim()) continue;

      if (VERBOSE) console.log(`[mock-imap] C: ${line.slice(0, 140)}`);

      const spaceIndex = line.indexOf(' ');
      const tag = spaceIndex === -1 ? line : line.slice(0, spaceIndex);
      const rest = spaceIndex === -1 ? '' : line.slice(spaceIndex + 1);
      const command = rest.split(' ')[0].toUpperCase();
      const args = rest.slice(command.length).trim();

      switch (command) {
        case 'CAPABILITY':
          write('* CAPABILITY IMAP4rev1 UIDPLUS LITERAL+ ID');
          write(`${tag} OK CAPABILITY completed`);
          break;

        case 'ID':
          write('* ID ("name" "mock-imap")');
          write(`${tag} OK ID completed`);
          break;

        case 'LOGIN':
          authenticated = true;
          write(`${tag} OK [CAPABILITY IMAP4rev1 UIDPLUS LITERAL+ ID] LOGIN completed`);
          break;

        case 'AUTHENTICATE':
          // Accept any credentials; the continuation line is consumed below.
          write('+ ');
          authenticated = true;
          write(`${tag} OK AUTHENTICATE completed`);
          break;

        case 'NAMESPACE':
          write('* NAMESPACE (("" "/")) NIL NIL');
          write(`${tag} OK NAMESPACE completed`);
          break;

        case 'LIST':
        case 'LSUB':
          // Both the delimiter probe (LIST "" "") and a real listing.
          if (/""\s*$|"" ""/.test(args)) {
            write(`* ${command} (\\Noselect) "/" ""`);
          } else {
            write(`* ${command} (\\HasNoChildren) "/" "INBOX"`);
          }
          write(`${tag} OK ${command} completed`);
          break;

        case 'STATUS': {
          const unseen = MAILBOX.filter((m) => !m.seen).length;
          write(
            `* STATUS "INBOX" (MESSAGES ${MAILBOX.length} UNSEEN ${unseen} UIDNEXT ${MAILBOX.length + 1} UIDVALIDITY 1 RECENT 0)`,
          );
          write(`${tag} OK STATUS completed`);
          break;
        }

        case 'SELECT':
        case 'EXAMINE': {
          selected = true;
          const readOnly = command === 'EXAMINE';
          write(`* FLAGS (${FLAGS})`);
          write(`* OK [PERMANENTFLAGS (${FLAGS} \\*)] Flags permitted`);
          write(`* ${MAILBOX.length} EXISTS`);
          write('* 0 RECENT');
          write('* OK [UIDVALIDITY 1] UIDs valid');
          write(`* OK [UIDNEXT ${MAILBOX.length + 1}] Predicted next UID`);
          write(`${tag} OK [${readOnly ? 'READ-ONLY' : 'READ-WRITE'}] ${command} completed`);
          break;
        }

        case 'UID': {
          const sub = args.split(' ')[0].toUpperCase();
          const subArgs = args.slice(sub.length).trim();

          if (sub === 'SEARCH') {
            const criteria = subArgs.toUpperCase();
            let matches = MAILBOX;
            if (criteria.includes('UNSEEN') || criteria.includes('NOT SEEN')) {
              matches = MAILBOX.filter((m) => !m.seen);
            } else if (criteria.includes('SEEN')) {
              matches = MAILBOX.filter((m) => m.seen);
            }
            write(`* SEARCH ${matches.map((m) => m.uid).join(' ')}`.trimEnd());
            write(`${tag} OK UID SEARCH completed`);
          } else if (sub === 'FETCH') {
            const setEnd = subArgs.indexOf(' ');
            const uidSet = subArgs.slice(0, setEnd);
            const wanted = subArgs.slice(setEnd + 1).toUpperCase();

            for (const item of expandUidSet(uidSet)) {
              const pieces = [`UID ${item.uid}`];

              if (/BODY(\.PEEK)?\[\]|RFC822(?!\.)/.test(wanted)) {
                const bytes = Buffer.byteLength(item.raw, 'utf8');
                // The literal is written raw, immediately after the {n} marker.
                socket.write(`* ${item.uid} FETCH (${pieces.join(' ')} BODY[] {${bytes}}\r\n`);
                socket.write(item.raw);
                socket.write(')\r\n');
                continue;
              }

              if (wanted.includes('FLAGS')) {
                pieces.push(`FLAGS (${item.seen ? '\\Seen' : ''})`);
              }
              if (wanted.includes('INTERNALDATE')) {
                pieces.push('INTERNALDATE "15-Sep-2026 09:30:00 +0000"');
              }
              if (wanted.includes('RFC822.SIZE')) {
                pieces.push(`RFC822.SIZE ${Buffer.byteLength(item.raw, 'utf8')}`);
              }
              write(`* ${item.uid} FETCH (${pieces.join(' ')})`);
            }

            write(`${tag} OK UID FETCH completed`);
          } else if (sub === 'STORE') {
            const match = subArgs.match(/^(\S+)\s+([+-]?FLAGS(?:\.SILENT)?)\s+\(?([^)]*)\)?/i);
            if (match) {
              const [, uidSet, operation, flagList] = match;
              const addingSeen = /\\Seen/i.test(flagList);
              for (const item of expandUidSet(uidSet)) {
                if (operation.startsWith('+') && addingSeen) item.seen = true;
                if (operation.startsWith('-') && addingSeen) item.seen = false;
                if (!operation.startsWith('+') && !operation.startsWith('-')) item.seen = addingSeen;
                if (!/SILENT/i.test(operation)) {
                  write(`* ${item.uid} FETCH (UID ${item.uid} FLAGS (${item.seen ? '\\Seen' : ''}))`);
                }
              }
              console.log(
                `[mock-imap] marked seen: [${MAILBOX.filter((m) => m.seen).map((m) => m.uid).join(', ')}]`,
              );
            }
            write(`${tag} OK UID STORE completed`);
          } else {
            write(`${tag} OK UID ${sub} completed`);
          }
          break;
        }

        case 'NOOP':
          write(`${tag} OK NOOP completed`);
          break;

        case 'CLOSE':
        case 'UNSELECT':
          selected = false;
          write(`${tag} OK ${command} completed`);
          break;

        case 'LOGOUT':
          write('* BYE mock-imap signing off');
          write(`${tag} OK LOGOUT completed`);
          socket.end();
          return;

        case 'ENABLE':
          write(`${tag} OK ENABLE completed`);
          break;

        default:
          // Unknown commands succeed rather than stalling the client.
          if (VERBOSE) console.log(`[mock-imap] (unhandled command "${command}")`);
          write(`${tag} OK ${command || 'command'} completed`);
      }

      void authenticated;
      void selected;
    }
  });

  socket.on('error', () => {
    /* clients disconnect abruptly */
  });
});

server.listen(PORT, '127.0.0.1', () => {
  const unseen = MAILBOX.filter((m) => !m.seen).length;
  console.log(`[mock-imap] listening on 127.0.0.1:${PORT}`);
  console.log(`[mock-imap] ${MAILBOX.length} messages, ${unseen} unread`);
});

// Let a test reset the mailbox between runs without restarting the process.
process.on('SIGHUP', () => {
  for (const item of MAILBOX) item.seen = false;
  console.log('[mock-imap] all messages marked unread again');
});
