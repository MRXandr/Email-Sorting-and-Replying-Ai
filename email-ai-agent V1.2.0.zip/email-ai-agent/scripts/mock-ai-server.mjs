/**
 * A stand-in for a real AI provider, used to test the AI code path without a key,
 * without spending anything, and without needing network access.
 *
 *   node scripts/mock-ai-server.mjs           # listens on 4010
 *   GEMINI_API_KEY=test \
 *   GEMINI_BASE_URL=http://localhost:4010/v1beta \
 *   npm start
 *
 * It implements both wire formats the app talks:
 *   POST /v1beta/models/{model}:generateContent   (Google Gemini)
 *   POST /v1/chat/completions                     (OpenAI-compatible)
 *
 * It answers by actually reading the prompt: it looks for the category catalogue
 * the app sends and picks whichever slug's keywords best match the email in the
 * prompt. That makes it a real exercise of prompt construction and response
 * parsing, not just a canned reply.
 *
 * Special behaviours for testing failure handling, triggered by the email text:
 *   "MOCKFAIL"     → responds 500
 *   "MOCKGARBAGE"  → responds with prose instead of JSON
 *   "MOCKNULL"     → returns slug: null (nothing matches)
 *   "MOCKLOWCONF"  → returns a real slug with confidence 0.3
 *   "MOCKBADSLUG"  → returns a slug that does not exist
 *   "MOCKSHORT"    → returns a uselessly short reply body
 */
import { createServer } from 'node:http';

const PORT = Number(process.env.MOCK_AI_PORT || 4010);
let requestCount = 0;

/** Pull the catalogue slugs and their "Typical phrases" out of the prompt. */
function parseCatalogue(prompt) {
  const entries = [];
  const blocks = prompt.split('### CATEGORY slug: ').slice(1);

  for (const block of blocks) {
    const slug = block.split('\n')[0].trim();
    const phraseLine = block.match(/^Typical phrases: (.*)$/m);
    const coversLine = block.match(/^Covers: (.*)$/m);
    entries.push({
      slug,
      phrases: phraseLine ? phraseLine[1].split(',').map((p) => p.trim().toLowerCase()) : [],
      covers: (coversLine?.[1] ?? '').toLowerCase(),
    });
  }
  return entries;
}

/** The email being classified sits after the "Now classify this" marker. */
function extractTargetEmail(prompt) {
  const index = prompt.indexOf('Now classify this newly received email:');
  return (index === -1 ? prompt : prompt.slice(index)).toLowerCase();
}

/**
 * Phrases that mark an email as not being from a customer at all.
 *
 * A real model reads intent and gets these right without help; this crude
 * stand-in needs telling. Without it the mock would file a supplier pitch under
 * "Returns & Refunds" purely because some words overlap, which is precisely the
 * mistake the system prompt tells a real model not to make — so leaving it out
 * would make the mock an unfair stand-in, not a stricter one.
 */
const NOT_A_CUSTOMER = [
  'on behalf of',
  'business development',
  'partnership',
  'wholesale',
  'supplier',
  'rate card',
  'minimum order quantity',
  'volume pricing',
  'trial consignment',
  'application for',
  'apply for the',
  'hiring manager',
  'my cv',
  'cv is attached',
  'curriculum vitae',
  'years of experience',
  'journalist',
  'press enquiry',
  'sponsorship',
  'keynote',
  'right to erasure',
  'gdpr',
];

function classify(prompt) {
  const catalogue = parseCatalogue(prompt);
  const email = extractTargetEmail(prompt);

  if (email.includes('mocknull')) {
    return { slug: null, confidence: 0.95, reasoning: 'Mock: told to report no match.' };
  }
  if (email.includes('mockbadslug')) {
    return { slug: 'this-slug-does-not-exist', confidence: 0.99, reasoning: 'Mock: invented a slug.' };
  }

  let best = null;
  for (const entry of catalogue) {
    let score = 0;
    for (const phrase of entry.phrases) {
      if (phrase && email.includes(phrase)) score += phrase.includes(' ') ? 2 : 1;
    }
    for (const word of entry.covers.split(/\W+/)) {
      if (word.length > 6 && email.includes(word)) score += 0.25;
    }
    if (!best || score > best.score) best = { slug: entry.slug, score };
  }

  if (email.includes('mocklowconf')) {
    return { slug: best?.slug ?? catalogue[0]?.slug ?? null, confidence: 0.3, reasoning: 'Mock: deliberately unsure.' };
  }

  // An email full of outsider signals is not a customer enquiry — unless a
  // catalogue entry matches it strongly, which is what happens once a human has
  // taught the system a "Supplier & Partnership" type for exactly this mail.
  const outsiderSignals = NOT_A_CUSTOMER.filter((phrase) => email.includes(phrase)).length;
  if (outsiderSignals >= 2 && (!best || best.score < 3)) {
    return {
      slug: null,
      confidence: 0.92,
      reasoning:
        `Mock: this reads as ${outsiderSignals} signals of a non-customer email (supplier pitch, ` +
        `job application, press or legal), and no category covers it.`,
    };
  }

  if (!best || best.score < 1) {
    return {
      slug: null,
      confidence: 0.9,
      reasoning: 'Mock: nothing in the catalogue matches this email.',
    };
  }

  return {
    slug: best.slug,
    confidence: 0.93,
    reasoning: `Mock: matched "${best.slug}" on catalogue phrases (score ${best.score}).`,
  };
}

function draft(prompt) {
  const email = prompt.toLowerCase();
  if (email.includes('mockshort')) return { subject: 'Re: hi', body: 'ok' };

  // Start from the pre-filled template the app supplies, so the output is
  // realistic and still contains any placeholder it could not resolve.
  const marker = 'THE SAME TEMPLATE WITH KNOWN VALUES ALREADY SUBSTITUTED (use this as your base):';
  const index = prompt.indexOf(marker);

  let subject = 'Re: your message';
  let body = '';

  if (index !== -1) {
    const section = prompt.slice(index + marker.length);
    const subjectMatch = section.match(/^\s*Subject: (.*)$/m);
    if (subjectMatch) subject = subjectMatch[1].trim();
    const bodyIndex = section.indexOf('\nBody:\n');
    if (bodyIndex !== -1) {
      body = section
        .slice(bodyIndex + 7)
        .split('\nKNOWN VALUES EXTRACTED')[0]
        .trim();
    }
  }

  if (body.length < 60) {
    body = 'Hello,\n\nThank you for your message. We are looking into it and will be in touch.\n\nBest regards,\nCustomer Care Team';
  }

  return { subject, body: `${body}\n\n[mock model]` };
}

function respond(prompt, isClassify) {
  if (prompt.toLowerCase().includes('mockgarbage')) {
    return { garbage: 'I am terribly sorry, but I cannot help with that request.' };
  }

  if (isClassify) {
    const verdict = classify(prompt);
    return { json: JSON.stringify({ ...verdict, runners_up: [] }) };
  }
  return { json: JSON.stringify(draft(prompt)) };
}

const server = createServer((req, res) => {
  let raw = '';
  req.on('data', (chunk) => {
    raw += chunk;
  });

  req.on('end', () => {
    requestCount++;

    let payload;
    try {
      payload = JSON.parse(raw || '{}');
    } catch {
      res.writeHead(400, { 'content-type': 'application/json' });
      res.end(JSON.stringify({ error: { message: 'bad json' } }));
      return;
    }

    const isGemini = req.url.includes(':generateContent');

    // Reconstruct the prompt and system instruction from either wire format.
    const system = isGemini
      ? (payload.systemInstruction?.parts ?? []).map((p) => p.text ?? '').join('\n')
      : (payload.messages ?? []).filter((m) => m.role === 'system').map((m) => m.content).join('\n');

    const prompt = isGemini
      ? (payload.contents ?? []).flatMap((c) => c.parts ?? []).map((p) => p.text ?? '').join('\n')
      : (payload.messages ?? []).filter((m) => m.role === 'user').map((m) => m.content).join('\n');

    if (prompt.toLowerCase().includes('mockfail')) {
      res.writeHead(500, { 'content-type': 'application/json' });
      res.end(JSON.stringify({ error: { message: 'mock: simulated provider outage' } }));
      return;
    }

    // Mirror the real providers' auth requirements, so a missing key is caught.
    if (isGemini && !req.headers['x-goog-api-key']) {
      res.writeHead(401, { 'content-type': 'application/json' });
      res.end(JSON.stringify({ error: { message: 'mock: no api key header' } }));
      return;
    }
    if (!isGemini && !req.headers.authorization) {
      res.writeHead(401, { 'content-type': 'application/json' });
      res.end(JSON.stringify({ error: { message: 'mock: no authorization header' } }));
      return;
    }

    const isClassify = system.includes('email triage classifier');
    const result = respond(prompt, isClassify);
    const text = result.json ?? result.garbage;

    console.log(
      `[mock-ai] #${requestCount} ${isGemini ? 'gemini' : 'openai'} ${isClassify ? 'classify' : 'draft'} → ${text.slice(0, 90)}`,
    );

    res.writeHead(200, { 'content-type': 'application/json' });

    if (isGemini) {
      res.end(
        JSON.stringify({
          candidates: [{ content: { parts: [{ text }], role: 'model' }, finishReason: 'STOP' }],
        }),
      );
    } else {
      res.end(
        JSON.stringify({
          choices: [{ message: { role: 'assistant', content: text }, finish_reason: 'stop' }],
        }),
      );
    }
  });
});

server.listen(PORT, () => {
  console.log(`[mock-ai] listening on http://localhost:${PORT}`);
  console.log(`[mock-ai]   Gemini: http://localhost:${PORT}/v1beta/models/{model}:generateContent`);
  console.log(`[mock-ai]   OpenAI: http://localhost:${PORT}/v1/chat/completions`);
});
