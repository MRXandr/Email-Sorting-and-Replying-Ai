/**
 * Tests the email-sending paths against the mock SMTP server.
 *
 *   Terminal 1:  node scripts/mock-smtp-server.mjs
 *   Terminal 2:  SMTP_HOST=127.0.0.1 SMTP_PORT=2525 SMTP_SECURE=false \
 *                SMTP_USER=test SMTP_PASSWORD=test SMTP_FROM=agent@example.test \
 *                npm start
 *   Terminal 3:  node scripts/test-mail.mjs
 *
 * Verifies the two things that actually leave the building:
 *   - a flagged email produces an alert to the review team, with the file attached
 *   - an approved draft is delivered to the customer who wrote in
 */
import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import path from 'node:path';

const BASE = (process.env.BASE_URL || 'http://localhost:3103').replace(/\/+$/, '');
const SINK_DIR = process.env.MOCK_SMTP_DIR || '/tmp/mock-smtp';
const INDEX = path.join(SINK_DIR, 'index.json');

const GREEN = '\x1b[32m';
const RED = '\x1b[31m';
const DIM = '\x1b[2m';
const BOLD = '\x1b[1m';
const RESET = '\x1b[0m';

let passed = 0;
let failed = 0;
const failures = [];

function check(name, condition, detail = '') {
  if (condition) {
    passed++;
    console.log(`  ${GREEN}✓${RESET} ${name}`);
  } else {
    failed++;
    failures.push(`${name}${detail ? ` — ${detail}` : ''}`);
    console.log(`  ${RED}✗ ${name}${RESET}${detail ? `\n      ${DIM}${detail}${RESET}` : ''}`);
  }
}

function section(title) {
  console.log(`\n${BOLD}${title}${RESET}`);
}

/** Session cookie, set if the server is password protected. */
let cookie = '';

async function api(method, pathname, body) {
  const init = { method, headers: {} };
  if (cookie) init.headers.cookie = cookie;
  if (body !== undefined) {
    init.headers['content-type'] = 'application/json';
    init.body = JSON.stringify(body);
  }
  const response = await fetch(`${BASE}${pathname}`, init);

  const setCookie = response.headers.get('set-cookie');
  if (setCookie) {
    const match = setCookie.match(/mail_agent_session=([^;]*)/);
    if (match) cookie = `mail_agent_session=${match[1]}`;
  }

  const text = await response.text();
  let data = null;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    data = { __unparsed: text.slice(0, 300) };
  }
  return { status: response.status, data };
}

/** Sign in when the server has APP_PASSWORD set, so this works either way. */
async function signInIfNeeded(health) {
  if (!health?.authEnabled) return true;
  const password = process.env.APP_PASSWORD || '';
  if (!password) {
    console.log(
      `\n${RED}The server is password protected. Re-run with APP_PASSWORD=yourpassword${RESET}\n`,
    );
    process.exit(1);
  }
  const login = await api('POST', '/api/login', { password });
  return login.status === 200;
}

function sink() {
  if (!existsSync(INDEX)) return [];
  try {
    return JSON.parse(readFileSync(INDEX, 'utf8'));
  } catch {
    return [];
  }
}

function clearSink() {
  writeFileSync(INDEX, '[]');
}

/** Wait for the sink to reach a message count, since sending is asynchronous. */
async function waitForMail(count, timeoutMs = 8000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (sink().length >= count) return sink();
    await new Promise((r) => setTimeout(r, 150));
  }
  return sink();
}

function readMail(entry) {
  return readFileSync(entry.file, 'utf8');
}

/**
 * Decode RFC 2047 encoded-words, e.g.
 *   =?UTF-8?Q?=5BAction_needed=5D?=  →  [Action needed]
 *
 * Real mail encodes any header containing non-ASCII, so a subject with an em dash
 * arrives encoded. That is correct behaviour by the app; the test has to decode it
 * to assert on the human-readable text.
 */
function decodeHeader(value) {
  return (value || '')
    // Encoded words may be split across several chunks; join adjacent ones first.
    .replace(/\?=\s+=\?/g, '?==?')
    .replace(/=\?([^?]+)\?([QqBb])\?([^?]*)\?=/g, (_match, charset, encoding, text) => {
      if (encoding.toUpperCase() === 'B') {
        return Buffer.from(text, 'base64').toString('utf8');
      }
      // Quoted-printable, with "_" meaning space inside encoded words.
      const bytes = [];
      const source = text.replace(/_/g, ' ');
      for (let i = 0; i < source.length; i++) {
        if (source[i] === '=' && /^[0-9A-Fa-f]{2}$/.test(source.slice(i + 1, i + 3))) {
          bytes.push(parseInt(source.slice(i + 1, i + 3), 16));
          i += 2;
        } else {
          bytes.push(source.charCodeAt(i));
        }
      }
      return Buffer.from(bytes).toString('utf8');
    });
}

/**
 * Return the message with every base64 MIME part decoded and appended, so a test
 * can search attachment contents. Attachments are base64 in the wire format.
 */
function readMailDecoded(entry) {
  const raw = readMail(entry);
  let out = decodeHeader(raw);

  const boundary = raw.match(/boundary="?([^"\r\n;]+)"?/i)?.[1];
  if (!boundary) return out;

  for (const part of raw.split(`--${boundary}`)) {
    if (!/Content-Transfer-Encoding:\s*base64/i.test(part)) continue;
    const bodyStart = part.search(/\r?\n\r?\n/);
    if (bodyStart === -1) continue;
    const encoded = part.slice(bodyStart).replace(/[^A-Za-z0-9+/=]/g, '');
    try {
      out += `\n${Buffer.from(encoded, 'base64').toString('utf8')}`;
    } catch {
      /* not valid base64; skip it */
    }
  }
  return out;
}

async function main() {
  console.log(`\n${BOLD}Mail-sending test against ${BASE}${RESET}`);
  console.log(`${DIM}reading the mock SMTP sink at ${SINK_DIR}${RESET}`);

  section('Setup');
  {
    const health = await api('GET', '/api/health');
    check('the server is up', health.status === 200, `status ${health.status}`);
    check('signed in (if the server requires it)', await signInIfNeeded(health.data));
    check(
      'SMTP is configured on the server',
      health.data?.mailbox?.smtp === true,
      'set SMTP_HOST, SMTP_USER and SMTP_PASSWORD when starting it',
    );
    if (health.data?.mailbox?.smtp !== true) {
      console.log(`\n${RED}Start the server with the mock SMTP settings first.${RESET}\n`);
      process.exit(1);
    }

    const verify = await api('POST', '/api/mailbox/verify');
    check('the app can reach the mail server', verify.data?.smtp?.ok === true, verify.data?.smtp?.error);

    await api('POST', '/api/seed', { confirm: true });
    await api('PATCH', '/api/settings', {
      reviewTeamEmail: 'review-team@example.test',
      autoSendEnabled: false,
    });
    check('the review team address is set', true);
    clearSink();
  }

  section('A flagged email alerts the team');
  {
    clearSink();
    const result = await api('POST', '/api/emails/process', {
      from: 'Priyanka Chandra <priyanka@brightpackaging.example>',
      subject: 'Wholesale partnership proposal — compostable packaging',
      body:
        'Dear Procurement Team,\n\nI am writing on behalf of Bright Packaging, a manufacturer of ' +
        'compostable retail packaging. Our minimum order quantity is 5,000 units and we can hold ' +
        'buffer stock. I have attached our catalogue and rate card. Would your buying team be open ' +
        'to a call about volume pricing?\n\nPriyanka Chandra\nHead of Business Development',
    });

    check('the email was flagged', result.data?.flagged === true, JSON.stringify(result.data?.type));
    check('the alert send was attempted', result.data?.alert?.attempted === true, JSON.stringify(result.data?.alert));
    check('the alert reports success', result.data?.alert?.ok === true, result.data?.alert?.error);
    check('it was addressed to the review team', result.data?.alert?.to === 'review-team@example.test');

    const mail = await waitForMail(1);
    check('exactly one email was sent', mail.length === 1, `got ${mail.length}`);

    if (mail.length) {
      const entry = mail[0];
      const subject = decodeHeader(entry.subject);
      check('it went to the review team address', entry.envelopeTo.includes('review-team@example.test'), JSON.stringify(entry.envelopeTo));
      check('the subject says action is needed', /Action needed/i.test(subject), subject);
      check('the subject names the sender', subject.includes('priyanka@brightpackaging.example'), subject);
      check('a file is attached', entry.hasAttachment === true);
      check('the attachment is the flagged-email file', /^flagged-email-.*\.txt$/.test(entry.attachmentName ?? ''), String(entry.attachmentName));

      const raw = readMailDecoded(entry);
      check('the body explains no reply was sent', /No reply has been sent to the sender/i.test(raw));
      check('the body links to the review page', /\/review\//.test(raw));
      check('the body gives the reason', /Why it was flagged/i.test(raw));
      check('the attached file contains the original email', /Bright Packaging/i.test(raw));
      check('the attached file contains the instructions', /IT IS A NEW KIND OF EMAIL/i.test(raw));

      // The review item must record that the alert went out.
      const reviews = await api('GET', '/api/review?status=open');
      const review = reviews.data?.items?.[0]?.review;
      check('the review item records the alert as sent', Boolean(review?.alertSentAt), JSON.stringify(review?.alertError));
    }
  }

  section('An approved reply reaches the customer');
  {
    clearSink();
    const processed = await api('POST', '/api/emails/process', {
      from: 'Kavya Reddy <kavya.reddy@example.com>',
      subject: 'Still no sign of order 92771',
      body:
        'Hi,\n\nOrder 92771 was supposed to arrive on the 12th. The tracking has said "in transit" ' +
        'for six days. Can you find out where the parcel is?\n\nThanks,\nKavya',
    });

    check('the email was classified', processed.data?.flagged === false, 'it was flagged instead');
    check('no email was sent automatically', sink().length === 0, `${sink().length} were sent`);

    const draftId = processed.data?.draft?.id;
    check('a draft exists', Boolean(draftId));

    if (draftId) {
      check(
        'the draft has no unfilled placeholders',
        processed.data.draft.unresolvedPlaceholders.length === 0,
        JSON.stringify(processed.data.draft.unresolvedPlaceholders),
      );

      const send = await api('POST', `/api/drafts/${draftId}/send`, {});
      check('the send succeeds', send.status === 200, JSON.stringify(send.data).slice(0, 200));
      check('the draft is marked sent', send.data?.draft?.status === 'sent');
      check('a sent timestamp is recorded', Boolean(send.data?.draft?.sentAt));

      const mail = await waitForMail(1);
      check('one email was delivered', mail.length === 1, `got ${mail.length}`);

      if (mail.length) {
        const entry = mail[0];
        check('it went to the customer', entry.envelopeTo.includes('kavya.reddy@example.com'), JSON.stringify(entry.envelopeTo));
        check('it came from the configured sender', entry.envelopeFrom === 'agent@example.test', entry.envelopeFrom);
        check('the subject references the original', /92771/.test(entry.subject), entry.subject);

        const raw = readMailDecoded(entry);
        check('the reply greets the customer by name', /Kavya/.test(raw));
        check('the reply quotes the order number', /92771/.test(raw));
        check('the reply carries the signature', /Northwind Retail/.test(raw));
        check('no placeholder leaked into the sent email', !/\{\{/.test(raw), 'found {{ in the message');
        check('it was sent as both text and HTML', /multipart\/alternative/i.test(raw));
      }

      const again = await api('POST', `/api/drafts/${draftId}/send`, {});
      check('sending the same reply twice is refused', again.status === 409, `status ${again.status}`);
    }
  }

  section('A reply with gaps is never sent by accident');
  {
    clearSink();
    const processed = await api('POST', '/api/emails/process', {
      from: 'Ruth Delaney <r.delaney@example.com>',
      subject: 'Fourth email, still nothing, I want a manager',
      body:
        'This is now my fourth email. Nobody has replied. I have been waiting nineteen days. ' +
        'I want this escalated to a manager today or I will dispute the charge with my bank ' +
        'and take it to the consumer forum. Worst service I have ever dealt with.',
    });

    check('it was classified as an escalation', processed.data?.type?.slug === 'complaint-escalation', processed.data?.type?.name);
    const draft = processed.data?.draft;
    check('the unfillable placeholder was kept', draft?.unresolvedPlaceholders?.includes('expected_resolution_date'), JSON.stringify(draft?.unresolvedPlaceholders));

    const blocked = await api('POST', `/api/drafts/${draft.id}/send`, {});
    check('sending is refused', blocked.status === 422, `status ${blocked.status}`);
    check('nothing was delivered', sink().length === 0, `${sink().length} were sent`);
    check('the error names the placeholder', /expected_resolution_date/.test(blocked.data?.error ?? ''), blocked.data?.error);

    // With an explicit override it does go, which is the documented escape hatch.
    const forced = await api('POST', `/api/drafts/${draft.id}/send`, { force: true });
    check('an explicit override does send it', forced.status === 200, JSON.stringify(forced.data).slice(0, 160));
    const mail = await waitForMail(1);
    check('and the placeholder is visible in what went out', /\{\{expected_resolution_date\}\}/.test(mail.length ? readMailDecoded(mail[0]) : ''), 'not found — which would mean it was silently altered');
  }

  section('Auto-send, when switched on');
  {
    clearSink();
    await api('PATCH', '/api/settings', { autoSendEnabled: true });

    const processed = await api('POST', '/api/emails/process', {
      from: 'Tom Brady <t.brady@example.com>',
      subject: 'Jacket is the wrong size, need to send it back',
      body:
        'The jacket from order 80145 arrived today but it is far too big. I would like to return it ' +
        'for the correct size, or a refund if you have no mediums left. How do I arrange that?',
    });

    check('the email was classified', processed.data?.flagged === false);
    check('auto-send was attempted', processed.data?.autoSend?.attempted === true, JSON.stringify(processed.data?.autoSend));
    check('auto-send succeeded', processed.data?.autoSend?.ok === true, processed.data?.autoSend?.error);
    check('the draft is marked sent', processed.data?.draft?.status === 'sent', processed.data?.draft?.status);

    const mail = await waitForMail(1);
    check('the reply was delivered without anyone approving it', mail.length === 1, `got ${mail.length}`);
    if (mail.length) {
      check('it went to the customer', mail[0].envelopeTo.includes('t.brady@example.com'));
      check('it mentions the order', /80145/.test(readMailDecoded(mail[0])));
    }

    // Auto-send must still refuse a draft with gaps in it.
    clearSink();
    const risky = await api('POST', '/api/emails/process', {
      from: 'Gordon Pryce <g.pryce@example.com>',
      subject: 'Third time writing, this is unacceptable',
      body:
        'This is the THIRD email about order 19845 and nobody has replied. I want a manager. ' +
        'If I do not hear back by Friday I am raising this with the consumer forum. Appalling.',
    });

    check('a draft with gaps is not auto-sent', risky.data?.autoSend?.ok !== true, JSON.stringify(risky.data?.autoSend));
    check('the reason is explained', /placeholder/i.test(risky.data?.autoSend?.error ?? ''), risky.data?.autoSend?.error);
    check('and nothing went out', sink().length === 0, `${sink().length} were sent`);

    await api('PATCH', '/api/settings', { autoSendEnabled: false });
  }

  console.log(`\n${BOLD}${'─'.repeat(60)}${RESET}`);
  if (failed === 0) {
    console.log(`${GREEN}${BOLD}All ${passed} mail checks passed.${RESET}\n`);
  } else {
    console.log(`${RED}${BOLD}${failed} of ${passed + failed} mail checks failed:${RESET}`);
    for (const failure of failures) console.log(`  ${RED}•${RESET} ${failure}`);
    console.log('');
  }
  process.exit(failed === 0 ? 0 : 1);
}

main().catch((err) => {
  console.error(`\n${RED}The test script itself crashed:${RESET}\n`, err);
  process.exit(1);
});
