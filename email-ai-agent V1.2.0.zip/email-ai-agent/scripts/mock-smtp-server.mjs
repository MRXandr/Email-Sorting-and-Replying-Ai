/**
 * A throwaway SMTP server that accepts mail and writes it to disk instead of
 * delivering it. Used to test the sending path — alert emails for flagged mail,
 * and replies to customers — without a real mail account.
 *
 *   node scripts/mock-smtp-server.mjs            # listens on 2525
 *
 *   SMTP_HOST=localhost SMTP_PORT=2525 SMTP_SECURE=false \
 *   SMTP_USER=test SMTP_PASSWORD=test SMTP_FROM=agent@example.test \
 *   npm start
 *
 * Received messages are written to /tmp/mock-smtp/ as .eml files and summarised
 * on stdout, and a JSON index is kept at /tmp/mock-smtp/index.json so a test
 * script can assert on what was sent.
 *
 * This implements only the subset of SMTP that nodemailer needs, in plaintext.
 * It is a test double, not a mail server — never expose it to a network.
 */
import { createServer } from 'node:net';
import { mkdirSync, writeFileSync, readFileSync, existsSync } from 'node:fs';
import path from 'node:path';

const PORT = Number(process.env.MOCK_SMTP_PORT || 2525);
const OUT_DIR = process.env.MOCK_SMTP_DIR || '/tmp/mock-smtp';
const INDEX = path.join(OUT_DIR, 'index.json');

mkdirSync(OUT_DIR, { recursive: true });
if (!existsSync(INDEX)) writeFileSync(INDEX, '[]');

let counter = 0;

function record(entry) {
  let list = [];
  try {
    list = JSON.parse(readFileSync(INDEX, 'utf8'));
  } catch {
    list = [];
  }
  list.push(entry);
  writeFileSync(INDEX, JSON.stringify(list, null, 2));
}

/** Pull a header value out of a raw message. */
function header(raw, name) {
  const match = raw.match(new RegExp(`^${name}:\\s*(.*(?:\\r?\\n[ \\t].*)*)$`, 'im'));
  return match ? match[1].replace(/\r?\n[ \t]+/g, ' ').trim() : '';
}

const server = createServer((socket) => {
  let buffer = '';
  let inData = false;
  let message = '';
  let envelope = { from: '', to: [] };

  const send = (line) => socket.write(`${line}\r\n`);

  send('220 mock-smtp ready');

  socket.on('data', (chunk) => {
    buffer += chunk.toString('utf8');

    // In DATA mode, everything up to a lone "." is the message.
    while (true) {
      if (inData) {
        const terminator = buffer.indexOf('\r\n.\r\n');
        if (terminator === -1) {
          // Keep accumulating; also handle a message that starts with ".".
          if (buffer === '.\r\n') {
            inData = false;
            buffer = '';
            send('250 OK: queued as mock-0');
          }
          return;
        }

        message += buffer.slice(0, terminator);
        buffer = buffer.slice(terminator + 5);
        inData = false;

        counter++;
        // Undo dot-stuffing, per RFC 5321.
        const raw = message.replace(/\r\n\.\./g, '\r\n.');
        const filename = path.join(OUT_DIR, `mail-${String(counter).padStart(3, '0')}.eml`);
        writeFileSync(filename, raw);

        const subject = header(raw, 'Subject');
        const to = header(raw, 'To');
        const from = header(raw, 'From');
        const hasAttachment = /Content-Disposition:\s*attachment/i.test(raw);
        const attachmentName = raw.match(/filename="?([^"\r\n;]+)"?/i)?.[1] ?? null;

        record({
          index: counter,
          file: filename,
          envelopeFrom: envelope.from,
          envelopeTo: envelope.to,
          from,
          to,
          subject,
          hasAttachment,
          attachmentName,
          bytes: raw.length,
          receivedAt: new Date().toISOString(),
        });

        console.log(
          `[mock-smtp] #${counter} to=${envelope.to.join(',')} subject="${subject.slice(0, 70)}"` +
            (hasAttachment ? ` attachment=${attachmentName}` : ''),
        );

        message = '';
        envelope = { from: '', to: [] };
        send(`250 OK: queued as mock-${counter}`);
        continue;
      }

      const lineEnd = buffer.indexOf('\r\n');
      if (lineEnd === -1) return;

      const line = buffer.slice(0, lineEnd);
      buffer = buffer.slice(lineEnd + 2);
      const upper = line.toUpperCase();

      if (upper.startsWith('EHLO') || upper.startsWith('HELO')) {
        // Advertise plain auth and sizes; deliberately no STARTTLS, so nodemailer
        // stays in plaintext for the test.
        send('250-mock-smtp greets you');
        send('250-AUTH PLAIN LOGIN');
        send('250-8BITMIME');
        send('250-SIZE 20971520');
        send('250 HELP');
      } else if (upper.startsWith('AUTH LOGIN')) {
        send('334 VXNlcm5hbWU6');
        // The next two lines are base64 username and password; accept anything.
        let step = 0;
        const authHandler = () => {
          const end = buffer.indexOf('\r\n');
          if (end === -1) return;
          buffer = buffer.slice(end + 2);
          step++;
          if (step === 1) {
            send('334 UGFzc3dvcmQ6');
            if (buffer.includes('\r\n')) authHandler();
          } else {
            send('235 2.7.0 Authentication successful');
            socket.off('authstep', authHandler);
          }
        };
        socket.on('authstep', authHandler);
        socket.emit('authstep');
        continue;
      } else if (upper.startsWith('AUTH PLAIN')) {
        send('235 2.7.0 Authentication successful');
      } else if (upper.startsWith('MAIL FROM')) {
        envelope.from = line.match(/<([^>]*)>/)?.[1] ?? '';
        send('250 OK');
      } else if (upper.startsWith('RCPT TO')) {
        const address = line.match(/<([^>]*)>/)?.[1] ?? '';
        envelope.to.push(address);
        send('250 OK');
      } else if (upper === 'DATA') {
        inData = true;
        message = '';
        send('354 End data with <CR><LF>.<CR><LF>');
      } else if (upper === 'RSET') {
        envelope = { from: '', to: [] };
        send('250 OK');
      } else if (upper === 'NOOP') {
        send('250 OK');
      } else if (upper === 'QUIT') {
        send('221 Bye');
        socket.end();
        return;
      } else if (upper.startsWith('STARTTLS')) {
        send('502 Command not implemented');
      } else {
        send('250 OK');
      }
    }
  });

  socket.on('error', () => {
    /* clients disconnect abruptly; nothing to do */
  });
});

server.listen(PORT, '127.0.0.1', () => {
  console.log(`[mock-smtp] listening on 127.0.0.1:${PORT}`);
  console.log(`[mock-smtp] writing messages to ${OUT_DIR}`);
});
