/**
 * Tests reading a real mailbox, against the mock IMAP server.
 *
 *   Terminal 1:  node scripts/mock-imap-server.mjs
 *   Terminal 2:  IMAP_HOST=127.0.0.1 IMAP_PORT=1143 IMAP_SECURE=false \
 *                IMAP_USER=test IMAP_PASSWORD=test IMAP_BATCH_SIZE=5 npm start
 *   Terminal 3:  node scripts/test-imap.mjs
 *
 * The mock holds seven messages: five ordinary customer emails and two that no
 * seeded type covers. The important properties checked here are that messages are
 * only marked read once they have actually been handled, that a backlog is worked
 * through in batches, and that nothing is ever processed twice.
 */
const BASE = (process.env.BASE_URL || 'http://localhost:3104').replace(/\/+$/, '');

/**
 * The mock server keeps its read/unread state in memory, so a previous run leaves
 * messages marked read. Set MOCK_IMAP_PID to its process id and this script will
 * reset the mailbox to all-unread before starting, and again for the duplicate
 * check at the end.
 */
const MOCK_PID = Number(process.env.MOCK_IMAP_PID || 0);

async function resetMockMailbox() {
  if (!MOCK_PID) return false;
  try {
    process.kill(MOCK_PID, 'SIGHUP');
    await new Promise((r) => setTimeout(r, 400));
    return true;
  } catch {
    return false;
  }
}

const GREEN = '\x1b[32m';
const RED = '\x1b[31m';
const DIM = '\x1b[2m';
const BOLD = '\x1b[1m';
const RESET = '\x1b[0m';

let passed = 0;
let failed = 0;
const failures = [];

function check(name, condition, detail = '') {
  if (condition) {
    passed++;
    console.log(`  ${GREEN}✓${RESET} ${name}`);
  } else {
    failed++;
    failures.push(`${name}${detail ? ` — ${detail}` : ''}`);
    console.log(`  ${RED}✗ ${name}${RESET}${detail ? `\n      ${DIM}${detail}${RESET}` : ''}`);
  }
}

function section(title) {
  console.log(`\n${BOLD}${title}${RESET}`);
}

/** Session cookie, set if the server is password protected. */
let cookie = '';

async function api(method, pathname, body) {
  const init = { method, headers: {} };
  if (cookie) init.headers.cookie = cookie;
  if (body !== undefined) {
    init.headers['content-type'] = 'application/json';
    init.body = JSON.stringify(body);
  }
  const response = await fetch(`${BASE}${pathname}`, init);

  const setCookie = response.headers.get('set-cookie');
  if (setCookie) {
    const match = setCookie.match(/mail_agent_session=([^;]*)/);
    if (match) cookie = `mail_agent_session=${match[1]}`;
  }

  const text = await response.text();
  let data = null;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    data = { __unparsed: text.slice(0, 300) };
  }
  return { status: response.status, data };
}

/** Sign in when the server has APP_PASSWORD set, so this works either way. */
async function signInIfNeeded(health) {
  if (!health?.authEnabled) return true;
  const password = process.env.APP_PASSWORD || '';
  if (!password) {
    console.log(
      `\n${RED}The server is password protected. Re-run with APP_PASSWORD=yourpassword${RESET}\n`,
    );
    process.exit(1);
  }
  const login = await api('POST', '/api/login', { password });
  return login.status === 200;
}

async function main() {
  console.log(`\n${BOLD}Mailbox-reading test against ${BASE}${RESET}`);

  section('Setup');
  {
    const health = await api('GET', '/api/health');
    check('the server is up', health.status === 200, `status ${health.status}`);
    check('signed in (if the server requires it)', await signInIfNeeded(health.data));
    check(
      'IMAP is configured on the server',
      health.data?.mailbox?.imap === true,
      'set IMAP_HOST, IMAP_USER and IMAP_PASSWORD when starting it',
    );
    if (health.data?.mailbox?.imap !== true) {
      console.log(`\n${RED}Start the server with the mock IMAP settings first.${RESET}\n`);
      process.exit(1);
    }

    const verify = await api('POST', '/api/mailbox/verify');
    check('the app can reach the mailbox', verify.data?.imap?.ok === true, verify.data?.imap?.error);
    check('it reports the folder it will read', verify.data?.imap?.mailbox === 'INBOX', verify.data?.imap?.mailbox);

    await api('POST', '/api/seed', { confirm: true });
    check('the demo types are loaded', true);

    const wasReset = await resetMockMailbox();
    check(
      'the mock mailbox was reset to all-unread',
      wasReset,
      'set MOCK_IMAP_PID to the mock server process id, or restart it, so counts start from seven',
    );
  }

  section('First fetch — a batch, not the whole backlog');
  let firstBatch;
  {
    firstBatch = await api('POST', '/api/mailbox/fetch', {});
    check('the fetch succeeds', firstBatch.status === 200, JSON.stringify(firstBatch.data).slice(0, 250));
    check('it reports the full unread count', firstBatch.data?.unseenTotal === 7, `got ${firstBatch.data?.unseenTotal}`);
    check('it handled only the batch size', firstBatch.data?.fetched === 5, `got ${firstBatch.data?.fetched}`);
    check('all five were processed', firstBatch.data?.processed === 5, `got ${firstBatch.data?.processed}`);
    check('none failed', firstBatch.data?.failed === 0, JSON.stringify(firstBatch.data?.outcomes?.filter((o) => !o.ok)));
    check(
      'it says there is more waiting',
      (firstBatch.data?.notes ?? []).some((n) => /processing the newest/i.test(n)),
      JSON.stringify(firstBatch.data?.notes),
    );

    // Newest-first, so this batch is uids 7..3: the two unknown emails plus three
    // ordinary ones.
    check('two of them were flagged for a person', firstBatch.data?.flagged === 2, `got ${firstBatch.data?.flagged}`);
    check('three were sorted automatically', firstBatch.data?.classified === 3, `got ${firstBatch.data?.classified}`);

    const bySubject = new Map((firstBatch.data?.outcomes ?? []).map((o) => [o.subject, o]));
    check(
      'the supplier pitch was flagged',
      bySubject.get('Wholesale partnership proposal - sustainable packaging')?.flagged === true,
      JSON.stringify(bySubject.get('Wholesale partnership proposal - sustainable packaging')),
    );
    check(
      'the job application was flagged',
      bySubject.get('Application for Warehouse Supervisor position')?.flagged === true,
    );
    check(
      'the escalation was recognised',
      bySubject.get('Fourth email, still nothing, I want a manager')?.typeName === 'Complaint & Service Escalation',
      bySubject.get('Fourth email, still nothing, I want a manager')?.typeName,
    );
    check(
      'the duplicate-charge email was recognised',
      bySubject.get('Two charges on my card for one order')?.typeName === 'Billing & Payment Issue',
      bySubject.get('Two charges on my card for one order')?.typeName,
    );
    check(
      'the pre-sales question was recognised',
      bySubject.get('Question about the desk before I order')?.typeName === 'Product Information (Pre-Sales)',
      bySubject.get('Question about the desk before I order')?.typeName,
    );
  }

  section('Headers and threading data survive the round trip');
  {
    const emails = await api('GET', '/api/emails?limit=50');
    const item = emails.data?.items?.find((i) => i.email.subject.includes('Two charges'));
    check('the email was stored', Boolean(item));

    if (item) {
      const detail = await api('GET', `/api/emails/${item.email.id}`);
      const email = detail.data?.email;
      check('the sender name was parsed from the header', email?.fromName === 'Ahmed Farouk', email?.fromName);
      check('the sender address was parsed', email?.fromEmail === 'ahmed.farouk@example.com', email?.fromEmail);
      check('the recipient was parsed', email?.toEmail === 'support@northwind-retail.example', email?.toEmail);
      check('the Message-ID was kept for deduplication', email?.externalId?.includes('mock-billing-1'), email?.externalId);
      check('it is recorded as having come from the mailbox', email?.source === 'imap', email?.source);
      check('the date came from the header, not the clock', email?.receivedAt?.startsWith('2026-09-15'), email?.receivedAt);
      check('the body text was decoded', /statement shows the amount deducted twice/.test(email?.body ?? ''));
      check('a reply was drafted', Boolean(detail.data?.draft?.body));
      // The billing template does not quote an order number, by design — but the
      // number must still have been extracted and be available to the template.
      check('the order number was extracted from the body', detail.data?.extracted?.order_id === '31556', detail.data?.extracted?.order_id);
      check('the customer name was worked out', detail.data?.extracted?.customer_first_name === 'Ahmed', detail.data?.extracted?.customer_first_name);
      check('the reply greets them by name', /Ahmed/.test(detail.data?.draft?.body ?? ''));
    }
  }

  section('Second fetch — the rest of the backlog');
  {
    const second = await api('POST', '/api/mailbox/fetch', {});
    check('the fetch succeeds', second.status === 200, JSON.stringify(second.data).slice(0, 200));
    check(
      'only the two still-unread messages remain',
      second.data?.unseenTotal === 2,
      `got ${second.data?.unseenTotal} — the first batch should already be marked read`,
    );
    check('both were handled', second.data?.fetched === 2, `got ${second.data?.fetched}`);
    check('both were sorted', second.data?.classified === 2, `got ${second.data?.classified}`);

    const bySubject = new Map((second.data?.outcomes ?? []).map((o) => [o.subject, o]));
    check(
      'the delivery chase was recognised',
      bySubject.get('Still no sign of order 92771')?.typeName === 'Order Status & Delivery',
      bySubject.get('Still no sign of order 92771')?.typeName,
    );
    check(
      'the return request was recognised',
      bySubject.get('Jacket is the wrong size, need to send it back')?.typeName === 'Returns & Refunds',
      bySubject.get('Jacket is the wrong size, need to send it back')?.typeName,
    );
  }

  section('Third fetch — nothing left, and nothing done twice');
  {
    const third = await api('POST', '/api/mailbox/fetch', {});
    check('the fetch succeeds', third.status === 200);
    check('the mailbox is empty of unread mail', third.data?.unseenTotal === 0, `got ${third.data?.unseenTotal}`);
    check('nothing was fetched', third.data?.fetched === 0, `got ${third.data?.fetched}`);
    check(
      'it says so plainly',
      (third.data?.notes ?? []).some((n) => /No unread messages/i.test(n)),
      JSON.stringify(third.data?.notes),
    );

    const emails = await api('GET', '/api/emails?limit=100');
    check(
      'exactly seven emails were stored in total',
      emails.data?.total === 7,
      `got ${emails.data?.total} — more would mean something was processed twice`,
    );

    const openReviews = await api('GET', '/api/review?status=open');
    check('two are waiting for a person', openReviews.data?.items?.length === 2, `got ${openReviews.data?.items?.length}`);

    const stats = await api('GET', '/api/stats');
    check('five were sorted automatically', stats.data?.stats?.classified === 5, `got ${stats.data?.stats?.classified}`);
    check('two are flagged', stats.data?.stats?.flaggedOpen === 2, `got ${stats.data?.stats?.flaggedOpen}`);
  }

  section('Re-fetching an already-seen message is recognised as a duplicate');
  {
    // Mark everything unread again on the server, so the same messages come back.
    // The app must recognise them by Message-ID rather than processing them again.
    if (await resetMockMailbox()) {
      const again = await api('POST', '/api/mailbox/fetch', { batchSize: 25 });
      check('the re-fetch succeeds', again.status === 200, JSON.stringify(again.data).slice(0, 200));
      check('all seven come back as unread', again.data?.unseenTotal === 7, `got ${again.data?.unseenTotal}`);
      check(
        'every one is recognised as already handled',
        again.data?.skipped === 7,
        `got ${again.data?.skipped} skipped, ${again.data?.classified} reclassified`,
      );

      const emails = await api('GET', '/api/emails?limit=100');
      check(
        'and no duplicates were stored',
        emails.data?.total === 7,
        `got ${emails.data?.total}`,
      );
    } else {
      console.log(`      ${DIM}skipped: set MOCK_IMAP_PID to enable this section${RESET}`);
    }
  }

  console.log(`\n${BOLD}${'─'.repeat(60)}${RESET}`);
  if (failed === 0) {
    console.log(`${GREEN}${BOLD}All ${passed} mailbox checks passed.${RESET}\n`);
  } else {
    console.log(`${RED}${BOLD}${failed} of ${passed + failed} mailbox checks failed:${RESET}`);
    for (const failure of failures) console.log(`  ${RED}•${RESET} ${failure}`);
    console.log('');
  }
  process.exit(failed === 0 ? 0 : 1);
}

main().catch((err) => {
  console.error(`\n${RED}The test script itself crashed:${RESET}\n`, err);
  process.exit(1);
});
