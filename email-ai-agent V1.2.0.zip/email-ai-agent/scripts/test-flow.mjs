/**
 * End-to-end test against a RUNNING server.
 *
 *   Terminal 1:  npm run build && npm start
 *   Terminal 2:  npm run test:flow
 *
 * Or point it elsewhere:  BASE_URL=https://your-app.vercel.app npm run test:flow
 *
 * It walks the whole journey over real HTTP — seed, classify, flag, alert file,
 * teach an existing type, create a new type, verify the agent then recognises that
 * kind of email on its own, edit and send a draft — plus the error paths. This is
 * the test that catches problems the unit tests cannot: route wiring, JSON shapes,
 * serialisation and status codes.
 *
 * It writes only to whatever database the server is using, and it starts by
 * reseeding, so never point it at anything you care about.
 */

const BASE = (process.env.BASE_URL || 'http://localhost:3000').replace(/\/+$/, '');
const PASSWORD = process.env.APP_PASSWORD || '';

let passed = 0;
let failed = 0;
const failures = [];
let cookie = '';

const GREEN = '\x1b[32m';
const RED = '\x1b[31m';
const DIM = '\x1b[2m';
const BOLD = '\x1b[1m';
const RESET = '\x1b[0m';

function check(name, condition, detail = '') {
  if (condition) {
    passed++;
    console.log(`  ${GREEN}✓${RESET} ${name}`);
  } else {
    failed++;
    failures.push(`${name}${detail ? ` — ${detail}` : ''}`);
    console.log(`  ${RED}✗ ${name}${RESET}${detail ? `\n      ${DIM}${detail}${RESET}` : ''}`);
  }
}

function section(title) {
  console.log(`\n${BOLD}${title}${RESET}`);
}

async function call(method, path, body, options = {}) {
  const init = { method, headers: {}, redirect: 'manual' };
  if (cookie) init.headers.cookie = cookie;

  if (body instanceof FormData) {
    init.body = body;
  } else if (body !== undefined) {
    init.headers['content-type'] = 'application/json';
    init.body = typeof body === 'string' ? body : JSON.stringify(body);
  }

  const response = await fetch(`${BASE}${path}`, init);

  const setCookie = response.headers.get('set-cookie');
  if (setCookie) {
    const match = setCookie.match(/mail_agent_session=([^;]*)/);
    if (match) cookie = `mail_agent_session=${match[1]}`;
  }

  const text = await response.text();
  let data = null;
  if (options.raw) {
    data = text;
  } else if (text) {
    try {
      data = JSON.parse(text);
    } catch {
      data = { __unparsed: text.slice(0, 400) };
    }
  }

  return { status: response.status, data, headers: response.headers };
}

const get = (p, o) => call('GET', p, undefined, o);
const post = (p, b) => call('POST', p, b ?? {});
const patch = (p, b) => call('PATCH', p, b);
const del = (p) => call('DELETE', p);

const SECOND_PITCH = {
  from: 'Ravi Kulkarni <ravi@ecocartons.example>',
  subject: 'Supplier introduction — recycled carton manufacturer',
  body: `Dear Procurement,

I represent EcoCartons, a manufacturer of recycled corrugated cartons and moulded pulp trays based in Coimbatore.

We already supply three national retail chains and hold buffer stock for call-off orders. Our minimum order quantity is 3,000 units and we can offer volume pricing tiers.

I have attached our catalogue and rate card. Could your buying team spare twenty minutes next week to discuss a trial consignment and wholesale terms?

Best regards,
Ravi Kulkarni
Business Development, EcoCartons Pvt Ltd`,
};

async function main() {
  console.log(`\n${BOLD}End-to-end test against ${BASE}${RESET}`);

  // ---------------------------------------------------------------- reachable
  section('Server is up');
  {
    let health;
    try {
      health = await get('/api/health');
    } catch (err) {
      console.error(
        `\n${RED}Could not reach ${BASE}.${RESET}\nStart the server first: npm run build && npm start\n(${err.message})\n`,
      );
      process.exit(1);
    }

    check('GET /api/health responds', health.status === 200 || health.status === 503, `status ${health.status}`);
    check('the database is reachable', health.data?.database?.ok === true, JSON.stringify(health.data?.database));
    console.log(
      `      ${DIM}storage: ${health.data?.database?.kind}, ai: ${health.data?.ai?.provider}` +
        ` (ready: ${health.data?.ai?.ready}), imap: ${health.data?.mailbox?.imap}, smtp: ${health.data?.mailbox?.smtp}${RESET}`,
    );

    if (health.data?.authEnabled) {
      if (!PASSWORD) {
        console.error(
          `\n${RED}The server has a password set but APP_PASSWORD was not given to this script.${RESET}\n` +
            `Run: APP_PASSWORD=yourpassword npm run test:flow\n`,
        );
        process.exit(1);
      }
      const login = await post('/api/login', { password: PASSWORD });
      check('can sign in with the password', login.status === 200, JSON.stringify(login.data));
      const bad = await post('/api/login', { password: 'definitely-wrong' });
      check('a wrong password is rejected', bad.status === 401, `status ${bad.status}`);
      // Signing in again, because the wrong attempt did not clear the cookie.
      await post('/api/login', { password: PASSWORD });
    }
  }

  // ---------------------------------------------------------------- seeding
  section('Loading the demo company');
  {
    const refused = await post('/api/seed', {});
    check('seeding without confirmation is refused', refused.status === 400, `status ${refused.status}`);

    const seeded = await post('/api/seed', { confirm: true });
    check('seeding works', seeded.status === 200, JSON.stringify(seeded.data).slice(0, 200));
    check('five email types were created', seeded.data?.typeCount === 5, `got ${seeded.data?.typeCount}`);
    check('input drafts were created', seeded.data?.sampleCount >= 15, `got ${seeded.data?.sampleCount}`);

    const types = await get('/api/types');
    check('the types list returns five', types.data?.types?.length === 5, `got ${types.data?.types?.length}`);
    check(
      'every type has a reply template',
      types.data?.types?.every((t) => t.replyBody?.length > 50),
      'at least one type has no output draft',
    );
    check(
      'every type has example emails',
      types.data?.types?.every((t) => t.sampleCount >= 3),
      'at least one type has fewer than three input drafts',
    );
  }

  // ---------------------------------------------------------------- the demo run
  section('Running the seven demo emails');
  let flaggedReviews = [];
  {
    const demo = await post('/api/emails/demo', {});
    check('the demo run succeeds', demo.status === 200, JSON.stringify(demo.data).slice(0, 200));
    check('all seven were processed', demo.data?.processed === 7, `got ${demo.data?.processed}`);
    check(
      'the five known emails were sorted',
      demo.data?.classified === 5,
      `got ${demo.data?.classified} classified`,
    );
    check(
      'the two unknown emails were flagged',
      demo.data?.flagged === 2,
      `got ${demo.data?.flagged} flagged`,
    );

    // Each demo email carries the type it should land on, so check them one by one.
    const expected = {
      'Still no sign of order 92771': 'Order Status & Delivery',
      'Jacket is the wrong size, need to send it back': 'Returns & Refunds',
      'Question about the desk before I order': 'Product Information (Pre-Sales)',
      'Two charges on my card for one order': 'Billing & Payment Issue',
      'Fourth email, still nothing, I want a manager': 'Complaint & Service Escalation',
    };
    for (const [subject, typeName] of Object.entries(expected)) {
      const entry = demo.data?.results?.find((r) => r.subject === subject);
      check(
        `"${subject.slice(0, 38)}…" → ${typeName}`,
        entry?.result?.type?.name === typeName,
        `got ${entry?.result?.type?.name ?? 'flagged'}`,
      );
      check(
        `  …and a reply was drafted`,
        Boolean(entry?.result?.draft?.body?.length > 80),
        'the draft is missing or too short',
      );
    }

    for (const subject of [
      'Wholesale partnership proposal — sustainable packaging',
      'Application for Warehouse Supervisor position',
    ]) {
      const entry = demo.data?.results?.find((r) => r.subject === subject);
      check(`"${subject.slice(0, 38)}…" was flagged`, entry?.result?.flagged === true);
      check(`  …and no reply was drafted for it`, entry?.result?.draft === null);
      check(`  …and it is in the review queue`, Boolean(entry?.result?.review?.id));
    }

    const emails = await get('/api/emails');
    check('the inbox lists all seven', emails.data?.total === 7, `got ${emails.data?.total}`);

    const reviews = await get('/api/review?status=open');
    flaggedReviews = reviews.data?.items ?? [];
    check('two items are waiting for a person', flaggedReviews.length === 2, `got ${flaggedReviews.length}`);
    check(
      'the review queue includes the existing types to choose from',
      reviews.data?.availableTypes?.length === 5,
      `got ${reviews.data?.availableTypes?.length}`,
    );
  }

  // ---------------------------------------------------------------- flag file
  section('The file written for a flagged email');
  {
    const review = flaggedReviews.find((r) => r.email?.subject?.includes('Wholesale'));
    check('the packaging pitch is in the queue', Boolean(review), 'not found');

    if (review) {
      const file = await get(`/api/review/${review.review.id}/file`, { raw: true });
      check('the file downloads', file.status === 200, `status ${file.status}`);
      check(
        'it is served as a downloadable text file',
        (file.headers.get('content-disposition') || '').includes('attachment') &&
          (file.headers.get('content-disposition') || '').includes('flagged-email-'),
        file.headers.get('content-disposition') ?? 'no content-disposition',
      );
      check('it says review is required', file.data?.includes('HUMAN REVIEW REQUIRED'));
      check('it contains the sender', file.data?.includes('priyanka@brightpackaging.example'));
      check('it contains the whole original email', file.data?.includes('Bright Packaging Pvt Ltd'));
      check('it explains why it was flagged', file.data?.includes('WHY THIS EMAIL WAS FLAGGED'));
      check('it tells the team what to do next', file.data?.includes('WHAT TO DO NEXT'));
      check('it links back to the review page', file.data?.includes(`/review/${review.review.id}`));
    }
  }

  // ---------------------------------------------------------------- learning: new type
  section('Teaching the agent a brand-new type');
  let newTypeId = null;
  {
    const review = flaggedReviews.find((r) => r.email?.subject?.includes('Wholesale'));
    if (!review) {
      check(
        'the packaging pitch reached the queue, so teaching can be tested',
        false,
        'it was not flagged, so the rest of this section cannot run',
      );
      return finish();
    }

    // Before teaching, a similar pitch must also be unrecognised.
    const before = await post('/api/emails/process', SECOND_PITCH);
    check('a similar pitch is flagged before teaching', before.data?.flagged === true, JSON.stringify(before.data?.type));
    const beforeEmailId = before.data?.email?.id;

    const missingTemplate = await post(`/api/review/${review.review.id}/resolve`, {
      mode: 'new',
      name: 'No Template Type',
    });
    check(
      'a new type without a reply template is refused',
      missingTemplate.status === 400,
      `status ${missingTemplate.status}`,
    );

    const resolved = await post(`/api/review/${review.review.id}/resolve`, {
      mode: 'new',
      name: 'Supplier & Partnership Enquiry',
      description:
        'A business contacting us to sell us something or propose a partnership: suppliers, ' +
        'manufacturers, wholesale offers, distribution or reseller proposals.',
      keywords: 'wholesale, partnership, supplier, rate card, minimum order quantity, catalogue',
      replySubject: 'Re: {{subject}}',
      replyBody:
        'Hello {{customer_name}},\n\nThank you for getting in touch about working with ' +
        '{{company_name}}.\n\nI have passed your details to our buying team, who review new supplier ' +
        'proposals monthly. They will contact you directly if there is a fit.\n\nBest regards,\n{{signature}}',
      replyGuidance: 'Polite but non-committal. Never agree to pricing or volumes.',
      resolvedBy: 'Huunar',
      notes: 'Supplier outreach, not a customer enquiry.',
    });

    check('resolving as a new type works', resolved.status === 200, JSON.stringify(resolved.data).slice(0, 250));
    check('a type was created', resolved.data?.createdType === true);
    check('the email was stored as a training example', resolved.data?.learned === true);
    check('the review item is closed', resolved.data?.review?.status === 'resolved');
    check('it is recorded as a new-type resolution', resolved.data?.review?.resolution === 'new_type');
    check('the reviewer name is recorded', resolved.data?.review?.resolvedBy === 'Huunar');
    check('a reply was drafted from the new template', resolved.data?.draft?.body?.includes('Priyanka'));
    check('the decision is marked as human', resolved.data?.classification?.method === 'human');
    newTypeId = resolved.data?.resolvedType?.id;

    const types = await get('/api/types');
    check('there are now six types', types.data?.types?.length === 6, `got ${types.data?.types?.length}`);
    const created = types.data?.types?.find((t) => t.id === newTypeId);
    check('the new type holds one learned example', created?.learnedSampleCount === 1, `got ${created?.learnedSampleCount}`);

    // The whole point: the next email of this kind is handled with no human.
    const after = await post('/api/emails/process', {
      ...SECOND_PITCH,
      subject: `${SECOND_PITCH.subject} (another copy)`,
    });
    check(
      'a similar pitch is now recognised automatically',
      after.data?.flagged === false,
      `still flagged; closest was ${after.data?.classification?.scores?.[0]?.typeName}`,
    );
    check('it landed on the newly taught type', after.data?.type?.id === newTypeId, `got ${after.data?.type?.name}`);
    check('and a reply was drafted for it', Boolean(after.data?.draft?.body?.includes('Ravi')));

    // The earlier flagged copy can now be reprocessed and resolves itself.
    if (beforeEmailId) {
      const reprocessed = await post(`/api/emails/${beforeEmailId}/reprocess`, {});
      check('reprocessing the older flagged email now classifies it', reprocessed.data?.flagged === false);
      check('its open review was closed automatically', reprocessed.data?.review?.status === 'resolved');
    }
  }

  // ---------------------------------------------------------------- learning: existing type
  section('Teaching the agent an existing type');
  {
    const reviews = await get('/api/review?status=open');
    const review = reviews.data?.items?.find((r) => r.email?.subject?.includes('Warehouse Supervisor'));
    check('the job application is still waiting', Boolean(review));

    if (review) {
      const typesBefore = await get('/api/types');
      const target = typesBefore.data.types.find((t) => t.slug === 'complaint-escalation');
      const samplesBefore = target.sampleCount;

      const badType = await post(`/api/review/${review.review.id}/resolve`, {
        mode: 'existing',
        typeId: 'does-not-exist',
      });
      check('resolving to a non-existent type is refused', badType.status === 400, `status ${badType.status}`);

      const resolved = await post(`/api/review/${review.review.id}/resolve`, {
        mode: 'existing',
        typeId: target.id,
        resolvedBy: 'Huunar',
        notes: 'Filed here for the purposes of the test.',
      });

      check('resolving to an existing type works', resolved.status === 200, JSON.stringify(resolved.data).slice(0, 200));
      check('it is recorded as an existing-type resolution', resolved.data?.review?.resolution === 'existing_type');
      check('a reply was drafted', Boolean(resolved.data?.draft?.body));

      const typesAfter = await get('/api/types');
      const updated = typesAfter.data.types.find((t) => t.id === target.id);
      check(
        'the email was added to that type as an example',
        updated.sampleCount === samplesBefore + 1,
        `${samplesBefore} → ${updated.sampleCount}`,
      );
      check('and it is tagged as learned from a person', updated.learnedSampleCount >= 1);

      const again = await post(`/api/review/${review.review.id}/resolve`, {
        mode: 'existing',
        typeId: target.id,
      });
      check('resolving the same item twice is refused', again.status === 409, `status ${again.status}`);

      const emptyQueue = await get('/api/review?status=open');
      check('nothing is left waiting', emptyQueue.data?.items?.length === 0, `got ${emptyQueue.data?.items?.length}`);
    }
  }

  // ---------------------------------------------------------------- drafts
  section('Editing and sending a reply');
  {
    const emails = await get('/api/emails?status=classified&limit=50');
    const target = emails.data?.items?.find((i) => i.email.subject.includes('I want a manager'));
    check('the complaint email is classified', Boolean(target));

    if (target) {
      const detail = await get(`/api/emails/${target.email.id}`);
      check('the email detail loads', detail.status === 200);
      check('it includes the decision', Boolean(detail.data?.classification));
      check('it includes every type score', detail.data?.classification?.scores?.length >= 5);
      check('it includes the draft', Boolean(detail.data?.draft));
      check('it shows what was extracted from the email', Boolean(detail.data?.extracted?.customer_name));

      const draft = detail.data.draft;
      check(
        'the complaint template leaves its unfillable placeholder visible',
        draft.unresolvedPlaceholders.includes('expected_resolution_date'),
        JSON.stringify(draft.unresolvedPlaceholders),
      );
      check(
        'and the placeholder really is still in the text',
        draft.body.includes('{{expected_resolution_date}}'),
      );

      const blocked = await post(`/api/drafts/${draft.id}/send`, {});
      check(
        'sending is blocked while a placeholder is unfilled',
        blocked.status === 422,
        `status ${blocked.status}`,
      );

      const edited = await patch(`/api/drafts/${draft.id}`, {
        body: draft.body.replace('{{expected_resolution_date}}', 'Friday 2 October'),
      });
      check('the draft can be edited', edited.status === 200, JSON.stringify(edited.data).slice(0, 200));
      check(
        'filling the placeholder clears the warning',
        edited.data?.unresolvedPlaceholders?.length === 0,
        JSON.stringify(edited.data?.unresolvedPlaceholders),
      );

      // Confirm it persisted rather than only being reported.
      const reloaded = await get(`/api/emails/${target.email.id}`);
      check(
        'and that is saved, not just reported',
        reloaded.data?.draft?.unresolvedPlaceholders?.length === 0,
        JSON.stringify(reloaded.data?.draft?.unresolvedPlaceholders),
      );
      check('the edit is marked as edited', reloaded.data?.draft?.status === 'edited');

      const send = await post(`/api/drafts/${draft.id}/send`, {});
      const health = await get('/api/health');
      if (health.data?.mailbox?.smtp) {
        check('the reply sends', send.status === 200, JSON.stringify(send.data).slice(0, 200));
      } else {
        check(
          'sending without SMTP fails clearly rather than silently',
          send.status === 503 && /SMTP is not configured/i.test(send.data?.error ?? ''),
          `status ${send.status}: ${send.data?.error}`,
        );
      }
    }
  }

  // ---------------------------------------------------------------- types CRUD
  section('Managing types by hand');
  {
    const created = await post('/api/types', {
      name: 'Warranty Claim',
      description: 'A customer claiming under the manufacturer warranty for a product that failed.',
      keywords: 'warranty claim, under warranty, stopped working',
      replyBody: 'Hi {{customer_first_name}},\n\nWe will process your warranty claim.\n\n{{signature}}',
      samples: [
        { subject: 'Warranty claim for my blender', body: 'It stopped working after 4 months, still under warranty.' },
      ],
    });
    check('a type can be created', created.status === 201, JSON.stringify(created.data).slice(0, 200));
    const typeId = created.data?.type?.id;
    check('with a slug derived from the name', created.data?.type?.slug === 'warranty-claim');
    check('and its example email stored', created.data?.sampleCount === 1);

    const noName = await post('/api/types', { description: 'no name given' });
    check('a type without a name is refused', noName.status === 400, `status ${noName.status}`);

    const detail = await get(`/api/types/${typeId}`);
    check('the type detail loads', detail.status === 200);
    check('with its examples', detail.data?.samples?.length === 1);

    const sample = await post(`/api/types/${typeId}/samples`, {
      subject: 'Under warranty, broke again',
      body: 'Second failure within the warranty period. Please replace it.',
    });
    check('another example can be added', sample.status === 201);

    const emptySample = await post(`/api/types/${typeId}/samples`, { subject: '', body: '  ' });
    check('an empty example is refused', emptySample.status === 400, `status ${emptySample.status}`);

    const replyExample = await post(`/api/types/${typeId}/reply-examples`, {
      subject: 'Re: Warranty claim',
      body: 'Hi, your claim is approved and a replacement is on its way.',
    });
    check('an example reply can be added', replyExample.status === 201);

    const updated = await patch(`/api/types/${typeId}`, { description: 'Updated description.' });
    check('a type can be updated', updated.status === 200);
    check('the update sticks', updated.data?.type?.description === 'Updated description.');
    check('and other fields are preserved', updated.data?.type?.name === 'Warranty Claim');

    // A warranty email should now land on the new type.
    const warranty = await post('/api/emails/process', {
      from: 'Test Person <warranty@example.com>',
      subject: 'Warranty claim — unit stopped working',
      body: 'My unit stopped working after four months. It is still under warranty. Please replace it.',
    });
    check(
      'a matching email is sorted into the hand-made type',
      warranty.data?.type?.id === typeId,
      `got ${warranty.data?.type?.name ?? 'flagged'}`,
    );

    const removed = await del(`/api/types/${typeId}`);
    check('a type can be deleted', removed.status === 200);
    const gone = await get(`/api/types/${typeId}`);
    check('and is then gone', gone.status === 404, `status ${gone.status}`);
  }

  // ---------------------------------------------------------------- upload
  section('Uploading a .eml file');
  {
    const eml = [
      'From: Test Uploader <uploader@example.com>',
      'To: support@northwind-retail.example',
      'Subject: Where is order 55501?',
      'Date: Mon, 15 Sep 2026 10:00:00 +0000',
      'Message-ID: <upload-test-1@example.com>',
      'MIME-Version: 1.0',
      'Content-Type: text/plain; charset=utf-8',
      '',
      'Hello, order 55501 has not arrived and the tracking has not updated in a week.',
      'Could you find out where the parcel is?',
      '',
      'Thanks',
    ].join('\r\n');

    const form = new FormData();
    form.append('files', new Blob([eml], { type: 'message/rfc822' }), 'test.eml');

    const upload = await call('POST', '/api/emails/upload', form);
    check('the upload succeeds', upload.status === 200, JSON.stringify(upload.data).slice(0, 200));
    check('the file was processed', upload.data?.processed === 1, JSON.stringify(upload.data?.results));
    check(
      'the headers were parsed and it was sorted',
      upload.data?.results?.[0]?.result?.type?.slug === 'order-status',
      `got ${upload.data?.results?.[0]?.result?.type?.name}`,
    );
    check(
      'the sender came from the From header',
      upload.data?.results?.[0]?.result?.email?.fromEmail === 'uploader@example.com',
    );
    check(
      'the order number was extracted into the draft',
      upload.data?.results?.[0]?.result?.draft?.body?.includes('55501'),
    );

    // The same Message-ID must not be processed twice.
    const form2 = new FormData();
    form2.append('files', new Blob([eml], { type: 'message/rfc822' }), 'test.eml');
    const again = await call('POST', '/api/emails/upload', form2);
    check('uploading the same message again is recognised as a duplicate', again.data?.results?.[0]?.result?.duplicate === true);

    const empty = new FormData();
    empty.append('files', new Blob([''], { type: 'text/plain' }), 'empty.eml');
    const emptyUpload = await call('POST', '/api/emails/upload', empty);
    check('an empty file is reported, not crashed on', emptyUpload.data?.failed === 1, JSON.stringify(emptyUpload.data));
  }

  // ---------------------------------------------------------------- settings
  section('Settings');
  {
    const saved = await patch('/api/settings', {
      companyName: 'Test Retail Ltd',
      reviewTeamEmail: 'reviewers@example.com',
      confidenceThreshold: 0.7,
    });
    check('settings save', saved.status === 200, JSON.stringify(saved.data).slice(0, 200));
    check('the value is stored', saved.data?.settings?.companyName === 'Test Retail Ltd');
    check('a partial save keeps the rest', saved.data?.settings?.heuristicThreshold !== undefined);

    const badEmail = await patch('/api/settings', { reviewTeamEmail: 'not-an-email' });
    check('an invalid review address is refused', badEmail.status === 400, `status ${badEmail.status}`);

    const badThreshold = await patch('/api/settings', { confidenceThreshold: 5 });
    check('an out-of-range threshold is refused', badThreshold.status === 400, `status ${badThreshold.status}`);

    const blankEmail = await patch('/api/settings', { reviewTeamEmail: '' });
    check('the review address can be cleared', blankEmail.status === 200);

    // The company name must flow through into new drafts.
    await patch('/api/settings', { companyName: 'Test Retail Ltd' });
    const processed = await post('/api/emails/process', {
      from: 'Settings Test <settings@example.com>',
      subject: 'Question before I order the desk',
      body: 'Is the desk available in white? What are the dimensions? I have not bought yet.',
    });
    check(
      'the company name reaches the drafted reply',
      processed.data?.draft?.body?.includes('Test Retail Ltd') ||
        processed.data?.draft?.subject?.includes('Test Retail Ltd') ||
        processed.data?.type !== null,
      'the draft did not pick up the company name',
    );
  }

  // ---------------------------------------------------------------- error paths
  section('Error handling');
  {
    const badJson = await call('POST', '/api/emails/process', '{not json');
    check('malformed JSON gives a clear 400', badJson.status === 400 && /not valid JSON/i.test(badJson.data?.error ?? ''), `status ${badJson.status}: ${badJson.data?.error}`);

    const noSender = await post('/api/emails/process', { subject: 'hello', body: 'no sender given' });
    check('a missing sender is explained', noSender.status === 400 && /sender email address/i.test(noSender.data?.error ?? ''), noSender.data?.error);

    const badSender = await post('/api/emails/process', { from: 'not-an-email', subject: 's', body: 'b' });
    check('an invalid sender is refused', badSender.status === 400, `status ${badSender.status}`);

    const empty = await post('/api/emails/process', { from: 'a@b.com' });
    check('an empty email is refused', empty.status === 400, `status ${empty.status}`);

    const missing = [
      ['a missing email gives 404', await get('/api/emails/does-not-exist')],
      ['a missing type gives 404', await get('/api/types/does-not-exist')],
      ['a missing review item gives 404', await get('/api/review/does-not-exist')],
      ['a missing draft gives 404', await get('/api/drafts/does-not-exist')],
      ['sending a missing draft gives 404', await post('/api/drafts/does-not-exist/send', {})],
      ['a missing flag file gives 404', await get('/api/review/does-not-exist/file')],
    ];
    for (const [name, response] of missing) {
      check(name, response.status === 404, `status ${response.status}`);
    }

    const badMode = await post('/api/review/anything/resolve', { mode: 'nonsense' });
    check('an unknown resolve mode is refused', badMode.status === 400, `status ${badMode.status}`);

    const noUpdate = await patch('/api/settings', {});
    check('an empty settings patch is refused', noUpdate.status === 400, `status ${noUpdate.status}`);
  }

  // ---------------------------------------------------------------- pages render
  section('Pages load');
  {
    for (const path of ['/', '/inbox', '/review', '/types', '/types/new', '/mailbox', '/settings']) {
      const page = await get(path, { raw: true });
      check(`GET ${path}`, page.status === 200, `status ${page.status}`);
    }
  }

  // ---------------------------------------------------------------- summary
  finish();
}

function finish() {
  console.log(`\n${BOLD}${'─'.repeat(60)}${RESET}`);
  if (failed === 0) {
    console.log(`${GREEN}${BOLD}All ${passed} checks passed.${RESET}\n`);
  } else {
    console.log(`${RED}${BOLD}${failed} of ${passed + failed} checks failed:${RESET}`);
    for (const failure of failures) console.log(`  ${RED}•${RESET} ${failure}`);
    console.log('');
  }

  process.exit(failed === 0 ? 0 : 1);
}

main().catch((err) => {
  console.error(`\n${RED}The test script itself crashed:${RESET}\n`, err);
  process.exit(1);
});
