#!/usr/bin/env bash
#
# Runs every test suite in one go, using local stand-ins for the AI provider, the
# outgoing mail server and the incoming mailbox. Nothing here touches the internet,
# costs anything, or needs an API key.
#
#   npm run verify
#
# What it does:
#   1. typechecks the project
#   2. runs the unit tests
#   3. checks the classifier is still well calibrated on your email types
#   4. builds the app
#   5. starts fake AI / SMTP / IMAP servers, and the app pointed at them
#   6. runs the three end-to-end suites over real HTTP
#   7. stops everything
#
# By default it stores data in a local JSON file. To verify against Postgres too
# (recommended before deploying, since that is what production uses):
#
#   VERIFY_DATABASE_URL="postgresql://user:pass@host/db" npm run verify
#
set -uo pipefail

cd "$(dirname "$0")/.."

PORT="${VERIFY_PORT:-3199}"
AI_PORT="${VERIFY_AI_PORT:-4099}"
SMTP_PORT="${VERIFY_SMTP_PORT:-2599}"
IMAP_PORT="${VERIFY_IMAP_PORT:-1199}"
BASE="http://localhost:${PORT}"
SMTP_DIR="$(mktemp -d)"
DATA_DIR_PATH="$(mktemp -d)"

GREEN='\033[32m'; RED='\033[31m'; BOLD='\033[1m'; DIM='\033[2m'; NC='\033[0m'

FAILURES=()
AI_PID=""; SMTP_PID=""; IMAP_PID=""; APP_PID=""

step() { printf "\n${BOLD}==> %s${NC}\n" "$1"; }
note() { printf "${DIM}    %s${NC}\n" "$1"; }

record() {
  if [ "$1" -eq 0 ]; then
    printf "${GREEN}    ✓ %s${NC}\n" "$2"
  else
    printf "${RED}    ✗ %s${NC}\n" "$2"
    FAILURES+=("$2")
  fi
}

cleanup() {
  step "Stopping the test servers"
  for pid in "$APP_PID" "$AI_PID" "$SMTP_PID" "$IMAP_PID"; do
    [ -n "$pid" ] && kill "$pid" 2>/dev/null
  done
  sleep 1
  bash scripts/dev-stop.sh >/dev/null 2>&1
  rm -rf "$SMTP_DIR" "$DATA_DIR_PATH"
  note "done"
}
trap cleanup EXIT

printf "${BOLD}Verifying the email triage agent${NC}\n"
note "app on port ${PORT}, fake AI on ${AI_PORT}, fake SMTP on ${SMTP_PORT}, fake IMAP on ${IMAP_PORT}"

# ---------------------------------------------------------------- static checks
step "1/7  Typechecking"
npm run typecheck >/tmp/verify-typecheck.log 2>&1
record $? "typecheck"
[ $? -ne 0 ] && tail -20 /tmp/verify-typecheck.log

step "2/7  Unit tests"
if [ -n "${VERIFY_DATABASE_URL:-}" ]; then
  note "including the Postgres storage suite"
  TEST_DATABASE_URL="$VERIFY_DATABASE_URL" npm test >/tmp/verify-unit.log 2>&1
else
  note "file storage only — set VERIFY_DATABASE_URL to also test Postgres"
  npm test >/tmp/verify-unit.log 2>&1
fi
UNIT_STATUS=$?
record $UNIT_STATUS "unit tests ($(grep -E '^# pass' /tmp/verify-unit.log | tail -1 | tr -dc '0-9') passed)"
[ $UNIT_STATUS -ne 0 ] && grep -A 12 "not ok" /tmp/verify-unit.log | head -40

step "3/7  Classifier calibration"
node scripts/calibrate.mjs >/tmp/verify-calibrate.log 2>&1
CAL_STATUS=$?
record $CAL_STATUS "calibration"
grep -E "known emails|unknown emails|gap between|held-out" /tmp/verify-calibrate.log | sed 's/^/    /'
[ $CAL_STATUS -ne 0 ] && grep -E "FAIL" /tmp/verify-calibrate.log | head -20

# ---------------------------------------------------------------- build and run
step "4/7  Building"
npm run build >/tmp/verify-build.log 2>&1
BUILD_STATUS=$?
record $BUILD_STATUS "production build"
if [ $BUILD_STATUS -ne 0 ]; then
  tail -30 /tmp/verify-build.log
  exit 1
fi

step "5/7  Starting the stand-in servers"
MOCK_AI_PORT="$AI_PORT" node scripts/mock-ai-server.mjs >/tmp/verify-ai.log 2>&1 &
AI_PID=$!
MOCK_SMTP_PORT="$SMTP_PORT" MOCK_SMTP_DIR="$SMTP_DIR" node scripts/mock-smtp-server.mjs >/tmp/verify-smtp.log 2>&1 &
SMTP_PID=$!
MOCK_IMAP_PORT="$IMAP_PORT" node scripts/mock-imap-server.mjs >/tmp/verify-imap.log 2>&1 &
IMAP_PID=$!
sleep 2
record 0 "fake AI, SMTP and IMAP servers started"

step "6/7  Starting the app against them"
DB_ENV=()
if [ -n "${VERIFY_DATABASE_URL:-}" ]; then
  DB_ENV=("DATABASE_URL=$VERIFY_DATABASE_URL")
  note "using Postgres"
else
  DB_ENV=("DATA_DIR=$DATA_DIR_PATH")
  note "using a temporary JSON data file"
fi

env "${DB_ENV[@]}" \
  PORT="$PORT" \
  AI_PROVIDER=gemini GEMINI_API_KEY=verify-key \
  GEMINI_BASE_URL="http://localhost:${AI_PORT}/v1beta" \
  SMTP_HOST=127.0.0.1 SMTP_PORT="$SMTP_PORT" SMTP_SECURE=false \
  SMTP_USER=verify SMTP_PASSWORD=verify SMTP_FROM=agent@example.test \
  IMAP_HOST=127.0.0.1 IMAP_PORT="$IMAP_PORT" IMAP_SECURE=false \
  IMAP_USER=verify IMAP_PASSWORD=verify IMAP_BATCH_SIZE=5 \
  REVIEW_TEAM_EMAIL=review-team@example.test \
  npm start >/tmp/verify-app.log 2>&1 &
APP_PID=$!

# Wait for the app to answer, rather than guessing at a sleep duration.
for _ in $(seq 1 40); do
  if curl -fsS "${BASE}/api/health" >/dev/null 2>&1; then break; fi
  sleep 0.5
done

if ! curl -fsS "${BASE}/api/health" >/dev/null 2>&1; then
  record 1 "app started"
  tail -30 /tmp/verify-app.log
  exit 1
fi
record 0 "app started and answering"
curl -fsS "${BASE}/api/health" | sed 's/^/    /'

# ---------------------------------------------------------------- e2e suites
step "7/7  End-to-end suites"

BASE_URL="$BASE" node scripts/test-flow.mjs >/tmp/verify-flow.log 2>&1
FLOW_STATUS=$?
record $FLOW_STATUS "main flow ($(grep -oE 'All [0-9]+ checks passed|[0-9]+ of [0-9]+ checks failed' /tmp/verify-flow.log | tail -1))"
[ $FLOW_STATUS -ne 0 ] && grep -E "✗" /tmp/verify-flow.log | head -20

rm -f "${SMTP_DIR}/index.json"
BASE_URL="$BASE" MOCK_SMTP_DIR="$SMTP_DIR" node scripts/test-mail.mjs >/tmp/verify-mail.log 2>&1
MAIL_STATUS=$?
record $MAIL_STATUS "sending mail ($(grep -oE 'All [0-9]+ mail checks passed|[0-9]+ of [0-9]+ mail checks failed' /tmp/verify-mail.log | tail -1))"
[ $MAIL_STATUS -ne 0 ] && grep -E "✗" /tmp/verify-mail.log | head -20

BASE_URL="$BASE" MOCK_IMAP_PID="$IMAP_PID" node scripts/test-imap.mjs >/tmp/verify-imapflow.log 2>&1
IMAP_STATUS=$?
record $IMAP_STATUS "reading a mailbox ($(grep -oE 'All [0-9]+ mailbox checks passed|[0-9]+ of [0-9]+ mailbox checks failed' /tmp/verify-imapflow.log | tail -1))"
[ $IMAP_STATUS -ne 0 ] && grep -E "✗" /tmp/verify-imapflow.log | head -20

# ---------------------------------------------------------------- summary
printf "\n${BOLD}%s${NC}\n" "────────────────────────────────────────────────────────────"
if [ ${#FAILURES[@]} -eq 0 ]; then
  printf "${GREEN}${BOLD}Everything passed.${NC}\n\n"
  note "full logs are in /tmp/verify-*.log"
  exit 0
fi

printf "${RED}${BOLD}%d stage(s) failed:${NC}\n" "${#FAILURES[@]}"
for failure in "${FAILURES[@]}"; do printf "${RED}  • %s${NC}\n" "$failure"; done
printf "\n"
note "full logs are in /tmp/verify-*.log"
exit 1
