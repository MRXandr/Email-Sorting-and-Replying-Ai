/**
 * Calibration harness for the offline matcher.
 *
 * Run:  npm run build:test && node scripts/calibrate.mjs
 *
 * It scores every seeded input draft and every demo inbox email against all five
 * seeded types and prints the ranking, so you can see whether:
 *   - each known email lands on its own type with a clear margin, and
 *   - the two deliberately-unknown emails score low enough to be flagged.
 *
 * Use it after editing keywords or weights to check nothing regressed.
 */
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const { scoreHeuristic, scoreMargin } = require('../.testbuild/lib/classify/heuristic.js');
const { SEED_TYPES, SEED_INBOX } = require('../.testbuild/lib/seed.js');

const profiles = SEED_TYPES.map((t, i) => ({
  typeId: `type-${i}`,
  typeName: t.name,
  slug: t.slug,
  description: t.description ?? '',
  keywords: t.keywords ?? [],
  samples: t.samples,
}));

const slugToId = new Map(profiles.map((p) => [p.slug, p.typeId]));

function bar(score) {
  const n = Math.round(score * 30);
  return '█'.repeat(n) + '·'.repeat(30 - n);
}

let failures = 0;

console.log('\n══ HELD-OUT TEST: each input draft scored with that draft removed ══\n');

// Leave-one-out: a draft must still land on its own type when it is not in the
// training data. This is the honest test — scoring a draft against itself is free.
for (const [ti, seedType] of SEED_TYPES.entries()) {
  for (const [si, sample] of seedType.samples.entries()) {
    const heldOut = profiles.map((p, i) =>
      i === ti ? { ...p, samples: p.samples.filter((_, k) => k !== si) } : p,
    );
    const scores = scoreHeuristic(sample, heldOut);
    const top = scores[0];
    const ok = top.slug === seedType.slug;
    if (!ok) failures++;
    console.log(
      `${ok ? 'PASS' : 'FAIL'}  ${seedType.slug.padEnd(22)} ` +
        `→ ${top.slug.padEnd(22)} ${top.score.toFixed(3)}  margin ${scoreMargin(scores).toFixed(3)}` +
        `   "${sample.subject.slice(0, 44)}"`,
    );
  }
}

console.log('\n══ DEMO INBOX ══\n');

for (const email of SEED_INBOX) {
  const scores = scoreHeuristic(email, profiles);
  const top = scores[0];
  const margin = scoreMargin(scores);

  console.log(`"${email.subject}"`);
  console.log(`   ${email.note}`);
  for (const s of scores.slice(0, 3)) {
    console.log(
      `   ${bar(s.score)} ${s.score.toFixed(3)}  ${s.slug.padEnd(22)}` +
        ` [nn ${s.bestSample.toFixed(2)} cen ${s.centroid.toFixed(2)} kw ${s.keyword.toFixed(2)}]` +
        (s.matchedKeywords?.length ? ` ← ${s.matchedKeywords.slice(0, 4).join(', ')}` : ''),
    );
  }
  console.log(`   top=${top.score.toFixed(3)} margin=${margin.toFixed(3)}\n`);
}

// Hand-written probes that are NOT in the training data. Terse one-liners, odd
// phrasing, and emails that straddle two categories — the cases most likely to
// break a matcher tuned only against its own examples.
const PROBES = [
  { subject: 'where is it', body: 'ordered 5 days ago nothing has come. order 4471.', want: 'order-status' },
  { subject: 'wrong colour sent', body: 'I got black, I paid for green. want to swap it.', want: 'returns-refunds' },
  { subject: 'stock question', body: 'is the 65 inch model available? not bought yet, just asking.', want: 'product-info' },
  { subject: 'billed 3 times', body: 'three identical amounts on my statement today. only one order placed.', want: 'billing-payment' },
  { subject: 'no reply in 2 weeks', body: 'I have written twice and heard nothing. put me through to a supervisor.', want: 'complaint-escalation' },
  {
    subject: 'refund for late parcel',
    body: 'order 8812 is 3 weeks late so I no longer want it. cancel and refund me please.',
    want: null,
    note: 'straddles order-status and returns — either is defensible',
  },
  { subject: 'invoice for my return', body: 'need a GST invoice for the credit note on my returned item, order 9912.', want: null, note: 'straddles billing and returns' },
  { subject: 'Invitation to speak at RetailTech 2027', body: 'We would be delighted to have your Head of Supply Chain deliver a keynote at our annual conference in Berlin. Sponsorship tiers attached.', want: 'FLAG' },
  { subject: 'Press enquiry — deadline 5pm', body: 'I am a journalist at a trade publication writing about warehouse automation and would like a comment from your operations director.', want: 'FLAG' },
  { subject: 'Data deletion request under GDPR', body: 'I am exercising my right to erasure and require confirmation that all personal data held about me has been deleted within 30 days.', want: 'FLAG' },
];

console.log('══ UNSEEN PROBES (not in training data) ══\n');

let probeFailures = 0;
for (const probe of PROBES) {
  const scores = scoreHeuristic(probe, profiles);
  const top = scores[0];
  const margin = scoreMargin(scores);

  let verdict;
  if (probe.want === 'FLAG') {
    // Should score below where a threshold would plausibly sit.
    const ok = top.score < 0.3;
    verdict = ok ? 'PASS' : 'FAIL';
    if (!ok) probeFailures++;
  } else if (probe.want === null) {
    verdict = 'INFO'; // ambiguous by design
  } else {
    const ok = top.slug === probe.want;
    verdict = ok ? 'PASS' : 'FAIL';
    if (!ok) probeFailures++;
  }

  console.log(
    `${verdict}  ${top.score.toFixed(3)} ${top.slug.padEnd(22)} m=${margin.toFixed(3)}` +
      `  want=${String(probe.want).padEnd(22)} "${probe.subject.slice(0, 40)}"` +
      (probe.note ? `  (${probe.note})` : ''),
  );
}
console.log(`\nprobe failures: ${probeFailures}\n`);

console.log('══ SEPARATION SUMMARY ══\n');

const known = SEED_INBOX.filter((e) => !e.expectFlag).map((e) => scoreHeuristic(e, profiles)[0].score);
const unknown = SEED_INBOX.filter((e) => e.expectFlag).map((e) => scoreHeuristic(e, profiles)[0].score);

const min = (a) => Math.min(...a);
const max = (a) => Math.max(...a);

console.log(`known emails   top score range: ${min(known).toFixed(3)} … ${max(known).toFixed(3)}`);
console.log(`unknown emails top score range: ${min(unknown).toFixed(3)} … ${max(unknown).toFixed(3)}`);
const gap = min(known) - max(unknown);
console.log(`gap between them: ${gap.toFixed(3)}  ${gap > 0.1 ? '(good — a threshold sits cleanly between)' : '(TOO NARROW — retune)'}`);
console.log(`suggested confidenceThreshold: ${(max(unknown) + gap / 2).toFixed(2)}`);
console.log(`\nheld-out failures: ${failures}   probe failures: ${probeFailures}`);

process.exit(failures > 0 || probeFailures > 0 || gap <= 0.1 ? 1 : 0);
