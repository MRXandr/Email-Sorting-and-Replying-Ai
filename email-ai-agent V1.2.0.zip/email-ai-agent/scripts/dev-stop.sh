#!/usr/bin/env bash
# Stop any Next.js server started for local testing.
#
# `lsof -ti:PORT` does not report listening sockets in every container, so this
# matches on the process command line instead, which is reliable.
set -u

find_pids() {
  ps -eo pid,args | awk '/next-server|next start/ && !/awk/ {print $1}'
}

if [ -z "$(find_pids)" ]; then
  echo "no Next.js server running"
  exit 0
fi

# A parent `sh -c next start` respawns briefly, so retry a few times rather than
# reporting failure on the first pass.
for _ in 1 2 3 4 5; do
  pids=$(find_pids)
  [ -z "$pids" ] && break
  echo "stopping: $(echo "$pids" | tr '\n' ' ')"
  # shellcheck disable=SC2086
  kill -9 $pids 2>/dev/null
  sleep 1
done

if [ -n "$(find_pids)" ]; then
  echo "still running: $(find_pids | tr '\n' ' ')" >&2
  exit 1
fi

echo "stopped"
