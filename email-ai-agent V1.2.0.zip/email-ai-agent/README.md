# Email Triage Agent

An AI system that reads incoming email, works out which kind of email it is, and
drafts a reply using the approved template for that kind. Anything it does not
recognise is flagged, written to a file, and emailed to a human team — and when
that human says what it was, the system remembers, so the next email like it is
handled on its own.

**You have never built anything like this before, so start here:**
[docs/01-run-it-locally.md](docs/01-run-it-locally.md). It takes about five
minutes and needs nothing but Node.js.

**Want to see it first?** [Screenshots of every screen](docs/screenshots/), taken
from the running app.

![Dashboard](docs/screenshots/1-dashboard.png)

---

## What it actually does

```
  An email arrives
  (pasted, uploaded, or pulled from a real mailbox)
        │
        ▼
  ┌─────────────────────────────────────────────────┐
  │  Which kind of email is this?                   │
  │                                                 │
  │  Compared against the example emails you have   │
  │  stored for each type, by two independent means: │
  │    • an AI model, which reads intent            │
  │    • an offline matcher, which reads vocabulary  │
  └─────────────────────────────────────────────────┘
        │                                  │
   confident                          not confident
        │                                  │
        ▼                                  ▼
  ┌──────────────────┐         ┌──────────────────────────────┐
  │ Draft a reply    │         │ Flag it                      │
  │ from that type's │         │  • write a file describing it │
  │ approved         │         │  • email it to your team      │
  │ template         │         │  • put it in the review queue │
  └──────────────────┘         └──────────────────────────────┘
        │                                  │
        ▼                                  ▼
  A person checks             A person says what it is:
  and sends it                  ┌─────────────────────────────┐
                                │ "It's an existing type"      │
                                │   → stored as a new example  │
                                │     for that type            │
                                │                              │
                                │ "It's a new type"            │
                                │   → you give it a name and   │
                                │     a reply template         │
                                └─────────────────────────────┘
                                             │
                                             ▼
                                   Next email like it is
                                   handled automatically
```

The example emails you store for each type are what the brief calls the **input
drafts**. The reply template for each type is the **output draft**. Both live on
the Types page and you can edit them at any time.

---

## Everything it can do

| | |
|---|---|
| **Sort email into your own categories** | Define as many types as you like. Five realistic ones are included as a demo. |
| **Draft replies from your approved wording** | Each type has a reply template. The AI adapts it to the specific customer; without an AI key the template is filled in directly. |
| **Refuse to invent facts** | If a template asks for something the system cannot work out — a delivery date, say — it leaves the gap visible and blocks sending until a person fills it in. |
| **Flag what it does not recognise** | Rather than forcing a bad match. The unmatched email is written to a readable file and emailed to your team. |
| **Learn from your team's decisions** | Resolving a flagged email stores it as a training example, so the same kind of email is recognised next time. Proven by an automated test. |
| **Add new types on the fly** | Including from the review screen, where a brand-new category can be created with its own input and output drafts. |
| **Read a real mailbox** | Pulls unread mail over IMAP. Only marks a message read once it has actually been handled, so nothing is lost if something fails. |
| **Send replies** | Over SMTP, with the original email threaded. Off by default — a person approves each one. |
| **Work with no AI key at all** | A built-in offline matcher handles classification and templates are filled directly. Less clever, but free and always available. |
| **Explain every decision** | Every email shows the score each type received, which phrases matched, and why the winner won. |
| **Survive things going wrong** | If the AI is unreachable, the offline matcher takes over and says so. If the database loses its tables, they are recreated. Failures are reported, never hidden. |

---

## The guides

Read them in order. Each one is self-contained and assumes no prior knowledge.

| | Guide | What you get |
|---|---|---|
| 1 | [Run it on your computer](docs/01-run-it-locally.md) | The app working in your browser, in about five minutes. |
| 2 | [Add the AI (free)](docs/02-add-the-ai.md) | A free Gemini key, so replies are properly tailored. |
| 3 | [Add a database](docs/03-database.md) | Free Postgres on Neon, which you need before hosting. |
| 4 | [Connect a real mailbox](docs/04-connect-email.md) | Reading real email and sending real replies. |
| 5 | [Put it on the internet](docs/05-deploy-to-vercel.md) | A public URL you can send to your professor. |
| 6 | [Make it your own](docs/06-make-it-yours.md) | Replacing the demo company with your own types and drafts. |
| 7 | [How it works inside](docs/07-how-it-works.md) | The design, the classifier, and why it is built this way. |
| 8 | [When something breaks](docs/08-troubleshooting.md) | Every error message, and what to do about it. |

---

## The fastest possible start

You need [Node.js 20 or newer](https://nodejs.org). Check with `node --version`.

```bash
npm install
npm run dev
```

Open <http://localhost:3000>, click **Load the demo company**, then **Run the
seven demo emails**. Five will be sorted with replies drafted; two will be
flagged for a human. Open the **Review** page and teach it what one of them is.

That is the whole system, working, with no keys and no database.

---

## Testing it yourself

Everything in this project is covered by tests you can run. There is no "trust
me" here — one command checks the lot, using local stand-ins for the AI provider,
the mail server and the mailbox, so it costs nothing and needs no accounts:

```bash
npm run verify
```

```
==> 1/7  Typechecking                ✓
==> 2/7  Unit tests                  ✓ 172 passed
==> 3/7  Classifier calibration      ✓ gap between known and unknown mail: 0.376
==> 4/7  Building                    ✓
==> 5/7  Starting the stand-in servers  ✓
==> 6/7  Starting the app against them  ✓
==> 7/7  End-to-end suites
         ✓ main flow            (129 checks)
         ✓ sending mail         (55 checks)
         ✓ reading a mailbox    (50 checks)
```

Individual pieces, if you want them:

| Command | What it checks |
|---|---|
| `npm test` | Unit tests: the classifier, templates, and both storage backends. |
| `npm run calibrate` | Whether your email types are still cleanly distinguishable. Run this after editing types. |
| `npm run test:flow` | The whole journey over HTTP against a running app. |
| `npm run test:mail` | That alert emails and replies really get sent. |
| `npm run test:imap` | That a real mailbox is read correctly, in batches, without duplicates. |
| `npm run typecheck` | That the TypeScript is sound. |

`npm run test:flow`, `test:mail` and `test:imap` need the app running, and the
last two need the stand-in servers — `npm run verify` sets all that up for you.

**These tests reset the database they point at.** Never run them against
anything you care about.

---

## Project layout

```
email-ai-agent/
├── src/
│   ├── app/                   Pages and the API
│   │   ├── page.tsx           Dashboard
│   │   ├── inbox/             Feed emails in, see what happened
│   │   ├── review/            The human-in-the-loop screen
│   │   ├── types/             Manage categories and their drafts
│   │   ├── mailbox/           Fetch from a real inbox
│   │   ├── settings/          Company details and thresholds
│   │   └── api/               Every endpoint
│   ├── components/            Shared UI pieces
│   ├── middleware.ts          The optional password gate
│   └── lib/
│       ├── classify/          Deciding which type an email is
│       │   ├── text.ts        Tokenising, similarity, keyword matching
│       │   ├── heuristic.ts   The offline matcher
│       │   └── classifier.ts  Combining AI + matcher into a decision
│       ├── draft/             Writing the reply
│       │   ├── templates.ts   Placeholder filling, entity extraction
│       │   └── drafter.ts     AI drafting with a template fallback
│       ├── ai/                Gemini, OpenAI, Anthropic — swappable
│       ├── db/                Storage: Postgres and a local file store
│       ├── mail/              IMAP reading, SMTP sending, parsing
│       ├── pipeline.ts        The whole flow, including the learning step
│       ├── flagfile.ts        The file written for an unmatched email
│       └── seed.ts            The demo company and its five types
├── tests/                     Unit tests
├── scripts/                   Test suites and local stand-in servers
└── docs/                      The guides listed above
```

---

## Built with

Next.js 15 (React 19, TypeScript, Tailwind CSS) for both the site and its API,
`pg` for Postgres, `imapflow` and `nodemailer` for email, and `mailparser` for
reading messages. The AI providers are called over plain HTTPS with no SDK, which
is why swapping between Gemini, OpenAI and Anthropic is a one-line change.

No paid service is required to run or host this.
