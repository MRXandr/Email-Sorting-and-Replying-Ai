import assert from 'node:assert/strict';
import { mkdtemp, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { afterEach, describe, it } from 'node:test';
import { lib } from './helpers.mjs';

const { getStore, resetStoreCache, StorageNotConfiguredError } = lib('db/index.js');
const { isServerless, STORAGE_NOT_CONFIGURED_MESSAGE } = lib('config.js');
const { FileStore, isUnwritableDirError, UNWRITABLE_DIR_CODES } = lib('db/filestore.js');

/**
 * Regression tests for a real deployment failure.
 *
 * Deploying to Vercel without a DATABASE_URL produced a bare
 * `ENOENT: no such file or directory, mkdir '/var/task/.data'` in the UI. Two
 * things were wrong: the read-only fallback did not recognise ENOENT, and there
 * was no check that catches this situation before it becomes a filesystem error
 * at all. Both are pinned down here.
 */

const SERVERLESS_VARS = [
  'VERCEL',
  'VERCEL_ENV',
  'AWS_LAMBDA_FUNCTION_NAME',
  'LAMBDA_TASK_ROOT',
  'NETLIFY',
  'FUNCTIONS_WORKER_RUNTIME',
];

/** Restore the environment after each case, so tests cannot leak into each other. */
function withEnv(changes) {
  const saved = {};
  for (const [key, value] of Object.entries(changes)) {
    saved[key] = process.env[key];
    if (value === undefined) delete process.env[key];
    else process.env[key] = value;
  }
  return () => {
    for (const [key, value] of Object.entries(saved)) {
      if (value === undefined) delete process.env[key];
      else process.env[key] = value;
    }
  };
}

let restore = () => {};
afterEach(async () => {
  restore();
  restore = () => {};
  await resetStoreCache();
});

describe('unwritable-directory detection', () => {
  it('recognises ENOENT, which is how read-only container filesystems refuse mkdir', () => {
    // The exact shape Node produced on the failing deployment.
    const err = Object.assign(new Error("ENOENT: no such file or directory, mkdir '/var/task/.data'"), {
      code: 'ENOENT',
    });
    assert.equal(isUnwritableDirError(err), true);
  });

  it('recognises the other read-only codes', () => {
    for (const code of ['EROFS', 'EACCES', 'EPERM']) {
      assert.equal(isUnwritableDirError(Object.assign(new Error(code), { code })), true, code);
    }
  });

  it('does not treat unrelated errors as unwritable', () => {
    for (const code of ['ENOTDIR', 'ENAMETOOLONG', 'EMFILE', undefined]) {
      assert.equal(isUnwritableDirError(Object.assign(new Error('x'), { code })), false, String(code));
    }
    assert.equal(isUnwritableDirError(new Error('plain error')), false);
    assert.equal(isUnwritableDirError(null), false);
  });

  it('keeps ENOENT in the list', () => {
    // Named explicitly: dropping it is what caused the deployment failure.
    assert.ok(UNWRITABLE_DIR_CODES.includes('ENOENT'));
  });
});

describe('serverless detection', () => {
  it('is false with none of the platform variables set', () => {
    restore = withEnv(Object.fromEntries(SERVERLESS_VARS.map((v) => [v, undefined])));
    assert.equal(isServerless(), false);
  });

  it('is true on each supported platform', () => {
    for (const variable of SERVERLESS_VARS) {
      const undo = withEnv({
        ...Object.fromEntries(SERVERLESS_VARS.map((v) => [v, undefined])),
        [variable]: '1',
      });
      assert.equal(isServerless(), true, `${variable} should mark the host as serverless`);
      undo();
    }
  });
});

describe('getStore on a serverless host', () => {
  it('refuses with an explanation when no database is configured', async () => {
    restore = withEnv({
      VERCEL: '1',
      DATABASE_URL: undefined,
      POSTGRES_URL: undefined,
      POSTGRES_PRISMA_URL: undefined,
      NEON_DATABASE_URL: undefined,
    });
    await resetStoreCache();

    await assert.rejects(
      () => getStore(),
      (err) => {
        assert.ok(err instanceof StorageNotConfiguredError, 'should be a StorageNotConfiguredError');
        assert.equal(err.status, 503, 'should be reported as a configuration problem, not a crash');
        // The message has to name the variable and the fact a redeploy is needed,
        // because that is the whole point of failing here rather than later.
        assert.match(err.message, /DATABASE_URL/);
        assert.match(err.message, /redeploy/i);
        assert.match(err.message, /NEW deployment/i);
        return true;
      },
    );
  });

  it('works normally once a database is configured', async () => {
    restore = withEnv({ VERCEL: '1', DATABASE_URL: 'postgresql://user:pass@example.invalid:5432/db' });
    await resetStoreCache();

    // Constructing the store must not throw; only connecting would, and that is
    // reported separately with its own message.
    const store = await getStore().catch((err) => err);
    assert.ok(!(store instanceof StorageNotConfiguredError), 'should not refuse when a URL is set');
  });

  it('still uses the file store when not on a serverless host', async () => {
    const dir = await mkdtemp(path.join(tmpdir(), 'mailagent-cfg-'));
    restore = withEnv({
      ...Object.fromEntries(SERVERLESS_VARS.map((v) => [v, undefined])),
      DATABASE_URL: undefined,
      POSTGRES_URL: undefined,
      POSTGRES_PRISMA_URL: undefined,
      NEON_DATABASE_URL: undefined,
      DATA_DIR: dir,
    });
    await resetStoreCache();

    const store = await getStore();
    assert.equal(store.kind, 'file', 'local development must keep working with no setup');
    await resetStoreCache();
    await rm(dir, { recursive: true, force: true });
  });
});

describe('the message shown to the user', () => {
  it('says what to add, where, and that a redeploy is required', () => {
    assert.match(STORAGE_NOT_CONFIGURED_MESSAGE, /DATABASE_URL/);
    assert.match(STORAGE_NOT_CONFIGURED_MESSAGE, /Postgres/i);
    assert.match(STORAGE_NOT_CONFIGURED_MESSAGE, /redeploy/i);
    assert.match(STORAGE_NOT_CONFIGURED_MESSAGE, /docs\/03-database\.md/);
  });
});

describe('FileStore falls back rather than failing', () => {
  it('writes somewhere usable when the chosen directory cannot be created', async () => {
    // A path whose parent is a regular file: mkdir cannot create it.
    const base = await mkdtemp(path.join(tmpdir(), 'mailagent-ro-'));
    const blocker = path.join(base, 'blocker');
    await writeFile(blocker, 'not a directory');

    const store = new FileStore(path.join(blocker, 'data'));

    try {
      await store.init();
      const type = await store.createType({ name: 'Fallback check' });
      assert.equal(type.name, 'Fallback check');
      assert.equal((await store.listTypes()).length, 1);
    } catch (err) {
      // ENOTDIR is deliberately NOT treated as unwritable, since it means a bad
      // path rather than a refusing filesystem — so a clear failure is correct.
      assert.equal((err).code, 'ENOTDIR', `unexpected error: ${err.message}`);
    } finally {
      await store.close();
      await rm(base, { recursive: true, force: true });
    }
  });
});
