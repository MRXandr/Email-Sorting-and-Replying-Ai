import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);

/** Import the compiled library. Run `npm run build:test` first. */
export function lib(modulePath) {
  try {
    return require(`../.testbuild/lib/${modulePath}`);
  } catch (err) {
    if (err.code === 'MODULE_NOT_FOUND' && String(err.message).includes('.testbuild')) {
      throw new Error(
        'The compiled test build is missing. Run `npm run build:test` (or `npm test`, which does it for you).',
      );
    }
    throw err;
  }
}

export const { FileStore } = lib('db/filestore.js');
export const { PostgresStore } = lib('db/postgres.js');

/**
 * The Postgres connection used for tests, if one is available.
 * Set TEST_DATABASE_URL to run the storage suite against real Postgres too.
 */
export const TEST_DATABASE_URL = process.env.TEST_DATABASE_URL || '';

/**
 * Build the list of storage adapters to test.
 * The file store always runs; Postgres runs only when TEST_DATABASE_URL is set,
 * so `npm test` works on a machine with no database installed.
 */
export function storeFactories() {
  const factories = [
    {
      name: 'FileStore',
      async create() {
        const dir = await mkdtemp(path.join(tmpdir(), 'mailagent-test-'));
        const store = new FileStore(dir);
        await store.init();
        return {
          store,
          async cleanup() {
            await store.close();
            await rm(dir, { recursive: true, force: true });
          },
        };
      },
    },
  ];

  if (TEST_DATABASE_URL) {
    factories.push({
      name: 'PostgresStore',
      async create() {
        const store = new PostgresStore(TEST_DATABASE_URL);
        await store.init();
        await store.reset();
        return {
          store,
          async cleanup() {
            await store.reset();
            // The pool is shared on globalThis; leave it open for the next test.
          },
        };
      },
    });
  }

  return factories;
}

/**
 * A controllable stand-in for an AI provider.
 *
 * `handler` receives the request and decides what to return, so a test can make
 * the "model" pick a type, refuse to pick one, report low confidence, return
 * malformed JSON, or throw — covering every branch of the decision logic without
 * a network call or an API key.
 */
export function fakeAi(handler, { name = 'fake', model = 'test-1' } = {}) {
  const calls = [];
  return {
    name,
    model,
    calls,
    async complete(req) {
      calls.push(req);
      return handler(req, calls.length);
    },
  };
}

/** True when this request is the classification call rather than the drafting call. */
export function isClassifyRequest(req) {
  return (req.system ?? '').includes('email triage classifier');
}

export function classifyJson({ slug, confidence = 0.95, reasoning = 'test reasoning' }) {
  return JSON.stringify({ slug, confidence, reasoning, runners_up: [] });
}

export function draftJson({ subject = 'Re: test', body }) {
  return JSON.stringify({ subject, body });
}

/** Minimal settings object for calling the library directly. */
export function testSettings(overrides = {}) {
  const { DEFAULT_SETTINGS } = lib('db/store.js');
  return { ...DEFAULT_SETTINGS, updatedAt: new Date().toISOString(), ...overrides };
}
