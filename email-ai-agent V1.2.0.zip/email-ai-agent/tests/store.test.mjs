import assert from 'node:assert/strict';
import { after, before, describe, it } from 'node:test';
import { storeFactories, TEST_DATABASE_URL } from './helpers.mjs';

/**
 * The same suite runs against every storage adapter, so the JSON file store and
 * the Postgres store cannot quietly drift apart in behaviour. Postgres is included
 * only when TEST_DATABASE_URL is set.
 */
for (const factory of storeFactories()) {
  describe(`Store contract — ${factory.name}`, () => {
    let store;
    let cleanup;

    before(async () => {
      const created = await factory.create();
      store = created.store;
      cleanup = created.cleanup;
    });

    after(async () => {
      await cleanup();
    });

    it('starts empty', async () => {
      await store.reset();
      assert.deepEqual(await store.listTypes(), []);
      assert.deepEqual(await store.listEmails(), []);
      assert.equal(await store.countEmails(), 0);
    });

    it('creates and reads a type', async () => {
      const type = await store.createType({
        name: 'Order Status',
        description: 'Where is my order',
        keywords: ['tracking', 'delivery date'],
        replySubject: 'Re: {{subject}}',
        replyBody: 'Hi {{customer_first_name}}',
        replyGuidance: 'Be concrete',
      });

      assert.ok(type.id);
      assert.equal(type.slug, 'order-status');
      assert.deepEqual(type.keywords, ['tracking', 'delivery date']);
      assert.equal(type.active, true);

      const fetched = await store.getType(type.id);
      assert.deepEqual(fetched, type);
      assert.deepEqual(await store.getTypeBySlug('order-status'), type);
      assert.equal(await store.getType('nope'), null);
      assert.equal(await store.getTypeBySlug('nope'), null);
    });

    it('makes slugs unique when names collide', async () => {
      const a = await store.createType({ name: 'Billing Issue' });
      const b = await store.createType({ name: 'Billing Issue' });
      const c = await store.createType({ name: 'Billing Issue' });
      assert.equal(a.slug, 'billing-issue');
      assert.equal(b.slug, 'billing-issue-2');
      assert.equal(c.slug, 'billing-issue-3');
      await store.deleteType(a.id);
      await store.deleteType(b.id);
      await store.deleteType(c.id);
    });

    it('updates only the fields given', async () => {
      const type = await store.createType({ name: 'Temp', description: 'first', keywords: ['a'] });
      const updated = await store.updateType(type.id, { description: 'second' });
      assert.equal(updated.description, 'second');
      assert.equal(updated.name, 'Temp', 'untouched fields must be preserved');
      assert.deepEqual(updated.keywords, ['a']);

      const cleared = await store.updateType(type.id, { keywords: [] });
      assert.deepEqual(cleared.keywords, []);

      // An empty patch is a no-op, not an error.
      const same = await store.updateType(type.id, {});
      assert.equal(same.id, type.id);

      await store.deleteType(type.id);
    });

    it('hides inactive types unless asked', async () => {
      const type = await store.createType({ name: 'Retired', active: false });
      const visible = await store.listTypes();
      const all = await store.listTypes({ includeInactive: true });
      assert.ok(!visible.some((t) => t.id === type.id));
      assert.ok(all.some((t) => t.id === type.id));
      await store.deleteType(type.id);
    });

    it('stores input drafts and reply examples per type', async () => {
      const type = await store.getTypeBySlug('order-status');

      const sample = await store.addSample({
        typeId: type.id,
        subject: 'Where is it',
        body: 'Order 1234 never arrived',
        source: 'seed',
      });
      await store.addSample({
        typeId: type.id,
        subject: 'Late parcel',
        body: 'Still waiting',
        source: 'human_review',
      });
      const example = await store.addReplyExample({
        typeId: type.id,
        subject: 'Re: Where is it',
        body: 'We are checking',
      });

      const samples = await store.listSamples(type.id);
      assert.equal(samples.length, 2);
      assert.equal(samples[0].id, sample.id, 'samples come back oldest first');
      assert.equal(samples[1].source, 'human_review');

      assert.equal((await store.listReplyExamples(type.id)).length, 1);
      assert.equal((await store.listSamples()).length, 2, 'listing without a type returns all');

      await store.deleteReplyExample(example.id);
      assert.equal((await store.listReplyExamples(type.id)).length, 0);
    });

    it('creates an email and finds it by external id', async () => {
      const email = await store.createEmail({
        externalId: '<abc@mail.example>',
        fromName: 'Kavya',
        fromEmail: 'kavya@example.com',
        toEmail: 'support@example.com',
        subject: 'Where is order 92771',
        body: 'Not arrived',
        source: 'imap',
        status: 'classified',
      });

      assert.ok(email.id);
      assert.equal(email.fromEmail, 'kavya@example.com');
      assert.deepEqual(await store.getEmail(email.id), email);
      assert.equal((await store.findEmailByExternalId('<abc@mail.example>')).id, email.id);
      assert.equal(await store.findEmailByExternalId('<nope@x>'), null);
      assert.equal(await store.findEmailByExternalId(''), null);
    });

    it('rejects a duplicate external id', async () => {
      await assert.rejects(
        () =>
          store.createEmail({
            externalId: '<abc@mail.example>',
            fromEmail: 'other@example.com',
            subject: 'dupe',
            body: 'dupe',
          }),
        'the same message must never be stored twice',
      );
    });

    it('allows many emails with no external id', async () => {
      const a = await store.createEmail({ fromEmail: 'a@x.com', subject: 's1', body: 'b1' });
      const b = await store.createEmail({ fromEmail: 'b@x.com', subject: 's2', body: 'b2' });
      assert.notEqual(a.id, b.id);
      await store.deleteEmail(a.id);
      await store.deleteEmail(b.id);
    });

    it('filters and paginates emails', async () => {
      const made = [];
      for (let i = 0; i < 5; i++) {
        made.push(
          await store.createEmail({
            fromEmail: `p${i}@example.com`,
            subject: `Paged subject ${i}`,
            body: `needle-${i} body text`,
            status: i % 2 === 0 ? 'classified' : 'flagged',
          }),
        );
      }

      const flagged = await store.listEmails({ status: 'flagged' });
      assert.ok(flagged.length >= 2);
      assert.ok(flagged.every((e) => e.status === 'flagged'));

      const searched = await store.listEmails({ search: 'needle-3' });
      assert.equal(searched.length, 1);
      assert.equal(searched[0].subject, 'Paged subject 3');

      // Search covers subject, body and sender.
      assert.equal((await store.listEmails({ search: 'p4@example.com' })).length, 1);
      assert.ok((await store.listEmails({ search: 'Paged subject' })).length >= 5);

      const firstPage = await store.listEmails({ limit: 2, offset: 0 });
      const secondPage = await store.listEmails({ limit: 2, offset: 2 });
      assert.equal(firstPage.length, 2);
      assert.equal(secondPage.length, 2);
      assert.ok(
        !firstPage.some((e) => secondPage.some((s) => s.id === e.id)),
        'pages must not overlap',
      );

      // count must agree with the same filter used by list
      assert.equal(
        await store.countEmails({ status: 'flagged' }),
        (await store.listEmails({ status: 'flagged', limit: 500 })).length,
      );

      for (const e of made) await store.deleteEmail(e.id);
    });

    it('records classifications and returns the newest', async () => {
      const type = await store.getTypeBySlug('order-status');
      const email = await store.createEmail({ fromEmail: 'c@x.com', subject: 's', body: 'b' });

      await store.addClassification({
        emailId: email.id,
        typeId: null,
        confidence: 0.1,
        method: 'heuristic',
        reasoning: 'first attempt, no match',
        scores: [],
      });
      // Distinct timestamps so "newest" is unambiguous.
      await new Promise((r) => setTimeout(r, 15));
      const second = await store.addClassification({
        emailId: email.id,
        typeId: type.id,
        confidence: 0.91,
        method: 'ai',
        reasoning: 'second attempt matched',
        scores: [{ typeId: type.id, typeName: type.name, slug: type.slug, score: 0.8 }],
        aiRaw: '{"slug":"order-status"}',
      });

      const latest = await store.getClassificationForEmail(email.id);
      assert.equal(latest.id, second.id);
      assert.equal(latest.typeId, type.id);
      assert.equal(latest.confidence, 0.91);
      assert.equal(latest.scores[0].score, 0.8);
      assert.equal(latest.aiRaw, '{"slug":"order-status"}');
      assert.equal(await store.getClassificationForEmail('missing'), null);

      await store.deleteEmail(email.id);
    });

    it('stores and updates drafts', async () => {
      const type = await store.getTypeBySlug('order-status');
      const email = await store.createEmail({ fromEmail: 'd@x.com', subject: 's', body: 'b' });

      const draft = await store.addDraft({
        emailId: email.id,
        typeId: type.id,
        subject: 'Re: s',
        body: 'Hello there',
        generatedBy: 'template',
        unresolvedPlaceholders: ['order_id'],
      });

      assert.equal(draft.status, 'draft');
      assert.equal(draft.sentAt, null);
      assert.deepEqual(draft.unresolvedPlaceholders, ['order_id']);

      const edited = await store.updateDraft(draft.id, { body: 'Edited body', status: 'edited' });
      assert.equal(edited.body, 'Edited body');
      assert.equal(edited.status, 'edited');
      assert.equal(edited.subject, 'Re: s', 'untouched fields preserved');

      const sentAt = new Date().toISOString();
      const sent = await store.updateDraft(draft.id, { status: 'sent', sentAt });
      assert.equal(sent.status, 'sent');
      assert.equal(new Date(sent.sentAt).toISOString(), sentAt);

      const failed = await store.updateDraft(draft.id, { sendError: 'smtp refused' });
      assert.equal(failed.sendError, 'smtp refused');

      assert.equal((await store.getDraftForEmail(email.id)).id, draft.id);
      assert.equal(await store.getDraft('missing'), null);
      await assert.rejects(() => store.updateDraft('missing', { body: 'x' }));

      await store.deleteEmail(email.id);
    });

    it('manages the review queue', async () => {
      const email = await store.createEmail({
        fromEmail: 'r@x.com',
        subject: 'partnership',
        body: 'wholesale proposal',
        status: 'flagged',
      });

      const review = await store.addReview({
        emailId: email.id,
        reason: 'no type matched',
        topScores: [{ typeId: 't', typeName: 'Order Status', slug: 'order-status', score: 0.11 }],
      });

      assert.equal(review.status, 'open');
      assert.equal(review.resolution, null);
      assert.equal(review.topScores[0].score, 0.11);

      assert.ok((await store.listReviews('open')).some((r) => r.id === review.id));
      assert.ok(!(await store.listReviews('resolved')).some((r) => r.id === review.id));
      assert.equal((await store.getReviewForEmail(email.id)).id, review.id);

      const type = await store.getTypeBySlug('order-status');
      const resolvedAt = new Date().toISOString();
      const resolved = await store.updateReview(review.id, {
        status: 'resolved',
        resolution: 'existing_type',
        resolvedTypeId: type.id,
        resolvedBy: 'Huunar',
        resolutionNotes: 'really an order query',
        resolvedAt,
      });

      assert.equal(resolved.status, 'resolved');
      assert.equal(resolved.resolution, 'existing_type');
      assert.equal(resolved.resolvedTypeId, type.id);
      assert.equal(resolved.resolvedBy, 'Huunar');
      assert.equal(resolved.reason, 'no type matched', 'untouched fields preserved');

      await store.deleteEmail(email.id);
    });

    it('persists settings and merges partial updates', async () => {
      const initial = await store.getSettings();
      assert.equal(typeof initial.confidenceThreshold, 'number');
      assert.equal(typeof initial.heuristicThreshold, 'number');

      const saved = await store.saveSettings({ companyName: 'Acme Ltd' });
      assert.equal(saved.companyName, 'Acme Ltd');
      assert.equal(
        saved.confidenceThreshold,
        initial.confidenceThreshold,
        'other settings must survive a partial save',
      );

      const again = await store.saveSettings({ reviewTeamEmail: 'team@acme.test' });
      assert.equal(again.companyName, 'Acme Ltd');
      assert.equal(again.reviewTeamEmail, 'team@acme.test');
      assert.equal((await store.getSettings()).companyName, 'Acme Ltd');
    });

    it('writes the activity log newest first', async () => {
      await store.log('test', 'first entry', { n: 1 });
      await new Promise((r) => setTimeout(r, 15));
      await store.log('test', 'second entry', { n: 2 });

      const entries = await store.listLog(10);
      assert.equal(entries[0].message, 'second entry');
      assert.deepEqual(entries[0].meta, { n: 2 });
      assert.equal(entries[1].message, 'first entry');
    });

    it('reports stats that match the data', async () => {
      await store.reset();

      const type = await store.createType({ name: 'Order Status' });
      await store.addSample({ typeId: type.id, subject: 's', body: 'b', source: 'seed' });
      await store.addSample({ typeId: type.id, subject: 's', body: 'b', source: 'human_review' });

      const classified = await store.createEmail({
        fromEmail: 'a@x.com',
        subject: 'a',
        body: 'a',
        status: 'classified',
      });
      await store.addClassification({
        emailId: classified.id,
        typeId: type.id,
        confidence: 0.9,
        method: 'ai',
        reasoning: 'x',
        scores: [],
      });
      await store.createEmail({ fromEmail: 'b@x.com', subject: 'b', body: 'b', status: 'flagged' });
      await store.createEmail({ fromEmail: 'c@x.com', subject: 'c', body: 'c', status: 'resolved' });

      const draft = await store.addDraft({
        emailId: classified.id,
        typeId: type.id,
        subject: 's',
        body: 'b',
        generatedBy: 'template',
      });
      await store.updateDraft(draft.id, { status: 'sent', sentAt: new Date().toISOString() });

      const stats = await store.stats();
      assert.equal(stats.totalEmails, 3);
      assert.equal(stats.classified, 1);
      assert.equal(stats.flaggedOpen, 1);
      assert.equal(stats.resolved, 1);
      assert.equal(stats.typeCount, 1);
      assert.equal(stats.sampleCount, 2);
      assert.equal(stats.learnedSampleCount, 1, 'human-taught examples are counted separately');
      assert.equal(stats.draftsSent, 1);
      assert.deepEqual(stats.perType, [{ typeId: type.id, typeName: 'Order Status', count: 1 }]);
    });

    it('cascades deletes like the Postgres schema does', async () => {
      await store.reset();
      const type = await store.createType({ name: 'Doomed' });
      const email = await store.createEmail({ fromEmail: 'x@x.com', subject: 's', body: 'b' });

      await store.addSample({ typeId: type.id, subject: 's', body: 'b' });
      await store.addReplyExample({ typeId: type.id, subject: 's', body: 'b' });
      await store.addClassification({
        emailId: email.id,
        typeId: type.id,
        confidence: 1,
        method: 'human',
        reasoning: 'x',
        scores: [],
      });
      const draft = await store.addDraft({
        emailId: email.id,
        typeId: type.id,
        subject: 's',
        body: 'b',
        generatedBy: 'template',
      });

      // Deleting a type removes its drafts/samples and nulls the references.
      await store.deleteType(type.id);
      assert.deepEqual(await store.listSamples(type.id), []);
      assert.deepEqual(await store.listReplyExamples(type.id), []);
      assert.equal((await store.getClassificationForEmail(email.id)).typeId, null);
      assert.equal((await store.getDraft(draft.id)).typeId, null);

      // Deleting an email removes everything hanging off it.
      await store.deleteEmail(email.id);
      assert.equal(await store.getEmail(email.id), null);
      assert.equal(await store.getClassificationForEmail(email.id), null);
      assert.equal(await store.getDraftForEmail(email.id), null);
    });

    it('survives concurrent writes without losing any', async () => {
      await store.reset();
      const type = await store.createType({ name: 'Concurrency' });

      // Fired together on purpose: the file store serialises through a lock and
      // must not drop writes when requests overlap.
      await Promise.all(
        Array.from({ length: 12 }, (_, i) =>
          store.addSample({ typeId: type.id, subject: `s${i}`, body: `b${i}` }),
        ),
      );

      assert.equal((await store.listSamples(type.id)).length, 12);
    });

    it('reset clears data and restores default settings', async () => {
      await store.saveSettings({ companyName: 'Will Be Wiped' });
      await store.createEmail({ fromEmail: 'z@x.com', subject: 's', body: 'b' });

      await store.reset();

      assert.deepEqual(await store.listTypes(), []);
      assert.deepEqual(await store.listEmails(), []);
      assert.deepEqual(await store.listReviews(), []);
      assert.notEqual((await store.getSettings()).companyName, 'Will Be Wiped');
    });
  });
}

if (!TEST_DATABASE_URL) {
  describe('Postgres storage', () => {
    it('is skipped because TEST_DATABASE_URL is not set', () => {
      // Set TEST_DATABASE_URL to run the identical contract against Postgres.
      assert.ok(true);
    });
  });
}
