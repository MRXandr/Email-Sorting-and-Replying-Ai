import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { lib } from './helpers.mjs';

const { tokenize, stripQuotedText, keywordHits, stem, cosine, features, buildIdf, tfidf } =
  lib('classify/text.js');
const { extractJson, parseAddress, displayName, isValidEmail, sanitizeHeader, slugify, truncate } =
  lib('util.js');

describe('tokenize', () => {
  it('drops stopwords and email pleasantries', () => {
    const tokens = tokenize('Dear Sir, please kindly help me with this. Thanks and regards');
    assert.deepEqual(tokens, []);
  });

  it('collapses anything containing digits to a single #num token', () => {
    assert.ok(tokenize('order 88213').includes('#num'));
    assert.ok(tokenize('order ORD-40192').includes('#num'));
    // The exact number must not survive, or nothing would ever match across emails.
    assert.ok(!tokenize('order 88213').includes('88213'));
  });

  it('collapses different surface forms onto one token', () => {
    assert.equal(stem('deliveries'), 'delivery');
    assert.equal(stem('returns'), 'return');
    // What matters is that the forms agree, not that the token is a real word.
    assert.equal(stem('refunded'), stem('refund'));
    assert.equal(stem('charging'), stem('charge'));
    assert.equal(stem('charged'), stem('charge'));
    assert.equal(stem('delays'), stem('delay'));
    assert.equal(stem('invoices'), stem('invoice'));
    assert.equal(stem('received'), stem('receive'));
  });

  it('does not collapse unrelated short words together', () => {
    assert.notEqual(stem('ship'), stem('shop'));
    assert.notEqual(stem('bill'), stem('ball'));
    assert.equal(stem('gst'), 'gst');
    assert.equal(stem('vat'), 'vat');
  });

  it('keeps meaningful words, in stemmed form', () => {
    const tokens = tokenize('My parcel was damaged in transit');
    assert.ok(tokens.includes('parcel'));
    assert.ok(tokens.includes('transit'));
    // Content words survive as their stem, and "damage"/"damaged" share it.
    assert.ok(tokens.includes(stem('damaged')));
    assert.equal(stem('damaged'), stem('damage'));
  });
});

describe('stripQuotedText', () => {
  it('removes an "On ... wrote:" reply chain', () => {
    const body = [
      'I still have not received it.',
      '',
      'On 3 March 2026 at 10:04, Support <s@x.com> wrote:',
      '> Thanks for your patience, we are looking into it.',
      '> Regards',
    ].join('\n');
    const out = stripQuotedText(body);
    assert.ok(out.includes('still have not received'));
    assert.ok(!out.includes('looking into it'));
  });

  it('removes a signature block after the -- delimiter', () => {
    const out = stripQuotedText('Where is my order?\n\n--\nJane Doe\nCEO, Example Ltd\n+1 555 0100');
    assert.ok(out.includes('Where is my order'));
    assert.ok(!out.includes('CEO, Example Ltd'));
  });

  it('keeps the original when stripping would remove almost everything', () => {
    const body = 'On 1 Jan 2026 at 09:00, X <x@y.com> wrote:\n> the whole message is quoted';
    // Nothing meaningful survives, so we must not return an empty string.
    assert.ok(stripQuotedText(body).length > 0);
  });

  it('handles empty input without throwing', () => {
    assert.equal(stripQuotedText(''), '');
  });
});

describe('keywordHits', () => {
  it('matches multi-word phrases and weights them double', () => {
    const phrase = keywordHits(['where is my order'], 'Hello', 'where is my order please');
    const single = keywordHits(['order'], 'Hello', 'where is my order please');
    assert.ok(phrase.score > single.score);
    assert.deepEqual(phrase.hits, ['where is my order']);
  });

  it('saturates so a long keyword list is not penalised for misses', () => {
    const text = 'I want a refund and to return it';
    const two = keywordHits(['refund', 'return'], 'x', text);
    const twoOfTen = keywordHits(
      // The eight extra keywords appear nowhere in the text.
      ['refund', 'return', 'ombudsman', 'chargeback', 'warranty', 'restock', 'courier', 'gstin', 'compatible', 'defective'],
      'x',
      text,
    );
    assert.deepEqual(two.hits, ['refund', 'return']);
    assert.deepEqual(twoOfTen.hits, ['refund', 'return']);
    // Same two real hits → same score, regardless of how long the list is.
    assert.equal(two.score.toFixed(4), twoOfTen.score.toFixed(4));
  });

  it('returns zero when nothing matches', () => {
    const result = keywordHits(['chargeback', 'ombudsman'], 'Hi', 'Just saying hello');
    assert.equal(result.score, 0);
    assert.deepEqual(result.hits, []);
  });

  it('matches a long keyword as a prefix so word forms are covered', () => {
    assert.deepEqual(keywordHits(['refund'], 'x', 'I was refunded already').hits, ['refund']);
    assert.deepEqual(keywordHits(['tracking'], 'x', 'the trackings are wrong').hits, ['tracking']);
  });

  it('requires a whole word for short keywords, so unrelated prefixes do not fire', () => {
    // A prefix match on "vat" would wrongly fire on "Vatican".
    assert.deepEqual(keywordHits(['vat'], 'x', 'a trip to the Vatican museums').hits, []);
    assert.deepEqual(keywordHits(['vat'], 'x', 'please send the VAT invoice').hits, ['vat']);
  });

  it('still matches the plural of a short keyword via the stem path', () => {
    // "awbs" really is the plural of "awb", so this should match even though the
    // whole-word rule blocks the raw prefix.
    assert.deepEqual(keywordHits(['awb'], 'x', 'the awbs are all wrong').hits, ['awb']);
  });
});

describe('cosine similarity', () => {
  it('is 1 for identical documents and low for unrelated ones', () => {
    const a = features('refund my order', 'I want a refund for my damaged order');
    const b = features('refund my order', 'I want a refund for my damaged order');
    const c = features('server maintenance window', 'we are patching the kubernetes cluster tonight');

    const idf = buildIdf([a, b, c]);
    const va = tfidf(a, idf);
    const vb = tfidf(b, idf);
    const vc = tfidf(c, idf);

    assert.ok(cosine(va, vb) > 0.99);
    assert.ok(cosine(va, vc) < 0.1);
  });

  it('is 0 against an empty document', () => {
    const idf = buildIdf([features('a', 'refund')]);
    assert.equal(cosine(tfidf(features('', ''), idf), tfidf(features('a', 'refund'), idf)), 0);
  });
});

describe('extractJson', () => {
  it('parses bare JSON', () => {
    assert.deepEqual(extractJson('{"slug":"a","confidence":0.9}'), { slug: 'a', confidence: 0.9 });
  });

  it('parses JSON inside a markdown fence', () => {
    assert.deepEqual(extractJson('```json\n{"slug":"b"}\n```'), { slug: 'b' });
  });

  it('parses JSON preceded by prose', () => {
    assert.deepEqual(extractJson('Sure! Here is the result:\n{"slug":"c"}\nHope that helps.'), {
      slug: 'c',
    });
  });

  it('is not confused by braces inside strings', () => {
    const parsed = extractJson('{"body":"use {{order_id}} here","ok":true}');
    assert.equal(parsed.body, 'use {{order_id}} here');
    assert.equal(parsed.ok, true);
  });

  it('handles nested objects', () => {
    const parsed = extractJson('noise {"a":{"b":{"c":1}},"d":[1,2]} more noise');
    assert.equal(parsed.a.b.c, 1);
  });

  it('returns null when there is no JSON', () => {
    assert.equal(extractJson('I cannot help with that.'), null);
    assert.equal(extractJson(''), null);
  });
});

describe('address handling', () => {
  it('parses a display name and address', () => {
    assert.deepEqual(parseAddress('Priya Sharma <priya@example.com>'), {
      name: 'Priya Sharma',
      email: 'priya@example.com',
    });
  });

  it('parses a bare address', () => {
    assert.deepEqual(parseAddress('bob@example.com'), { name: '', email: 'bob@example.com' });
  });

  it('strips quotes around the display name', () => {
    assert.equal(parseAddress('"Sharma, Priya" <p@x.com>').name, 'Sharma, Priya');
  });

  it('derives a readable name from the address when there is no display name', () => {
    assert.equal(displayName('', 'priya.sharma@example.com'), 'Priya Sharma');
    assert.equal(displayName('', 'john_doe99@example.com'), 'John Doe');
    assert.equal(displayName('', ''), 'there');
  });

  it('prefers a real display name over the address', () => {
    assert.equal(displayName('Ada Lovelace', 'al@example.com'), 'Ada Lovelace');
  });
});

describe('isValidEmail', () => {
  it('accepts normal addresses', () => {
    assert.ok(isValidEmail('a.b-c+tag@sub.example.co.uk'));
  });

  it('rejects malformed and dangerous values', () => {
    for (const bad of [
      '',
      'nope',
      'a@b',
      'a b@example.com',
      'a@@example.com',
      'a@example.com\nBcc: evil@x.com',
      'a@example.com, b@example.com',
      `${'x'.repeat(250)}@example.com`,
    ]) {
      assert.equal(isValidEmail(bad), false, `expected ${JSON.stringify(bad)} to be rejected`);
    }
  });
});

describe('sanitizeHeader', () => {
  it('strips CR and LF so headers cannot be injected', () => {
    assert.equal(
      sanitizeHeader('Order update\r\nBcc: attacker@example.com'),
      'Order update Bcc: attacker@example.com',
    );
    assert.ok(!sanitizeHeader('a\nb').includes('\n'));
  });
});

describe('slugify', () => {
  it('produces url-safe slugs', () => {
    assert.equal(slugify('Order Status & Delivery'), 'order-status-delivery');
    assert.equal(slugify('  Refunds/Returns  '), 'refunds-returns');
  });

  it('never returns an empty string', () => {
    assert.equal(slugify('!!!'), 'type');
    assert.equal(slugify(''), 'type');
  });
});

describe('truncate', () => {
  it('leaves short text alone', () => {
    assert.equal(truncate('hello', 20), 'hello');
  });

  it('shortens long text and marks it', () => {
    const out = truncate('a'.repeat(100), 10);
    assert.ok(out.length <= 11);
    assert.ok(out.endsWith('…'));
  });
});
