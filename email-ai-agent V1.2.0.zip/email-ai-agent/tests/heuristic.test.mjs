import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { lib } from './helpers.mjs';

const { scoreHeuristic, scoreMargin } = lib('classify/heuristic.js');
const { SEED_TYPES, SEED_INBOX } = lib('seed.js');
const { DEFAULT_SETTINGS } = lib('db/store.js');

const profiles = SEED_TYPES.map((t, i) => ({
  typeId: `type-${i}`,
  typeName: t.name,
  slug: t.slug,
  description: t.description ?? '',
  keywords: t.keywords ?? [],
  samples: t.samples,
}));

describe('scoreHeuristic', () => {
  it('returns every type, ranked best first', () => {
    const scores = scoreHeuristic({ subject: 'where is my order 123', body: 'not arrived' }, profiles);
    assert.equal(scores.length, profiles.length);
    for (let i = 1; i < scores.length; i++) {
      assert.ok(scores[i - 1].score >= scores[i].score, 'scores must be in descending order');
    }
  });

  it('returns an empty array when there are no types', () => {
    assert.deepEqual(scoreHeuristic({ subject: 'x', body: 'y' }, []), []);
  });

  it('gives every seeded input draft the right type when that draft is held out', () => {
    // Leave-one-out: scoring a draft that is still in its own training data is a
    // free win, so each draft is removed before being scored.
    for (const [ti, seedType] of SEED_TYPES.entries()) {
      for (const [si, sample] of seedType.samples.entries()) {
        const heldOut = profiles.map((p, i) =>
          i === ti ? { ...p, samples: p.samples.filter((_, k) => k !== si) } : p,
        );
        const top = scoreHeuristic(sample, heldOut)[0];
        assert.equal(
          top.slug,
          seedType.slug,
          `"${sample.subject}" should be ${seedType.slug} but got ${top.slug}`,
        );
      }
    }
  });

  it('scores each known demo email above the threshold, on the right type', () => {
    for (const email of SEED_INBOX.filter((e) => !e.expectFlag)) {
      const scores = scoreHeuristic(email, profiles);
      assert.ok(
        scores[0].score >= DEFAULT_SETTINGS.heuristicThreshold,
        `"${email.subject}" scored ${scores[0].score}, below the ${DEFAULT_SETTINGS.heuristicThreshold} threshold`,
      );
      assert.ok(
        scoreMargin(scores) >= DEFAULT_SETTINGS.marginThreshold,
        `"${email.subject}" margin ${scoreMargin(scores)} is too narrow`,
      );
    }
  });

  it('scores emails of unknown kinds below the threshold so they get flagged', () => {
    for (const email of SEED_INBOX.filter((e) => e.expectFlag)) {
      const top = scoreHeuristic(email, profiles)[0];
      assert.ok(
        top.score < DEFAULT_SETTINGS.heuristicThreshold,
        `"${email.subject}" scored ${top.score}, which would wrongly classify it as ${top.slug}`,
      );
    }
  });

  it('does not let a stray keyword outrank real similarity', () => {
    // A supplier pitch that happens to say "shipping" is not an order enquiry.
    // The corroboration damping is what keeps this below the threshold.
    const pitch = {
      subject: 'Partnership proposal for retail packaging',
      body:
        'We manufacture compostable cartons and can hold buffer stock. Minimum order quantity ' +
        'is 5000 units. Happy to send samples if you share a shipping address. Rate card attached.',
    };
    const top = scoreHeuristic(pitch, profiles)[0];
    assert.ok(
      top.score < DEFAULT_SETTINGS.heuristicThreshold,
      `stray-keyword pitch scored ${top.score} on ${top.slug}`,
    );
  });

  it('handles terse real-world phrasing', () => {
    const cases = [
      { subject: 'where is it', body: 'ordered 5 days ago nothing has come. order 4471.', want: 'order-status' },
      { subject: 'wrong colour sent', body: 'I got black, I paid for green. want to swap it.', want: 'returns-refunds' },
      { subject: 'stock question', body: 'is the 65 inch model available? not bought yet, just asking.', want: 'product-info' },
      { subject: 'billed 3 times', body: 'three identical amounts on my statement today. only one order placed.', want: 'billing-payment' },
      { subject: 'no reply in 2 weeks', body: 'I have written twice and heard nothing. put me through to a supervisor.', want: 'complaint-escalation' },
    ];
    for (const probe of cases) {
      const top = scoreHeuristic(probe, profiles)[0];
      assert.equal(top.slug, probe.want, `"${probe.subject}" → ${top.slug}, expected ${probe.want}`);
    }
  });

  it('reports the signal breakdown for the UI', () => {
    const top = scoreHeuristic(
      { subject: 'Need to return these shoes', body: 'too small, want a refund for order 61277' },
      profiles,
    )[0];
    assert.equal(typeof top.bestSample, 'number');
    assert.equal(typeof top.centroid, 'number');
    assert.equal(typeof top.keyword, 'number');
    assert.equal(typeof top.corroboration, 'number');
    assert.ok(Array.isArray(top.matchedKeywords));
    assert.ok(top.matchedKeywords.length > 0);
  });

  it('scores empty input at zero rather than throwing', () => {
    const scores = scoreHeuristic({ subject: '', body: '' }, profiles);
    assert.equal(scores.length, profiles.length);
    assert.ok(scores.every((s) => s.score === 0));
  });

  it('copes with a type that has a description but no samples yet', () => {
    const bare = [
      ...profiles,
      {
        typeId: 'bare',
        typeName: 'Warranty Claim',
        slug: 'warranty-claim',
        description: 'A customer claiming under the manufacturer warranty for a failed product.',
        keywords: ['warranty claim', 'under warranty'],
        samples: [],
      },
    ];
    const scores = scoreHeuristic(
      { subject: 'Warranty claim', body: 'My unit failed, it is still under warranty.' },
      bare,
    );
    assert.equal(scores[0].slug, 'warranty-claim');
  });
});

describe('scoreMargin', () => {
  it('is the gap between first and second', () => {
    assert.equal(scoreMargin([{ score: 0.8 }, { score: 0.3 }]), 0.5);
  });

  it('is the only score when there is one candidate', () => {
    assert.equal(scoreMargin([{ score: 0.42 }]), 0.42);
  });

  it('is zero for no candidates', () => {
    assert.equal(scoreMargin([]), 0);
  });
});
