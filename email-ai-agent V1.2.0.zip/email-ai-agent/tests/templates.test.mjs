import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { lib, testSettings } from './helpers.mjs';

const {
  extractEntities,
  fillTemplate,
  findPlaceholders,
  stripReplyPrefix,
  buildPlaceholderValues,
} = lib('draft/templates.js');

describe('extractEntities', () => {
  it('finds labelled order numbers in several shapes', () => {
    assert.equal(extractEntities('', 'my order 88213 is late').orderId, '88213');
    assert.equal(extractEntities('', 'Order no. 40192 please').orderId, '40192');
    assert.equal(extractEntities('', 'order #77451').orderId, '77451');
    assert.equal(extractEntities('', 'Order ID: ORD-4019').orderId, 'ORD-4019');
    assert.equal(extractEntities('Where is order 92771?', '').orderId, '92771');
  });

  it('finds a bare prefixed reference', () => {
    assert.equal(extractEntities('', 'Reference ORD-40192 refers').orderId, 'ORD-40192');
  });

  it('finds invoice and tracking references', () => {
    assert.equal(extractEntities('', 'invoice number 5511 attached').invoiceId, '5511');
    assert.equal(extractEntities('', 'tracking number AB123456789XY').trackingId, 'AB123456789XY');
    assert.equal(extractEntities('', 'AWB: 7788990011').trackingId, '7788990011');
  });

  it('returns null rather than guessing when there is no reference', () => {
    const entities = extractEntities('Question before I buy', 'Does it come in white?');
    assert.equal(entities.orderId, null);
    assert.equal(entities.invoiceId, null);
    assert.equal(entities.trackingId, null);
  });

  it('does not treat an arbitrary number as an order id', () => {
    // "5,000 units" and a phone number must not become an order number.
    const entities = extractEntities('Proposal', 'Our minimum is 5000 units. Call 9876543210.');
    assert.equal(entities.orderId, null);
  });

  it('is repeatable — no regex lastIndex leakage between calls', () => {
    const text = 'order 12345 here';
    assert.equal(extractEntities('', text).orderId, '12345');
    assert.equal(extractEntities('', text).orderId, '12345');
    assert.equal(extractEntities('', text).orderId, '12345');
  });
});

describe('stripReplyPrefix', () => {
  it('removes one or many reply prefixes', () => {
    assert.equal(stripReplyPrefix('Re: Order late'), 'Order late');
    assert.equal(stripReplyPrefix('RE: Re: FWD: Order late'), 'Order late');
    assert.equal(stripReplyPrefix('Re[2]: Order late'), 'Order late');
  });

  it('leaves a normal subject untouched', () => {
    assert.equal(stripReplyPrefix('Refund please'), 'Refund please');
    assert.equal(stripReplyPrefix(''), '');
  });

  it('does not eat a word that merely starts with "re"', () => {
    assert.equal(stripReplyPrefix('Return request'), 'Return request');
  });
});

describe('fillTemplate', () => {
  it('substitutes known values', () => {
    const result = fillTemplate('Hi {{customer_first_name}}, about {{order_id}}.', {
      customer_first_name: 'Ada',
      order_id: '123',
    });
    assert.equal(result.text, 'Hi Ada, about 123.');
    assert.deepEqual(result.unresolved, []);
  });

  it('leaves unknown placeholders in place and reports them', () => {
    const result = fillTemplate('Update by {{expected_resolution_date}} for {{customer_name}}.', {
      customer_name: 'Ada',
    });
    // The token stays visible so a human can see exactly what needs filling.
    assert.ok(result.text.includes('{{expected_resolution_date}}'));
    assert.deepEqual(result.unresolved, ['expected_resolution_date']);
  });

  it('treats an empty-string value as unresolved', () => {
    const result = fillTemplate('Order {{order_id}}.', { order_id: '' });
    assert.deepEqual(result.unresolved, ['order_id']);
  });

  it('tolerates whitespace inside the braces', () => {
    assert.equal(fillTemplate('Hi {{  name  }}', { name: 'Ada' }).text, 'Hi Ada');
  });

  it('reports each unresolved placeholder once even if repeated', () => {
    const result = fillTemplate('{{a}} then {{a}} then {{a}}', {});
    assert.deepEqual(result.unresolved, ['a']);
  });

  it('handles an empty template', () => {
    assert.deepEqual(fillTemplate('', {}), { text: '', unresolved: [] });
  });
});

describe('findPlaceholders', () => {
  it('finds placeholders left in finished text', () => {
    assert.deepEqual(findPlaceholders('Hi, update by {{eta}} on {{order_id}}.').sort(), [
      'eta',
      'order_id',
    ]);
  });

  it('returns an empty list for clean text', () => {
    assert.deepEqual(findPlaceholders('All values filled in.'), []);
  });
});

describe('buildPlaceholderValues', () => {
  const settings = testSettings({
    companyName: 'Northwind Retail',
    supportSignature: 'Care Team\nNorthwind',
  });

  it('builds names, subject and company values', () => {
    const values = buildPlaceholderValues(
      {
        fromName: 'Kavya Reddy',
        fromEmail: 'kavya@example.com',
        subject: 'Re: Still no sign of order 92771',
        body: 'Order 92771 has not arrived.',
      },
      settings,
    );

    assert.equal(values.customer_name, 'Kavya Reddy');
    assert.equal(values.customer_first_name, 'Kavya');
    assert.equal(values.customer_email, 'kavya@example.com');
    // The Re: prefix is stripped so replies do not stack "Re: Re:".
    assert.equal(values.subject, 'Still no sign of order 92771');
    assert.equal(values.order_id, '92771');
    assert.equal(values.company_name, 'Northwind Retail');
    assert.equal(values.signature, 'Care Team\nNorthwind');
    assert.match(values.today, /^\d{4}-\d{2}-\d{2}$/);
  });

  it('omits reference numbers that are not present, so they show as unresolved', () => {
    const values = buildPlaceholderValues(
      { fromName: '', fromEmail: 'a@b.com', subject: 'Pre-sales question', body: 'Is it in stock?' },
      settings,
    );
    assert.equal(values.order_id, undefined);
    assert.equal(values.invoice_id, undefined);

    const filled = fillTemplate('About order {{order_id}}.', values);
    assert.deepEqual(filled.unresolved, ['order_id']);
  });

  it('falls back to a readable name when there is no display name', () => {
    const values = buildPlaceholderValues(
      { fromName: '', fromEmail: 'joel.mensah@example.com', subject: 's', body: 'b' },
      settings,
    );
    assert.equal(values.customer_name, 'Joel Mensah');
    assert.equal(values.customer_first_name, 'Joel');
  });
});
