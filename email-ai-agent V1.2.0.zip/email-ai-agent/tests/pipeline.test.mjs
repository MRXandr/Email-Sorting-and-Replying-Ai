import assert from 'node:assert/strict';
import { after, before, beforeEach, describe, it } from 'node:test';
import {
  classifyJson,
  draftJson,
  fakeAi,
  isClassifyRequest,
  lib,
  storeFactories,
} from './helpers.mjs';

const { processEmail, reprocessEmail, resolveReviewItem } = lib('pipeline.js');
const { seedDatabase, SEED_INBOX } = lib('seed.js');
const { setAiProviderOverride } = lib('ai/index.js');
const { buildFlagFile } = lib('flagfile.js');

/** Pick a demo email by the note recorded against it in the seed data. */
function demo(match) {
  const found = SEED_INBOX.find((e) => e.subject.includes(match));
  if (!found) throw new Error(`no demo email matching "${match}"`);
  const [, name, email] = found.from.match(/^(.*?)\s*<(.+)>$/) ?? [null, '', found.from];
  return { fromName: name, fromEmail: email, subject: found.subject, body: found.body };
}

const PACKAGING_PITCH = demo('Wholesale partnership');
const JOB_APPLICATION = demo('Warehouse Supervisor');
const ORDER_EMAIL = demo('Still no sign of order');
const RETURN_EMAIL = demo('wrong size');

// A second supplier pitch, worded differently. Used to prove that teaching the
// system from the first one makes this one classify with no human involved.
const SECOND_PITCH = {
  fromName: 'Ravi Kulkarni',
  fromEmail: 'ravi@ecocartons.example',
  subject: 'Supplier introduction — recycled carton manufacturer',
  body: `Dear Procurement,

I represent EcoCartons, a manufacturer of recycled corrugated cartons and moulded pulp trays based in Coimbatore.

We already supply three national retail chains and hold buffer stock for call-off orders. Our minimum order quantity is 3,000 units and we can offer volume pricing tiers.

I have attached our catalogue and rate card. Could your buying team spare twenty minutes next week to discuss a trial consignment and wholesale terms?

Best regards,
Ravi Kulkarni
Business Development, EcoCartons Pvt Ltd`,
};

for (const factory of storeFactories()) {
  describe(`Pipeline — ${factory.name}`, () => {
    let store;
    let cleanup;

    before(async () => {
      const created = await factory.create();
      store = created.store;
      cleanup = created.cleanup;
    });

    after(async () => {
      setAiProviderOverride(undefined);
      await cleanup();
    });

    beforeEach(async () => {
      // No AI by default: the offline path must work on its own, and these tests
      // must never depend on a network call or an API key.
      setAiProviderOverride(null);
      await seedDatabase(store);
    });

    it('seeds five types with their input drafts', async () => {
      const types = await store.listTypes();
      assert.equal(types.length, 5);

      for (const type of types) {
        assert.ok(type.replyBody.length > 50, `${type.name} needs an output draft`);
        assert.ok(type.description.length > 20, `${type.name} needs a description`);
        assert.ok(type.keywords.length > 0, `${type.name} needs keywords`);
        assert.ok(
          (await store.listSamples(type.id)).length >= 3,
          `${type.name} needs at least three input drafts`,
        );
      }
    });

    it('classifies a known email and drafts a reply from its output draft', async () => {
      const result = await processEmail(store, { ...ORDER_EMAIL, source: 'manual' });

      assert.equal(result.flagged, false);
      assert.equal(result.type.slug, 'order-status');
      assert.equal(result.email.status, 'classified');
      assert.equal(result.review, null);
      assert.ok(result.draft, 'a draft must be created');

      // The draft is built from the type's template, with placeholders filled.
      assert.equal(result.draft.generatedBy, 'template');
      assert.ok(result.draft.body.includes('Kavya'), 'greeting should use the sender name');
      assert.ok(result.draft.body.includes('92771'), 'order number should be substituted');
      assert.ok(!result.draft.body.includes('{{'), 'no placeholder should be left unfilled');
      assert.deepEqual(result.draft.unresolvedPlaceholders, []);
      assert.ok(result.draft.body.includes('Northwind Retail'), 'signature should be present');
      assert.equal(result.draft.status, 'draft', 'nothing is sent without approval');
      assert.equal(result.autoSend, null);
    });

    it('records the decision with a readable explanation', async () => {
      const result = await processEmail(store, RETURN_EMAIL);
      const classification = await store.getClassificationForEmail(result.email.id);

      assert.equal(classification.typeId, result.type.id);
      assert.equal(classification.method, 'heuristic');
      assert.ok(classification.confidence > 0);
      assert.ok(classification.reasoning.length > 20);
      // Every type is scored, so the UI can show the runners-up.
      assert.equal(classification.scores.length, 5);
      assert.ok(classification.scores[0].score >= classification.scores[1].score);
    });

    it('flags an email that matches no type, and queues it for a human', async () => {
      const result = await processEmail(store, PACKAGING_PITCH);

      assert.equal(result.flagged, true);
      assert.equal(result.type, null);
      assert.equal(result.draft, null, 'no reply is drafted for unknown mail');
      assert.equal(result.email.status, 'flagged');

      assert.ok(result.review, 'a review item must be created');
      assert.equal(result.review.status, 'open');
      assert.ok(result.review.reason.length > 20);
      assert.ok(result.review.topScores.length > 0, 'closest guesses are recorded for the human');

      const open = await store.listReviews('open');
      assert.equal(open.length, 1);
      assert.equal(open[0].emailId, result.email.id);
    });

    it('flags a second unrelated kind of email too', async () => {
      const result = await processEmail(store, JOB_APPLICATION);
      assert.equal(result.flagged, true);
      assert.equal(result.draft, null);
    });

    it('writes a file describing the flagged email', async () => {
      const result = await processEmail(store, PACKAGING_PITCH);
      const settings = await store.getSettings();

      const file = buildFlagFile({
        email: result.email,
        classification: result.classification,
        review: result.review,
        settings,
        baseUrl: 'http://localhost:3000',
      });

      assert.match(file.filename, /^flagged-email-\d{4}-\d{2}-\d{2}-[a-z0-9]+\.txt$/);
      assert.ok(file.content.includes('HUMAN REVIEW REQUIRED'));
      assert.ok(file.content.includes(PACKAGING_PITCH.fromEmail), 'sender must be in the file');
      assert.ok(file.content.includes('Bright Packaging'), 'the full body must be in the file');
      assert.ok(file.content.includes('WHY THIS EMAIL WAS FLAGGED'));
      assert.ok(file.content.includes(`/review/${result.review.id}`), 'a link back to the queue');
      assert.ok(file.content.includes('IT IS A NEW KIND OF EMAIL'), 'instructions for the team');
    });

    it('reports clearly when no review address is configured', async () => {
      const result = await processEmail(store, PACKAGING_PITCH);
      // Nothing is silently swallowed: the alert outcome says exactly what happened.
      assert.ok(result.alert);
      assert.equal(result.alert.ok, false);
      assert.match(result.alert.error, /review team address/i);
      assert.ok(result.alert.filename, 'the file is still produced');
    });

    it('reports an SMTP failure without losing the review item', async () => {
      await store.saveSettings({ reviewTeamEmail: 'team@example.test' });
      const result = await processEmail(store, JOB_APPLICATION);

      assert.equal(result.alert.attempted, true);
      assert.equal(result.alert.ok, false);
      // SMTP is not configured in tests, so the send is skipped — but the email
      // is still safely in the queue, which is the thing that matters.
      assert.match(result.alert.error, /SMTP is not configured/i);
      assert.equal((await store.listReviews('open')).length, 1);
    });

    it('never processes the same message twice', async () => {
      const input = { ...ORDER_EMAIL, externalId: '<dupe-test@mail.example>' };
      const first = await processEmail(store, input);
      const second = await processEmail(store, input);

      assert.equal(second.duplicate, true);
      assert.equal(second.email.id, first.email.id);
      assert.equal(await store.countEmails(), 1);
    });

    // ---------------------------------------------------------------- learning

    it('learns from a human assigning a flagged email to an existing type', async () => {
      const flagged = await processEmail(store, {
        fromName: 'Ann',
        fromEmail: 'ann@example.com',
        subject: 'Parcel query',
        body: 'Hello, a quick question about something I bought.',
      });
      assert.equal(flagged.flagged, true);

      const orderType = await store.getTypeBySlug('order-status');
      const before = (await store.listSamples(orderType.id)).length;

      const resolved = await resolveReviewItem(store, flagged.review.id, {
        mode: 'existing',
        typeId: orderType.id,
        resolvedBy: 'Huunar',
        notes: 'This is really an order status question.',
      });

      assert.equal(resolved.createdType, false);
      assert.equal(resolved.learned, true);
      assert.equal(resolved.resolvedType.id, orderType.id);
      assert.equal(resolved.email.status, 'resolved');
      assert.equal(resolved.review.status, 'resolved');
      assert.equal(resolved.review.resolution, 'existing_type');
      assert.equal(resolved.review.resolvedBy, 'Huunar');
      assert.ok(resolved.draft, 'a reply is drafted once the type is known');

      // THE LEARNING STEP: the email is now an input draft for that type.
      const samples = await store.listSamples(orderType.id);
      assert.equal(samples.length, before + 1);
      const learned = samples.filter((s) => s.source === 'human_review');
      assert.equal(learned.length, 1);
      assert.equal(learned[0].subject, 'Parcel query');

      // It is recorded as a human decision, not an AI guess.
      assert.equal(resolved.classification.method, 'human');
      assert.equal(resolved.classification.confidence, 1);
      assert.ok(resolved.classification.reasoning.includes('Huunar'));

      const stats = await store.stats();
      assert.equal(stats.learnedSampleCount, 1);
    });

    it('creates a new type from a flagged email, with its own input and output drafts', async () => {
      const flagged = await processEmail(store, PACKAGING_PITCH);

      const resolved = await resolveReviewItem(store, flagged.review.id, {
        mode: 'new',
        name: 'Supplier & Partnership Enquiry',
        description:
          'A business contacting us to sell us something or propose a partnership: suppliers, ' +
          'manufacturers, wholesale offers, distribution or reseller proposals.',
        keywords: ['wholesale', 'partnership', 'supplier', 'rate card', 'minimum order quantity'],
        replySubject: 'Re: {{subject}}',
        replyBody:
          'Hello {{customer_name}},\n\nThank you for getting in touch about working with ' +
          '{{company_name}}.\n\nI have passed your details to our buying team, who review new ' +
          'supplier proposals monthly. They will contact you directly if there is a fit.\n\n' +
          'Best regards,\n{{signature}}',
        replyGuidance: 'Polite but non-committal. Never agree to pricing or volumes.',
        resolvedBy: 'Huunar',
      });

      assert.equal(resolved.createdType, true);
      assert.equal(resolved.review.resolution, 'new_type');
      assert.equal(resolved.resolvedType.slug, 'supplier-partnership-enquiry');

      // Six types now, and the new one owns this email as its first example.
      assert.equal((await store.listTypes()).length, 6);
      const samples = await store.listSamples(resolved.resolvedType.id);
      assert.equal(samples.length, 1);
      assert.equal(samples[0].source, 'human_review');

      // A reply was drafted from the output draft the human just supplied.
      assert.ok(resolved.draft.body.includes('Priyanka'), 'the new template was filled in');
      assert.ok(resolved.draft.body.includes('Northwind Retail'));
      assert.ok(!resolved.draft.body.includes('{{'));
    });

    it('recognises the next email of a newly taught type with no human involved', async () => {
      // This is the whole point of the learning loop, so it is tested end to end
      // with the AI switched off — only the stored example can make this work.
      const flagged = await processEmail(store, PACKAGING_PITCH);
      assert.equal(flagged.flagged, true, 'the first pitch must be unknown');

      // A similar pitch is still unknown before teaching.
      const beforeTeaching = await processEmail(store, SECOND_PITCH);
      assert.equal(beforeTeaching.flagged, true, 'the second pitch is unknown before teaching');

      await resolveReviewItem(store, flagged.review.id, {
        mode: 'new',
        name: 'Supplier & Partnership Enquiry',
        description:
          'A business contacting us to sell us something or propose a partnership: suppliers, ' +
          'manufacturers, wholesale offers, distribution or reseller proposals.',
        keywords: ['wholesale', 'partnership', 'supplier', 'rate card', 'minimum order quantity'],
        replySubject: 'Re: {{subject}}',
        replyBody: 'Hello {{customer_name}},\n\nThank you for your proposal.\n\n{{signature}}',
        resolvedBy: 'Huunar',
      });

      // Now the same kind of email is classified automatically.
      const afterTeaching = await processEmail(store, {
        ...SECOND_PITCH,
        subject: `${SECOND_PITCH.subject} (second copy)`,
      });

      assert.equal(afterTeaching.flagged, false, 'the taught type should now match');
      assert.equal(afterTeaching.type.slug, 'supplier-partnership-enquiry');
      assert.ok(afterTeaching.draft, 'and a reply is drafted automatically');
      assert.ok(afterTeaching.draft.body.includes('Ravi'));
    });

    it('reprocesses an older flagged email once the system has learned', async () => {
      const first = await processEmail(store, PACKAGING_PITCH);
      const stillUnknown = await processEmail(store, SECOND_PITCH);
      assert.equal(stillUnknown.flagged, true);

      await resolveReviewItem(store, first.review.id, {
        mode: 'new',
        name: 'Supplier & Partnership Enquiry',
        description: 'Businesses proposing to supply us or partner with us.',
        keywords: ['wholesale', 'partnership', 'supplier', 'rate card', 'minimum order quantity'],
        replyBody: 'Hello {{customer_name}},\n\nThank you.\n\n{{signature}}',
      });

      const reprocessed = await reprocessEmail(store, stillUnknown.email.id);

      assert.equal(reprocessed.flagged, false);
      assert.equal(reprocessed.type.slug, 'supplier-partnership-enquiry');
      assert.ok(reprocessed.draft);

      // The human's outstanding request is closed automatically.
      const review = await store.getReviewForEmail(stillUnknown.email.id);
      assert.equal(review.status, 'resolved');
      assert.match(review.resolvedBy, /system/i);
      assert.equal((await store.listReviews('open')).length, 0);
    });

    it('can assign a flagged email without storing it as a training example', async () => {
      const flagged = await processEmail(store, JOB_APPLICATION);
      const orderType = await store.getTypeBySlug('order-status');
      const before = (await store.listSamples(orderType.id)).length;

      const resolved = await resolveReviewItem(store, flagged.review.id, {
        mode: 'existing',
        typeId: orderType.id,
        learn: false,
      });

      assert.equal(resolved.learned, false);
      assert.equal((await store.listSamples(orderType.id)).length, before);
      assert.ok(resolved.draft, 'a reply is still drafted');
    });

    it('refuses to resolve the same review item twice', async () => {
      const flagged = await processEmail(store, PACKAGING_PITCH);
      const orderType = await store.getTypeBySlug('order-status');

      await resolveReviewItem(store, flagged.review.id, { mode: 'existing', typeId: orderType.id });

      await assert.rejects(
        () => resolveReviewItem(store, flagged.review.id, { mode: 'existing', typeId: orderType.id }),
        (err) => err.status === 409,
      );
    });

    it('rejects a bad resolution request', async () => {
      const flagged = await processEmail(store, PACKAGING_PITCH);

      await assert.rejects(
        () => resolveReviewItem(store, flagged.review.id, { mode: 'existing', typeId: 'nope' }),
        (err) => err.status === 400,
      );
      await assert.rejects(
        () => resolveReviewItem(store, flagged.review.id, { mode: 'new', name: '   ' }),
        (err) => err.status === 400,
      );
      await assert.rejects(
        () => resolveReviewItem(store, 'missing-id', { mode: 'existing', typeId: 'x' }),
        (err) => err.status === 404,
      );
    });

    // ---------------------------------------------------------------- AI paths

    it('uses the AI verdict when a provider is configured', async () => {
      setAiProviderOverride(
        fakeAi((req) =>
          isClassifyRequest(req)
            ? classifyJson({ slug: 'billing-payment', confidence: 0.93, reasoning: 'Duplicate charge.' })
            : draftJson({ subject: 'Re: your billing query', body: 'A'.repeat(120) }),
        ),
      );

      const result = await processEmail(store, ORDER_EMAIL);

      // The model's answer wins over the offline matcher, which would have said
      // order-status — that difference is exactly what we are checking.
      assert.equal(result.type.slug, 'billing-payment');
      assert.equal(result.classification.confidence, 0.93);
      assert.equal(result.classification.method, 'ai');
      assert.ok(result.classification.reasoning.includes('Duplicate charge'));
      assert.ok(result.classification.reasoning.includes('offline matcher would have ranked'));
      assert.equal(result.draft.generatedBy, 'fake:test-1');
      assert.equal(result.draft.subject, 'Re: your billing query');
    });

    it('marks agreement when the AI and the offline matcher concur', async () => {
      setAiProviderOverride(
        fakeAi((req) =>
          isClassifyRequest(req)
            ? classifyJson({ slug: 'order-status', confidence: 0.9 })
            : draftJson({ body: 'B'.repeat(120) }),
        ),
      );

      const result = await processEmail(store, ORDER_EMAIL);
      assert.equal(result.classification.method, 'ai+heuristic');
      assert.ok(result.classification.reasoning.includes('independently ranked the same type'));
    });

    it('flags the email when the AI says nothing matches', async () => {
      setAiProviderOverride(
        fakeAi(() => classifyJson({ slug: null, confidence: 0.9, reasoning: 'This is a supplier pitch.' })),
      );

      const result = await processEmail(store, PACKAGING_PITCH);
      assert.equal(result.flagged, true);
      assert.equal(result.draft, null);
      assert.ok(result.review.reason.includes('supplier pitch'));
    });

    it('flags rather than guessing when the AI is unsure', async () => {
      setAiProviderOverride(
        fakeAi(() =>
          classifyJson({ slug: 'order-status', confidence: 0.4, reasoning: 'Could be a few things.' }),
        ),
      );

      const result = await processEmail(store, ORDER_EMAIL);
      assert.equal(result.flagged, true);
      assert.match(result.review.reason, /below the 0\.60 threshold/);
    });

    it('flags when the AI invents a category that does not exist', async () => {
      setAiProviderOverride(
        fakeAi(() => classifyJson({ slug: 'totally-made-up-category', confidence: 0.99 })),
      );

      const result = await processEmail(store, ORDER_EMAIL);
      assert.equal(result.flagged, true);
      assert.ok(result.classification.reasoning.includes('unknown category'));
    });

    it('treats the string "null" from a model as a real null', async () => {
      setAiProviderOverride(fakeAi(() => classifyJson({ slug: 'none', confidence: 0.8 })));
      const result = await processEmail(store, ORDER_EMAIL);
      assert.equal(result.flagged, true);
    });

    it('falls back to the offline matcher when the AI call fails', async () => {
      setAiProviderOverride(
        fakeAi(() => {
          throw new Error('simulated network outage');
        }),
      );

      const result = await processEmail(store, ORDER_EMAIL);

      // The work still gets done, and the failure is surfaced rather than hidden.
      assert.equal(result.flagged, false);
      assert.equal(result.type.slug, 'order-status');
      assert.equal(result.classification.method, 'heuristic');
      assert.ok(result.aiError.includes('simulated network outage'));
      assert.ok(result.classification.reasoning.includes('could not be reached'));
      assert.equal(result.draft.generatedBy, 'template', 'the drafter falls back too');
      assert.ok(result.draftAiError);
    });

    it('falls back when the AI returns unparseable output', async () => {
      setAiProviderOverride(fakeAi(() => 'I am terribly sorry, I cannot help with that.'));

      const result = await processEmail(store, ORDER_EMAIL);
      assert.equal(result.classification.method, 'heuristic');
      assert.ok(result.aiError.includes('could not find a JSON object'));
      assert.equal(result.type.slug, 'order-status');
    });

    it('keeps the template when the AI returns a uselessly short reply', async () => {
      setAiProviderOverride(
        fakeAi((req) =>
          isClassifyRequest(req)
            ? classifyJson({ slug: 'order-status', confidence: 0.9 })
            : draftJson({ body: 'ok' }),
        ),
      );

      const result = await processEmail(store, ORDER_EMAIL);
      assert.equal(result.draft.generatedBy, 'template');
      assert.match(result.draftAiError, /unusably short/);
      assert.ok(result.draft.body.length > 100);
    });

    it('passes human-taught examples to the AI first', async () => {
      const orderType = await store.getTypeBySlug('order-status');
      await store.addSample({
        typeId: orderType.id,
        subject: 'TAUGHT-BY-HUMAN marker',
        body: 'This example was added during human review.',
        source: 'human_review',
      });

      const ai = fakeAi((req) =>
        isClassifyRequest(req)
          ? classifyJson({ slug: 'order-status', confidence: 0.9 })
          : draftJson({ body: 'C'.repeat(120) }),
      );
      setAiProviderOverride(ai);

      await processEmail(store, ORDER_EMAIL);

      const prompt = ai.calls.find((c) => isClassifyRequest(c)).prompt;
      // Only three examples per type reach the prompt, and the human correction
      // must be one of them — otherwise the system would not act on what it learned.
      assert.ok(prompt.includes('TAUGHT-BY-HUMAN marker'));
    });

    it('sends the fed output draft to the AI so replies stay on-message', async () => {
      const ai = fakeAi((req) =>
        isClassifyRequest(req)
          ? classifyJson({ slug: 'returns-refunds', confidence: 0.95 })
          : draftJson({ body: 'D'.repeat(120) }),
      );
      setAiProviderOverride(ai);

      await processEmail(store, RETURN_EMAIL);

      const draftPrompt = ai.calls.find((c) => !isClassifyRequest(c)).prompt;
      assert.ok(draftPrompt.includes('APPROVED REPLY TEMPLATE'));
      assert.ok(draftPrompt.includes('prepaid return label'), 'the actual template text');
      assert.ok(draftPrompt.includes('80145'), 'the extracted order number');
      assert.ok(draftPrompt.includes('KNOWN VALUES EXTRACTED'));
    });

    // ------------------------------------------------------- edge cases

    it('flags an email with no readable content', async () => {
      const result = await processEmail(store, { fromEmail: 'x@example.com', subject: '', body: '   ' });
      assert.equal(result.flagged, true);
      assert.match(result.review.reason, /no readable text/i);
    });

    it('flags everything when no types exist yet', async () => {
      await store.reset();
      const result = await processEmail(store, ORDER_EMAIL);
      assert.equal(result.flagged, true);
      assert.match(result.review.reason, /No email types exist yet/i);
    });

    it('reports unresolved placeholders instead of inventing values', async () => {
      // The complaint template deliberately contains {{expected_resolution_date}},
      // which nothing can fill automatically — a human must decide it.
      const result = await processEmail(store, demo('I want a manager'));

      assert.equal(result.type.slug, 'complaint-escalation');
      assert.deepEqual(result.draft.unresolvedPlaceholders, ['expected_resolution_date']);
      assert.ok(result.draft.body.includes('{{expected_resolution_date}}'));
    });

    it('explains itself when auto-send is on but SMTP is not configured', async () => {
      await store.saveSettings({ autoSendEnabled: true });
      const result = await processEmail(store, ORDER_EMAIL);

      // A silent no-op here would look exactly like a delivered reply.
      assert.ok(result.autoSend, 'the outcome must be reported, not skipped');
      assert.equal(result.autoSend.attempted, false);
      assert.match(result.autoSend.error, /SMTP is not configured/i);
      assert.equal(result.draft.status, 'draft');
    });

    it('refuses to auto-send a draft that still has placeholders', async () => {
      await store.saveSettings({ autoSendEnabled: true });

      // Make SMTP look configured so the placeholder guard is what stops the send.
      // No connection is ever opened, because the guard returns first.
      const saved = { ...process.env };
      process.env.SMTP_HOST = 'smtp.invalid.test';
      process.env.SMTP_USER = 'user@invalid.test';
      process.env.SMTP_PASSWORD = 'not-a-real-password';

      try {
        const result = await processEmail(store, demo('I want a manager'));

        assert.equal(result.autoSend.attempted, false);
        assert.match(result.autoSend.error, /unfilled placeholders/);
        assert.match(result.autoSend.error, /expected_resolution_date/);
        assert.equal(result.draft.status, 'draft', 'nothing is marked sent');
      } finally {
        process.env = saved;
      }
    });

    it('keeps history rather than overwriting it on reprocess', async () => {
      const result = await processEmail(store, ORDER_EMAIL);
      await reprocessEmail(store, result.email.id);

      // A fresh classification and draft are appended; the originals remain.
      const latest = await store.getClassificationForEmail(result.email.id);
      assert.notEqual(latest.id, result.classification.id);
      assert.equal(latest.typeId, result.type.id);
    });
  });
}
