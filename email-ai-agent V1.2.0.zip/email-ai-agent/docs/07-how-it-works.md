# 7. How it works inside

For understanding the code, and for answering questions about the design.

---

## The shape of the whole thing

One Next.js application serves both the website and the API. That is why hosting is
a single deployment with nothing to wire together.

```
   Browser
      │   fetch()
      ▼
  ┌──────────────────────────────────────────────────┐
  │  src/app/api/**        the API                   │
  │  src/app/**/page.tsx   the pages                 │
  └──────────────────────────────────────────────────┘
      │
      ▼
  ┌──────────────────────────────────────────────────┐
  │  src/lib/pipeline.ts                             │
  │  The one place the whole flow lives              │
  └──────────────────────────────────────────────────┘
      │              │              │            │
      ▼              ▼              ▼            ▼
  classify/       draft/          mail/         db/
  which type?     what to say?    IMAP/SMTP     Postgres
                                                or a file
```

Everything that decides anything lives under `src/lib/`, and none of it imports
Next.js. That is deliberate: it means the unit tests import the real classifier and
the real pipeline directly, with no HTTP and no framework, which is why the test
suite is fast and specific.

Every route — pasting an email, uploading a file, fetching from a mailbox,
reprocessing — funnels into the same `pipeline.ts` functions. There is no second
code path that could behave differently.

---

## Deciding which type an email is

Two independent systems run on every email.

### The offline matcher (`classify/heuristic.ts`)

No network, no API key, pure functions. It always runs, for three reasons: it is
the fallback when the AI is unavailable, it supplies the numbers shown in the "why
this decision" panel, and it acts as a second opinion on the AI's answer.

It produces three signals per type:

**1. Nearest neighbour** — how similar is this email to the single closest example
of that type? Text is tokenised (lowercased, stopwords dropped, crudely stemmed),
turned into TF-IDF vectors, and compared by cosine similarity.

Two details in the tokeniser that matter more than they look:

- **Anything containing a digit collapses to one token, `#num`.** The exact order
  number "ORD-88213" is unique to one email and would never match anything. But
  "this email contains a reference number" is a genuinely useful signal that
  generalises across order and invoice enquiries.
- **Email pleasantries are treated as stopwords** — "dear", "regards", "kindly",
  "thanks", "please", "customer", "support". They appear in every category, so
  leaving them in makes everything look similar to everything.

**2. Centroid** — similarity to all of that type's material combined: description,
keywords and every example. This lets a type score sensibly when it has a good
description but no examples yet.

**3. Keywords** — how many of that type's curated phrases appear. Multi-word
phrases count double, because "where is my order" is far more telling than "order".
The count saturates, so a type with twenty keywords is not punished for having
eighteen misses.

These combine as `0.45 × nearest + 0.20 × centroid + 0.35 × keywords`.

### Why keyword evidence gets damped

The one piece of this worth explaining properly, because it was a real bug found by
testing rather than a design idea.

A supplier's wholesale pitch containing the phrase "trial shipment" and a "shipping
address" scored **0.27** for Order Status & Delivery — high enough to be wrongly
classified — purely on keyword hits. Its actual similarity to every order-status
example was about 0.05, correctly saying "this is nothing like those emails".

That disagreement is itself the signal. So keyword evidence is now scaled by how
much the similarity signals corroborate it:

```
corroboration = clamp((nearest + centroid) / 0.30, 0.35, 1.0)
```

An email that genuinely resembles the type keeps its keywords at full strength. An
email that trips a keyword while resembling nothing keeps only 35% of it. The
pitch dropped from 0.27 to **0.119**, and the gap between mail the system knows and
mail it does not widened from 0.153 to 0.376.

There is also a floor: an email that neither resembles any example nor trips a
single keyword has its score cut to a quarter, so near-misses do not accumulate
into a false match.

### The AI classifier (`classify/classifier.ts`)

When a key is configured, the model is sent a catalogue of your types — each with
name, description, keywords and up to three examples — then the new email, and asked
for JSON.

The prompt is unusually insistent on one point:

> The most important rule: if the email does not clearly belong to one of the
> listed categories, you MUST return null for "slug". Returning null is a correct
> and valuable answer, not a failure... A wrong category causes a wrong automated
> reply to be drafted to a real customer. Returning null simply routes the email to
> a person, which is always safe.

Models left to themselves will always pick the closest option. The whole value of
the review loop depends on them being willing to say "none of these", so the prompt
pushes hard on that.

Examples added by your team during review are sent **first**, ahead of the
originals, so when the per-type cap of three bites, the corrections survive.

### Combining them

| Situation | What happens |
|---|---|
| Model names a type, confidence ≥ threshold | Classified. Marked "AI, matcher agreed" if the matcher ranked it first too. |
| Model returns `null` | **Flagged.** |
| Model's confidence below threshold | **Flagged**, with the near-miss recorded. |
| Model names a type that does not exist | **Flagged.** Never trusted. |
| Model call fails, times out, or returns unparseable output | Offline matcher decides, and the failure is **reported to the user**, not hidden. |
| No AI key at all | Offline matcher decides. |
| Matcher's top score below its threshold | **Flagged.** |
| Matcher's top two within the margin | **Flagged** as genuinely ambiguous. |

There are two confidence thresholds because the two numbers are not on the same
scale — a model says 0.9 for an obvious match, the matcher says around 0.5 for the
same email. One shared threshold would necessarily be wrong for one of them.

---

## Writing the reply

`draft/templates.ts` extracts what it can from the email — names, order numbers,
invoice numbers, tracking numbers — and substitutes it into the type's template.

Reference-number extraction is deliberately conservative: a number is only taken
when it appears near a label like "order" or "invoice", or when it has an
unambiguous form like `ORD-40192`. A wrong order number in a reply is worse than no
order number, because the customer will act on it. "Our minimum is 5000 units" does
not yield an order number.

**Anything that cannot be filled is left visible.** The `{{placeholder}}` stays in
the text, is highlighted in the UI, and blocks sending. This runs through the whole
design: the system would rather show an obvious gap than invent a delivery date.

`draft/drafter.ts` then, if a model is available, sends it the template, the
pre-filled version, any extra example replies, the guidance for that type, and the
customer's email — and asks it to adapt the template to what this person actually
asked. Its rules, in order: never invent a fact; keep any placeholder you cannot
fill; follow the template's structure and tone; answer everything they asked.

If the model returns something suspiciously short, the filled template is used
instead, because a good generic answer beats a two-line non-answer.

---

## The learning loop

This is the part the brief is really about, so it is worth being precise.

When an email is flagged:

1. Its status becomes `flagged`
2. A review item is created, recording why and the closest guesses
3. A readable file is generated (`flagfile.ts`) describing the email, the reason,
   the scores, and what the reader should do
4. That file is emailed to the review team address, attached
5. **No reply is drafted.** There is nothing to draft from.

When a human resolves it, one of two things happens — and in both cases the email
is stored as a new example for the type, tagged `human_review`:

**"It is an existing type"** → the email becomes another input draft for that type.

**"It is a new kind of email"** → a new type is created from the name, description,
keywords and reply template the human supplies, and this email becomes its first
example.

Then a reply is drafted from that type's template, the email is marked `resolved`,
and the review item records who decided and when.

The tagging matters twice over: those examples are counted separately on the
dashboard, and they are the ones sent first in the AI prompt.

`reprocessEmail()` exists for the other half of this. An email flagged yesterday may
classify cleanly today, once something has been learned. Reprocessing re-runs the
decision, and if it now matches, closes the outstanding review request
automatically.

**This is tested end to end, twice.** `tests/pipeline.test.mjs` flags a supplier
pitch, confirms a *differently worded* second pitch is also unrecognised, teaches
the system from the first, and then asserts the second is classified automatically
— with the AI switched off, so only the stored example can possibly be doing the
work. `scripts/test-flow.mjs` does the same over real HTTP.

---

## Storage

One interface, `Store` (`db/store.ts`), with two implementations:

- **`postgres.ts`** — used whenever `DATABASE_URL` is set. What production runs.
- **`filestore.ts`** — a JSON file, so the project runs locally with zero setup.

Both are exercised by the *same* test suite (`tests/store.test.mjs`), so they
cannot quietly drift apart. That includes matching each other on the awkward
details: unique constraints, cascading deletes, ordering, and partial updates that
must not clobber untouched fields.

Two robustness measures came out of testing rather than planning:

**Schema self-repair.** `init()` memoises its success, so a process whose tables
later disappeared — easy to do from a database console, and what happens on a fresh
branch — would fail every request for the rest of its life. Now a Postgres
`undefined_table` error (code 42P01) triggers one schema recreation and a retry.

**Read-only filesystem fallback.** Serverless hosts mount the deployment
read-only, so an app deployed without a `DATABASE_URL` could not create `.data/`
and would fail every request with an unhelpful `EROFS`. It now falls back to the
temporary directory, warns loudly in the logs, and surfaces the warning on the
dashboard, so the person sees a working app telling them what to fix.

---

## Safety and correctness decisions

Collected here because they are the questions most worth being able to answer.

| Decision | Why |
|---|---|
| Replies are never sent without approval by default | An automated reply in your company's name, based on a classification that might be wrong, is the main risk this system carries. |
| Unfillable placeholders block sending | A made-up delivery date to an angry customer is the worst possible output. |
| Auto-send still refuses drafts with gaps | Whatever the setting says. |
| A message is marked read only *after* it is handled | Marking on fetch loses email whenever anything fails. |
| Deduplication by Message-ID | Overlapping fetches must not double-reply to a customer. |
| Email headers are stripped of CR/LF before sending | Otherwise a crafted subject could inject extra headers, including a `Bcc`. |
| Recipient addresses are validated before sending | Rather than handing anything to the mail server. |
| An unknown category from the model is never trusted | It is treated as "no match" and flagged. |
| AI failures are reported, never swallowed | The user is told the matcher decided instead. |
| The session cookie holds a digest, never the password | And is compared in constant time. |
| Every error message says what to do next | Rather than just reporting a status code. |

---

## Where things live

| Question | File |
|---|---|
| How is a type decided? | `src/lib/classify/classifier.ts` |
| How does the offline matcher score? | `src/lib/classify/heuristic.ts` |
| What counts as a word? | `src/lib/classify/text.ts` |
| How is a reply written? | `src/lib/draft/drafter.ts` |
| How are placeholders filled? | `src/lib/draft/templates.ts` |
| What is the whole flow? | `src/lib/pipeline.ts` |
| What does the flag file say? | `src/lib/flagfile.ts` |
| What are the demo types? | `src/lib/seed.ts` |
| What are the database tables? | `src/lib/db/schema.ts` |
| How is the AI called? | `src/lib/ai/gemini.ts` and siblings |
| How is mail read and sent? | `src/lib/mail/imap.ts`, `smtp.ts`, `parse.ts` |
| How does the password gate work? | `src/middleware.ts` |

---

## One gotcha worth knowing if you change the code

`src/middleware.ts` reads `process.env.APP_PASSWORD` as a literal property access
rather than going through `src/lib/config.ts` like everything else. This is not
inconsistency.

Middleware runs on the Edge runtime, where the bundler inlines only statically
analysable references. `config.ts` reads `process.env[name]` with a dynamic
variable name, which returns `undefined` there. Routing the password check through
it silently disabled the entire password gate while appearing to work — the worst
possible failure mode for an access check. It is spelled out literally in the
middleware, with a comment explaining why.

Everything else in the app runs on the Node runtime, where dynamic access is fine.

---

**Next:** [When something breaks](08-troubleshooting.md)
