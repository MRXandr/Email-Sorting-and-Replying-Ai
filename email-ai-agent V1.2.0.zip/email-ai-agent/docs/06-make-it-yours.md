# 6. Make it your own

The demo company, "Northwind Retail", exists only to show you the shape of the
thing. Replacing it with your own categories is done entirely in the browser — you
do not edit any code.

---

## The two things every type needs

| | Called | What it is | Why it matters |
|---|---|---|---|
| **Input drafts** | "Example incoming emails" in the UI | Real examples of emails of this kind | This is how the system *recognises* the type |
| **Output draft** | "Reply template" in the UI | The approved wording to answer with | This is what the system *says* |

Everything else — description, keywords, guidance — sharpens those two.

---

## Setting up your own types

1. **Settings** → set your company name and email signature. These fill
   `{{company_name}}` and `{{signature}}` in every template.
2. **Email types** → delete the five demo types, or keep them as reference while
   you build yours.
3. **Add a type**, and fill in the three sections.

### Writing a good description

This is the single most valuable field, because it is the main thing the AI reads.
Write it as you would explain the category to a new colleague on their first day.

Vague, and it will misfire:

> Questions about orders.

Specific, including what is *excluded*:

> A customer who has already placed an order wants to know where it is: has it
> shipped, when will it arrive, why is it late, the tracking is not updating, or a
> delivery was missed. The order already exists and payment has gone through. Not
> for people asking about a product before buying.

That last sentence does real work. Categories get confused with each other at
their boundaries, and naming the boundary is how you fix it.

### Writing good keywords

These drive the offline matcher, which is what keeps things working when no AI key
is set or the model is unreachable. Two rules:

**Phrases beat single words.** "where is my order" is a far stronger signal than
"order", which appears in nearly every email a shop receives. Phrases are weighted
double.

**Use the words customers actually type**, not the words your business uses
internally. People write "hasn't come yet", not "delivery exception".

A caution about short words: anything under five letters must match a whole word,
so `vat` will not fire on "Vatican". Longer keywords match as prefixes, so `refund`
catches "refunded" and "refunds" for free.

### Adding example emails

Two or three real ones make a noticeable difference. If you have real mail, paste
it in — with names and order numbers changed if you like, since the system
normalises numbers anyway.

Do not worry about getting this complete. The whole point of the review loop is
that examples accumulate by themselves: every time someone resolves a flagged
email as this type, it becomes another example, tagged "learned from a person" so
you can see which ones came from your team.

### Writing the reply template

Write the email you would want a good colleague to send. Then replace the specifics
with placeholders.

These get filled in automatically:

| Placeholder | Becomes |
|---|---|
| `{{customer_first_name}}` | `Kavya` |
| `{{customer_name}}` | `Kavya Reddy` |
| `{{customer_email}}` | `kavya@example.com` |
| `{{subject}}` | the original subject, with any `Re:` stripped |
| `{{order_id}}` | `92771`, if an order number appears in the email |
| `{{invoice_id}}` | an invoice number, if one appears |
| `{{tracking_id}}` | a tracking or AWB number, if one appears |
| `{{company_name}}` | from Settings |
| `{{signature}}` | from Settings |
| `{{today}}` | `2026-09-26` |

The name is worked out from the From header, falling back to the email address —
`priya.sharma@x.com` becomes "Priya Sharma". Reference numbers are only picked up
when they appear near a label like "order" or "invoice", so a phone number or a
quantity is not mistaken for one.

### Placeholders you invent on purpose

You can write any placeholder you like, such as `{{expected_resolution_date}}`.
The system will **not** guess at it. Instead it leaves the placeholder visible,
highlighted in the draft, and blocks sending until a person fills it in.

Use this deliberately, for anything that needs a human decision:

```
You will receive a substantive update from them by {{expected_resolution_date}}.
```

This is better than having the AI invent a date. A made-up promise to an already
angry customer is the worst thing this system could do, so it is built not to.

---

## Checking your types are actually distinguishable

After setting up your own types, run:

```bash
npm run calibrate
```

This does something genuinely useful: it takes each of your example emails, removes
it from the training data, and checks it still lands on the right type. Scoring an
example against itself proves nothing, so it is held out.

```
══ HELD-OUT TEST: each input draft scored with that draft removed ══

PASS  order-status      → order-status      0.512  margin 0.301   "Where is my order 88213?"
PASS  returns-refunds   → returns-refunds   0.549  margin 0.402   "Need to return these shoes"
...

══ SEPARATION SUMMARY ══

known emails   top score range: 0.503 … 0.561
unknown emails top score range: 0.084 … 0.127
gap between them: 0.376  (good — a threshold sits cleanly between)
```

**What to look for:**

- **`FAIL` lines.** Two of your types are too similar, or one has too few
  examples. Either sharpen their descriptions and keywords, or merge them.
- **A narrow gap.** If known and unknown mail score similarly, the system cannot
  reliably tell "I know this" from "I don't". Usually means keywords are too
  generic.
- **Low margins.** A winner barely ahead of the runner-up means those two types
  overlap.

Re-run it whenever you change types. It takes a second.

---

## Tuning how cautious it is

**Settings → How careful the agent should be** has three sliders. The defaults are
measured, not guessed, so change them only in response to a real problem.

| Slider | Raise it when | Lower it when |
|---|---|---|
| **AI confidence needed** | Confidently wrong classifications | Too much obvious mail going to review |
| **Offline matcher score needed** | Same, but with no AI key set | Same |
| **How far ahead the winner must be** | Mistakes between two similar types | Genuinely clear mail being called ambiguous |

There are two confidence thresholds rather than one because the two numbers are
not comparable. A model reports 0.9 for an obvious match; the offline matcher's
score for the same email is nearer 0.5. Sharing one threshold would make one of
them wrong.

The third slider is about ambiguity rather than confidence. If the top two types
score within that distance of each other, the email goes to a person regardless of
how high the scores are — because "it is definitely one of these two" is not an
answer you can send a reply from.

**Which way to err:** flagging too much wastes a little of your team's time.
Classifying too eagerly sends wrong replies to real customers. Prefer over-flagging.

---

## Adding more types later

You do not have to plan every category up front, and you should not try. The
intended way to grow the system is:

1. Start with the categories you are sure about
2. Let unfamiliar mail get flagged
3. When a pattern appears in the review queue, create a type for it **from the
   review screen** — the email that prompted it becomes its first example

This way your categories reflect the mail you actually receive rather than the mail
you predicted, and each new type starts with a real example.

---

## Replacing the demo data in code

If you would rather ship your own types as the built-in default — handy if you will
redeploy from scratch, or for a fresh copy of the project — edit
`src/lib/seed.ts`. The structure is straightforward:

```ts
{
  name: 'Order Status & Delivery',
  slug: 'order-status',
  description: '...',
  keywords: ['order status', 'where is my order', ...],
  replyGuidance: '...',
  replySubject: 'Re: {{subject}}',
  replyBody: `Hi {{customer_first_name}}, ...`,
  samples: [
    { subject: 'Where is my order 88213?', body: '...' },
    ...
  ],
}
```

The same file holds `SEED_INBOX`, the demo emails on the Inbox page. Set
`expectFlag: true` on any that should not match a type — the test suite uses that
flag to check the flagging path still works.

After editing, run `npm run calibrate` to check your types separate cleanly, then
`npm test`. Both test suites read this file, so they will tell you if a change
broke something.

---

**Next:** [How it works inside](07-how-it-works.md)
