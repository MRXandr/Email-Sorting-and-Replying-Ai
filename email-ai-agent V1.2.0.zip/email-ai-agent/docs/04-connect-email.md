# 4. Connect a real mailbox

**Time needed:** about ten minutes
**Cost:** nothing

This is optional. Everything works by pasting or uploading emails. Connect a
mailbox when you want the system to read real incoming mail and send real replies.

---

## Strong advice: use a throwaway account

**Do not connect your personal Gmail.** Make a new free Google account for this —
`yourname.emailagent@gmail.com` or similar.

Two reasons. You will be creating an App Password, which grants full mailbox
access, and you will be running code that marks messages as read and can send mail
as you. A test account means a mistake costs you nothing. It also makes the demo
cleaner, because the inbox contains only what you put there.

---

## What the two halves do

| | Protocol | What it gives you |
|---|---|---|
| **Reading** | IMAP | The **Fetch new mail** button pulls unread messages in and runs them through the agent. |
| **Sending** | SMTP | Alert emails to your team when something cannot be classified, and approved replies to customers. |

They are independent. You can set up either on its own. Sending is the more
useful of the two, because it is what makes the "flag it and forward it to a human
team" part of the system real.

---

## Step 1 — Turn on 2-Step Verification

Google will not let you create an App Password without it.

1. Go to **<https://myaccount.google.com/security>**
2. Find **2-Step Verification** and turn it on
3. Follow the prompts (usually your phone number)

---

## Step 2 — Create an App Password

An App Password is a 16-character password that works for one application. Your
normal Google password will be rejected — Google blocked that for mail clients
years ago, and it is the single most common reason people get stuck here.

1. Go to **<https://myaccount.google.com/apppasswords>**
2. If it says the option is unavailable, 2-Step Verification is not fully on yet —
   go back to step 1
3. Type a name, such as `Email Agent`
4. Click **Create**
5. Copy the 16 characters shown, for example `abcd efgh ijkl mnop`

**Remove the spaces.** `abcd efgh ijkl mnop` becomes `abcdefghijklmnop`.

Google shows it once. If you lose it, delete it and make another.

---

## Step 3 — Turn IMAP on in Gmail

1. Open Gmail
2. Click the gear icon, then **See all settings**
3. Go to the **Forwarding and POP/IMAP** tab
4. Under **IMAP access**, choose **Enable IMAP**
5. Click **Save Changes** at the bottom

---

## Step 4 — Fill in your settings file

Open `.env.local` and fill in both blocks. Using the same account for both is
fine.

```bash
# Reading mail
IMAP_HOST=imap.gmail.com
IMAP_PORT=993
IMAP_SECURE=true
IMAP_USER=yourname.emailagent@gmail.com
IMAP_PASSWORD=abcdefghijklmnop
IMAP_MAILBOX=INBOX
IMAP_BATCH_SIZE=5

# Sending mail
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_SECURE=false
SMTP_USER=yourname.emailagent@gmail.com
SMTP_PASSWORD=abcdefghijklmnop
SMTP_FROM=yourname.emailagent@gmail.com

# Where flagged emails get reported — use an address you can check
REVIEW_TEAM_EMAIL=your.real.email@gmail.com
```

> **The port and TLS setting must agree.** Port 587 needs
> `SMTP_SECURE=false` (it upgrades to encryption after connecting, which is
> called STARTTLS). Port 465 needs `SMTP_SECURE=true`. Mismatching them produces
> a connection timeout that looks like a network problem but is not.

Save, then restart the app (`Ctrl+C`, then `npm run dev`).

---

## Other providers

| Provider | IMAP host | SMTP host | SMTP port | `SMTP_SECURE` |
|---|---|---|---|---|
| Gmail | `imap.gmail.com` | `smtp.gmail.com` | 587 | `false` |
| Outlook / Hotmail | `outlook.office365.com` | `smtp.office365.com` | 587 | `false` |
| Yahoo | `imap.mail.yahoo.com` | `smtp.mail.yahoo.com` | 465 | `true` |
| Zoho | `imap.zoho.com` | `smtp.zoho.com` | 587 | `false` |
| iCloud | `imap.mail.me.com` | `smtp.mail.me.com` | 587 | `false` |

All of these need an app-specific password rather than your normal one. Outlook
accounts on a work or school tenant often have IMAP disabled by an administrator,
in which case use a personal account instead.

---

## Step 5 — Test the connection before trying to use it

Open the **Mailbox** page and click **Test the connection**.

You get two panels, one for reading and one for sending, each with a green or red
light and — if red — the actual reason. This is the right first move whenever mail
is not working, because it separates "wrong password" from "wrong port" from "not
configured at all".

A green light on both means you are done. If not, the message tells you which of
those three it is; there is a full list in
[When something breaks](08-troubleshooting.md#email-problems).

---

## Step 6 — Fetch some real email

1. Send two or three emails **to** your agent account from another address. Make
   one an obvious customer query ("where is my order 12345?") and one something
   unrelated — a supplier pitch, or a newsletter.
2. On the Mailbox page, click **Fetch new mail**.

You will see each message, what it was sorted as, and which ones were flagged.
Then check the Inbox page for the drafted replies, and the Review page for
anything flagged.

If you set `REVIEW_TEAM_EMAIL`, check that inbox too — there should be an alert
email with the flagged email attached as a text file.

---

## How reading works, and why

A few decisions worth knowing about, because they are what stops this losing your
mail.

**Only unread messages are fetched.** The system asks the server for unread
messages, so already-handled mail is not reprocessed.

**A message is marked read only after it has been handled.** Not before. If the
AI call fails or the app crashes halfway, the message stays unread and is picked
up on the next fetch. The alternative — marking messages read as they are fetched
— silently loses email whenever anything goes wrong.

**Five messages per click by default.** Each message costs two model calls, and a
serverless request has a time limit (60 seconds on Vercel's free plan). A hundred
unread messages in one request would be cut off partway. So it works in batches
and tells you there is more waiting. Click again to continue, or raise
`IMAP_BATCH_SIZE` if your mail is short and your model is fast.

**Newest first**, because if you have a backlog, the recent mail matters more.

**The same message is never processed twice.** Every email carries a Message-ID,
and the system records it. Even if a message is marked unread again on the
server, it is recognised and skipped.

---

## Sending replies

Nothing is ever sent without you approving it, unless you deliberately change
that.

1. Open a classified email from the Inbox
2. Read the drafted reply
3. Edit it if you want — click **Edit**, make changes, **Save**
4. Click **Send reply**

The reply is threaded onto the original message using its Message-ID, so it
appears in the same conversation in the customer's mail client rather than as a
disconnected new email.

### Replies with gaps in them

Some templates deliberately ask for something the system cannot know. The demo's
complaint template contains `{{expected_resolution_date}}` — a promise about when
someone will get back to the customer, which only a person can make.

When that happens the placeholder is **left visible and highlighted**, and
**sending is blocked**. Fill it in and the block lifts. There is an override
("Send without filling the gaps") which requires a second click, for the rare case
where you really mean it.

This is a deliberate design choice: a made-up delivery date sent to an angry
customer is worse than an obvious gap that a human notices.

### Automatic sending

**Settings → Sending replies** has a switch to send every matched email's reply
automatically, with nobody checking.

It is off by default and worth leaving off. With it on, real emails go to real
people in your company's name, based on a classification that might be wrong. If
you do turn it on, note that a draft with unfilled placeholders is *still* never
sent automatically, whatever the setting says.

---

## If you cannot connect a mailbox

Plenty of people cannot — a locked-down work account, a provider that has disabled
IMAP, or just not wanting to. Nothing is lost:

- **Paste emails** into the Inbox page, either as fields or as a whole raw email
  including headers
- **Upload `.eml` files.** In Gmail, open a message, click the ⋮ menu and choose
  **Download message** to get one. You can upload several at once.
- **Use the demo emails** built into the Inbox page

All three run through exactly the same pipeline as a real fetch, so a demo built
this way is a fair demonstration of the system.

---

**Next:** [Put it on the internet](05-deploy-to-vercel.md)
