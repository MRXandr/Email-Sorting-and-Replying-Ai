# 2. Add the AI

**Time needed:** about three minutes
**Cost:** nothing. Google's free tier is generous and needs no card.

---

## Why bother, when it already works?

Without an AI key the app uses a built-in **offline matcher**. It compares the
words in a new email against the example emails you have stored, and checks for
telltale phrases. It is genuinely decent — the demo you ran in guide 1 used it —
but it only understands vocabulary, not meaning.

With a model connected:

| | Offline matcher | With an AI model |
|---|---|---|
| "Where is my order 123?" | Correct | Correct |
| "still nothing after 3 weeks?!" | Might flag it for a human | Understands it is a delivery chase |
| Supplier pitch mentioning "shipment" | Correctly rejected | Correctly rejected |
| The drafted reply | The template with names and numbers filled in | The template rewritten to answer what this customer actually asked, including any extra questions |
| Someone asking three things at once | Answers with the generic template | Addresses all three |

The biggest practical gain is in the replies. The offline version sends a good
generic answer; the AI version sounds like somebody read the email.

---

## Step 1 — Get a free Gemini key

1. Go to **<https://aistudio.google.com/apikey>**
2. Sign in with a Google account
3. Click **Create API key**
4. Pick any project when asked (or let it create one)
5. Copy the key — it is a long string starting with `AIza...`

You will not be asked for payment details. The free tier allows plenty for this
project; you would have to process thousands of emails to reach it.

> **Treat the key like a password.** Anyone who has it can spend your quota.
> Never put it in a screenshot, a GitHub commit, or a message to anyone.

---

## Step 2 — Put the key in a file

In your project folder, make a copy of the example settings file:

**macOS / Linux:**
```bash
cp .env.example .env.local
```

**Windows PowerShell:**
```powershell
Copy-Item .env.example .env.local
```

Open `.env.local` in any text editor (Notepad is fine) and find this line:

```
GEMINI_API_KEY=
```

Paste your key straight after the `=`, with no spaces and no quote marks:

```
GEMINI_API_KEY=AIzaSyC-your-actual-key-goes-here
```

Save the file.

> **Why `.env.local` and not `.env.example`?** The example file is a template
> that gets shared. `.env.local` is yours, and is already listed in `.gitignore`
> so it can never be committed to GitHub by accident.

---

## Step 3 — Restart

Settings are read once at startup, so the running app has not noticed yet.

In the terminal running the app, press **Ctrl+C**, then:

```bash
npm run dev
```

---

## Step 4 — Confirm it took

Open the Dashboard. The "How it is set up" panel should now show:

```
Model        ● gemini · gemini-2.0-flash
```

with a green dot. The top-right corner of every page shows `gemini` too.

If it still says "Offline matcher", see
[When something breaks](08-troubleshooting.md#the-ai-key-isnt-being-picked-up).

---

## Step 5 — See the difference

Go to the Inbox and paste in an email that asks several things at once, which is
where the offline matcher is weakest:

> **From:** `Sarah Chen <s.chen@example.com>`
> **Subject:** `order 44219 — three questions`
> **Message:**
> ```
> Hi,
>
> Order 44219 was due Tuesday and hasn't arrived. Three things:
>
> 1. Where actually is it?
> 2. If it's lost, can you reship rather than refund? I need it for an event.
> 3. Can you confirm in writing that I won't be charged twice if you reship?
>
> Sarah
> ```

The reply you get back should follow your approved template's structure and tone,
but address all three points — including the reshipping question, which no
template covers.

Open the email's detail page and look at the "Why it decided that" panel. It now
shows the model's own reasoning in plain English, alongside the offline matcher's
scores. When both agree, the badge reads **"AI, matcher agreed"**, which is a
useful signal of a safe classification.

---

## What happens when the AI fails

This matters, because free-tier APIs do occasionally rate-limit you, and networks
drop.

The app never loses your email. If a model call fails for any reason — no network,
a bad key, a rate limit, a malformed response — it falls back to the offline
matcher, does the job, and **tells you what happened** rather than hiding it. You
will see a note like:

> Note: the AI provider could not be reached (gemini: rate limit or quota
> reached...), so the offline matcher decided this one.

This is tested deliberately, including the cases where the model returns
nonsense, invents a category that does not exist, or reports low confidence. In
every case the email is either correctly handled or flagged for a person — never
answered on a bad guess.

---

## Using a different provider

The app supports three, and only ever uses one at a time. Just set the relevant
key in `.env.local`; it works out which to use.

| Provider | Key to set | Notes |
|---|---|---|
| Google Gemini | `GEMINI_API_KEY` | Free tier, no card. **Recommended.** |
| OpenAI | `OPENAI_API_KEY` | Needs a paid account with credit added. |
| Anthropic | `ANTHROPIC_API_KEY` | Needs a paid API account. |

To change model, set `GEMINI_MODEL`, `OPENAI_MODEL` or `ANTHROPIC_MODEL`.

To switch the AI off deliberately and go back to the offline matcher, set
`AI_PROVIDER=none`.

Anything that speaks the OpenAI API also works — a local Ollama, Groq, Together —
by setting `OPENAI_API_KEY` and `OPENAI_BASE_URL`.

---

## What the model is actually told

Worth knowing, both for your own understanding and because your professor may
ask. There are two separate calls per email.

**To classify**, the model receives a catalogue of your types — each with its
name, description, telltale phrases, and up to three of your example emails — then
the new email. It is told to reply with JSON naming one type, or `null`. The
instruction it is given is blunt about this:

> Returning null is a correct and valuable answer, not a failure... Never stretch
> a category to make an email fit. A wrong category causes a wrong automated reply
> to be drafted to a real customer.

Examples added by your team during review are sent **first**, ahead of the
originals, so corrections carry the most weight.

**To draft the reply**, it receives your approved template, the template with all
the values already substituted, any extra example replies, the guidance you wrote
for that type, and the customer's email. Its first rule is never to invent a fact
— no delivery dates, amounts, or order numbers that are not already in front of
it. If the template has a placeholder it cannot fill, it must leave the
`{{placeholder}}` exactly as it is so a person can complete it.

You can read both prompts in full in `src/lib/classify/classifier.ts` and
`src/lib/draft/drafter.ts`. They are written out as plain text, not assembled
from fragments, so they are easy to read and adjust.

---

**Next:** [Add a database](03-database.md)
