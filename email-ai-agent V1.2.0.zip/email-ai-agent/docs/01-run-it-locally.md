# 1. Run it on your computer

**Time needed:** about five minutes
**You need:** nothing except Node.js. No API key, no database, no accounts.

---

## Step 1 — Check you have Node.js

Open a terminal and run:

```bash
node --version
```

You want **v20 or higher** — something like `v20.11.0` or `v22.14.0`.

If the command is not found, or the number is lower than 20, install the **LTS**
version from [nodejs.org](https://nodejs.org), close your terminal, open a new
one, and check again.

> **Which terminal?**
> - **Windows:** press Start, type `powershell`, open Windows PowerShell.
> - **macOS:** press Cmd+Space, type `terminal`, press Enter.
> - **Linux:** whatever you normally use.

---

## Step 2 — Go to the project folder

Unzip the project somewhere you will remember, then in your terminal:

```bash
cd path/to/email-ai-agent
```

A shortcut if typing paths is fiddly: type `cd ` (with the space), then drag the
folder from your file manager onto the terminal window and press Enter.

Check you are in the right place:

```bash
ls        # macOS / Linux
dir       # Windows
```

You should see `package.json`, `src`, `docs` and `scripts` listed.

---

## Step 3 — Install the dependencies

```bash
npm install
```

This downloads the libraries the project uses into a `node_modules` folder. It
takes a minute or two the first time and prints a lot of text. That is normal.

You are fine as long as the last lines look roughly like:

```
added 170 packages, and audited 171 packages in 11s
found 0 vulnerabilities
```

If it fails, see [When something breaks](08-troubleshooting.md#npm-install-fails).

---

## Step 4 — Start it

```bash
npm run dev
```

You should see:

```
  ▲ Next.js 15.5.26
  - Local:        http://localhost:3000

 ✓ Ready in 1.2s
```

Leave this terminal window open. The app runs for as long as it stays open.
Pressing `Ctrl+C` stops it.

---

## Step 5 — Open it

Go to **<http://localhost:3000>** in your browser.

You will see the Dashboard, with a warning that no email types are configured.
That is expected — the system does not know your categories yet.

---

## Step 6 — Load the demo company and watch it work

This is the part worth doing carefully, because it shows you the whole idea in
about thirty seconds.

**a) Click "1. Load the demo company".**

This sets up a fictional retailer with five kinds of email:

| Type | What belongs in it |
|---|---|
| Order Status & Delivery | "Where is my order, it hasn't arrived" |
| Returns & Refunds | "Wrong size, I want to send it back" |
| Product Information (Pre-Sales) | "Does it come in white? Not bought yet" |
| Billing & Payment Issue | "I've been charged twice" |
| Complaint & Service Escalation | "Fourth email, I want a manager" |

Each one comes with example incoming emails and an approved reply template.

**b) Click "2. Run the seven demo emails".**

Seven emails go through the system. You should see:

> Processed 7 demo emails: 5 matched a known type and 2 were flagged for a person
> to look at.

**c) Open the Inbox page.**

Five emails are sorted, each with a drafted reply. Click any one to see:

- the original email
- what the system extracted from it (the customer's name, the order number)
- **a score for every single type**, so you can see exactly why it chose what it
  chose
- the drafted reply, ready to edit or send

**d) Open the Review page.**

Two emails are waiting: a supplier's wholesale pitch and a job application.
Neither is a customer enquiry, so the system refused to guess and asked for help
instead. This is the behaviour that matters most — it would rather ask than send
a wrong reply to a real customer.

**e) Click into the supplier pitch and teach the system.**

Choose **"It is a new kind of email"** and fill in:

- **Name:** `Supplier & Partnership Enquiry`
- **What belongs in it:** `A business contacting us to sell us something or
  propose a partnership: suppliers, manufacturers, wholesale offers, reseller
  proposals.`
- **Telltale words:** `wholesale, partnership, supplier, rate card, minimum order
  quantity`
- **Reply template:** leave the default and edit the middle line to something
  like `I have passed your details to our buying team, who review new supplier
  proposals monthly.`

Click **"Create the type and draft the reply"**.

**f) Now prove it learned.**

Go back to the Inbox, and paste in a *different* supplier pitch — different
company, different wording. For example:

> **From:** `Ravi Kulkarni <ravi@ecocartons.example>`
> **Subject:** `Supplier introduction — recycled carton manufacturer`
> **Message:**
> ```
> Dear Procurement,
>
> I represent EcoCartons, a manufacturer of recycled corrugated cartons based in
> Coimbatore. We supply three national retail chains and hold buffer stock for
> call-off orders. Our minimum order quantity is 3,000 units.
>
> I have attached our catalogue and rate card. Could your buying team spare
> twenty minutes next week to discuss wholesale terms?
>
> Ravi Kulkarni
> ```

It is sorted into **Supplier & Partnership Enquiry** automatically, with a reply
drafted from the template you just wrote. Nobody had to tell it about this one.

That is the learning loop, and it is the heart of the project.

---

## What you have at this point

Everything works, with two limitations:

1. **No AI model is connected.** Classification uses a built-in offline matcher,
   and replies are templates with the blanks filled in. It works well — that demo
   you just ran used it — but it handles unusual phrasing less gracefully, and
   replies are less tailored to what each customer actually asked.

2. **Data is stored in a local file** (`.data/store.json`). Fine on your own
   computer, but it will not survive being hosted online.

Both are fixed in the next two guides, and both are free.

---

## Useful commands

| Command | What it does |
|---|---|
| `npm run dev` | Start in development mode. Picks up code changes as you save. |
| `Ctrl+C` | Stop it. |
| `npm run build` then `npm start` | Run the production build, which is what hosting uses. Faster, but does not pick up code changes. |
| `npm run verify` | Run every test. Takes a couple of minutes. |
| `npm run stop` | Force-stop a server you have lost track of. |

---

## Starting over

To wipe everything and reload the demo, use **Settings → Reset and load demo
data**, or delete the `.data` folder and restart.

---

**Next:** [Add the AI (free)](02-add-the-ai.md)
