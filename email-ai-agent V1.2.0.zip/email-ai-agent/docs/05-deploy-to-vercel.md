# 5. Put it on the internet

**Time needed:** about fifteen minutes
**Cost:** nothing. Vercel's Hobby plan is free and does not expire.

At the end of this you will have a URL like
`https://email-agent-yourname.vercel.app` that you can send to anyone.

---

## Before you start

**You need a database first.** If you have not done [guide 3](03-database.md), do
it now. This is not optional and it is not a "nice to have later": without
`DATABASE_URL` the deployed app has nowhere to write anything and will refuse to
work, telling you so on the dashboard. It takes about five minutes and is free.

You also need:

- a **GitHub** account — <https://github.com/signup>
- a **Vercel** account — <https://vercel.com/signup>, and sign up *with GitHub*,
  which links them automatically

Why GitHub? Vercel deploys from a Git repository. Push a change, and the site
updates itself. This is also how your professor can see the code.

---

## Step 1 — Check nothing secret is about to be committed

The most important minute of this guide.

```bash
git status --short
```

If `.env.local` appears in that list, **stop**. It contains your API key and mail
password. It should be ignored already, but check:

```bash
cat .gitignore | grep env
```

You should see `.env.local` and `.env*.local` listed. If not, add them before
going any further.

Committing an API key to a public repository means it will be found and used by
someone else, usually within hours. Bots scan GitHub for exactly this.

---

## Step 2 — Put the project in Git

If you have not used Git before, these four commands are all you need:

```bash
git init
git add .
git commit -m "Email triage agent"
```

If Git complains it does not know who you are:

```bash
git config --global user.name "Your Name"
git config --global user.email "you@example.com"
```

Then commit again.

Check what went in:

```bash
git show --stat --oneline HEAD | head -20
```

`.env.local` must not be there. `.env.example` should be — that one is a safe
template with no real values.

---

## Step 3 — Create the GitHub repository

1. Go to **<https://github.com/new>**
2. **Repository name:** `email-triage-agent`
3. **Private** is the safer choice. Vercel can deploy from a private repo on the
   free plan, and you can still add your professor as a collaborator or make it
   public later.
4. **Do not** tick "Add a README" or add a .gitignore — you already have both
5. Click **Create repository**

GitHub then shows you commands. Use the "push an existing repository" ones:

```bash
git remote add origin https://github.com/YOUR-USERNAME/email-triage-agent.git
git branch -M main
git push -u origin main
```

If it asks for a password, GitHub no longer accepts your account password over
HTTPS. Either install the [GitHub CLI](https://cli.github.com) and run
`gh auth login`, or create a
[personal access token](https://github.com/settings/tokens) and paste that as the
password.

---

## Step 4 — Import it into Vercel

1. Go to **<https://vercel.com/new>**
2. Your GitHub repositories are listed. Find `email-triage-agent` and click
   **Import**. (If you do not see it, click **Adjust GitHub App Permissions** and
   grant access to the repo.)
3. Vercel detects Next.js and fills in the build settings correctly. **Leave them
   alone** — framework preset Next.js, build command `next build`, output
   directory `.next`.
4. **Do not click Deploy yet.** Add the environment variables first, otherwise the
   first deployment comes up without a database and you will be confused by the
   warnings.

---

## Step 5 — Add the environment variables

Expand the **Environment Variables** section on that same import screen.

Add each of these as a separate Name / Value pair. You are copying the same
values from your `.env.local`, one at a time.

**Required:**

| Name | Value |
|---|---|
| `DATABASE_URL` | Your Neon **pooled** connection string |

**Strongly recommended:**

| Name | Value |
|---|---|
| `GEMINI_API_KEY` | Your Gemini key |
| `APP_PASSWORD` | A password you choose, to stop strangers opening the site |
| `AUTH_SECRET` | A long random string — run `openssl rand -hex 32`, or just mash the keyboard for 40 characters |

**If you connected a mailbox:**

| Name | Value |
|---|---|
| `IMAP_HOST` | `imap.gmail.com` |
| `IMAP_PORT` | `993` |
| `IMAP_SECURE` | `true` |
| `IMAP_USER` | your agent address |
| `IMAP_PASSWORD` | the 16-character App Password, no spaces |
| `SMTP_HOST` | `smtp.gmail.com` |
| `SMTP_PORT` | `587` |
| `SMTP_SECURE` | `false` |
| `SMTP_USER` | your agent address |
| `SMTP_PASSWORD` | the same App Password |
| `SMTP_FROM` | your agent address |
| `REVIEW_TEAM_EMAIL` | where flagged-email alerts should go |

Watch for a trailing space when pasting — it is a common and very annoying cause
of "invalid API key".

---

## Step 6 — Deploy

Click **Deploy**.

It takes one to three minutes. You will see the build log; the useful parts look
like:

```
Running "npm install"
Running "npm run build"
   ▲ Next.js 15.5.26
   Creating an optimized production build ...
   ✓ Compiled successfully
Build Completed
```

Then a congratulations screen with a screenshot of your site.

If the build fails, see
[When something breaks](08-troubleshooting.md#the-vercel-build-fails).

---

## Step 7 — Check it works

Click **Visit**, or use the `.vercel.app` URL you were given.

First, visit `https://your-app.vercel.app/api/health` — this is public even with a
password set, and it is the quickest way to see what the server thinks:

```json
{
  "status": "ok",
  "database": { "ok": true, "kind": "postgres", "error": null },
  "ai": { "provider": "gemini", "model": "gemini-2.0-flash", "ready": true },
  "mailbox": { "imap": true, "smtp": true },
  "authEnabled": true
}
```

Everything you care about is in that one response. `"kind": "file"` means
`DATABASE_URL` did not come through. `"ready": false` means the AI key did not.

Then open the site itself, sign in with your `APP_PASSWORD`, and click **Load the
demo company** followed by **Run the seven demo emails**. If five sort and two
flag, the deployment is fully working.

---

## Step 8 — Protect it with a password

If you skipped `APP_PASSWORD` above, add it now — anyone with the URL can
otherwise read every email in the system.

1. In Vercel, go to your project → **Settings** → **Environment Variables**
2. Add `APP_PASSWORD` and `AUTH_SECRET`
3. Go to the **Deployments** tab, click the ⋯ menu on the most recent deployment,
   and choose **Redeploy**

**Environment variable changes only take effect on a new deployment.** Adding a
variable does nothing to the site already running. This catches almost everyone
once.

---

## Making changes after deploying

Edit code locally, then:

```bash
git add .
git commit -m "Describe what changed"
git push
```

Vercel notices the push and deploys automatically. You do not touch the dashboard.

---

## Things specific to hosting that are worth knowing

**Requests have a time limit.** Vercel's free plan allows up to 60 seconds. The
endpoints that need it are already configured for the maximum. If fetching mail
times out, lower `IMAP_BATCH_SIZE` to 3, or 2.

**The first request after a quiet period is slow.** Both Vercel and Neon suspend
idle resources. Expect a second or two extra on the first load. Nothing is broken,
and nothing is lost.

**Use the pooled database connection.** Explained in
[guide 3](03-database.md#step-2--copy-the-connection-string). With the direct
connection string, the app works at first and then starts failing once more than a
few instances are alive.

**Logs are in the dashboard.** Project → **Logs**, or the **Functions** tab on a
deployment. Every error the app reports is written there, which is where to look
when something behaves oddly in production but not locally.

---

## Other hosting options

Vercel is the smoothest path for a Next.js app, and it is what your professor
mentioned. But the project is a standard Next.js application with no Vercel-only
features, so it runs anywhere.

**Render** (<https://render.com>) — one always-on server rather than serverless.
Create a Web Service from your repo, build command `npm install && npm run build`,
start command `npm start`. Add the same environment variables. The free instance
sleeps after 15 minutes of inactivity and takes about 30 seconds to wake, which is
awkward for a live demo but otherwise fine. An advantage: no request time limit, so
you can raise `IMAP_BATCH_SIZE` freely.

**Railway** (<https://railway.app>) — similar to Render, with Postgres available
in the same project.

**Fly.io**, a VPS, or your own machine — all work. Build with `npm run build`, run
with `npm start`, set the same environment variables.

---

## Deployment checklist

- [ ] `.env.local` is **not** in the repository
- [ ] `DATABASE_URL` set, and it is the **pooled** string
- [ ] `GEMINI_API_KEY` set
- [ ] `APP_PASSWORD` and `AUTH_SECRET` set
- [ ] Redeployed after adding any variable
- [ ] `/api/health` shows `"kind": "postgres"` and `"ready": true`
- [ ] Demo data loads and the seven demo emails behave as expected
- [ ] If mail is connected: **Test the connection** on the Mailbox page is green
- [ ] `REVIEW_TEAM_EMAIL` points somewhere you actually check

---

**Next:** [Make it your own](06-make-it-yours.md)
