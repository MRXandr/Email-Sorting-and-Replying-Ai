# 8. When something breaks

Find your symptom below. If it is not here, `/api/health` is always the first
thing to check.

---

## Start here: the health check

Visit `http://localhost:3000/api/health` — or `https://your-app.vercel.app/api/health`,
which stays public even with a password set.

```json
{
  "status": "ok",
  "database": { "ok": true, "kind": "postgres", "error": null },
  "ai": { "provider": "gemini", "model": "gemini-2.0-flash", "ready": true },
  "mailbox": { "imap": true, "smtp": true },
  "authEnabled": true
}
```

| What you see | What it means |
|---|---|
| `"kind": "file"` when you expected Postgres | `DATABASE_URL` is not reaching the app |
| `"ready": false` | No AI key, or it is not reaching the app |
| `"database": { "ok": false }` | The `error` field says exactly why |
| `"imap": false` / `"smtp": false` | Those settings are incomplete |
| `"status": "degraded"` | The app is running but the database is not reachable |

---

## Setup problems

### `npm install` fails

**"Unsupported engine" or a Node version complaint** — you are on Node 18 or older.
Install Node 20+ from [nodejs.org](https://nodejs.org), open a *new* terminal, and
check `node --version`.

**`EACCES` permission errors** — do not reach for `sudo`. It usually means npm's
cache has root-owned files from an earlier `sudo npm`:

```bash
sudo chown -R $(whoami) ~/.npm
```

**Network or registry timeouts** — try `npm install --registry=https://registry.npmjs.org`.
Behind a corporate proxy you may need `npm config set proxy http://your-proxy:port`.

**Anything else, as a last resort:**

```bash
rm -rf node_modules package-lock.json
npm install
```

### `npm run dev` says the port is in use

Something else is on port 3000 — often a previous copy of this app that did not
shut down.

```bash
npm run stop        # stops any Next.js server from this project
```

Or use a different port: `PORT=3001 npm run dev`.

### The page loads but is unstyled

Tailwind did not compile. Stop the server, delete the build cache, restart:

```bash
rm -rf .next
npm run dev
```

---

## AI problems

### The AI key isn't being picked up

The dashboard still says "Offline matcher" after setting a key. In order of
likelihood:

1. **You did not restart.** Settings are read once at startup. `Ctrl+C`, then
   `npm run dev`.
2. **Wrong filename.** It must be `.env.local` in the project root — not
   `.env`, not `env.local`, not inside `src/`. On Windows, check Explorer is not
   hiding a `.txt` extension: `.env.local.txt` will not work.
3. **Quotes or spaces.** `GEMINI_API_KEY=AIza...` — no quote marks, no space
   around the `=`, nothing after the key.
4. **A trailing space from pasting.** Invisible and very common. Delete the line
   and retype the `=`, then paste.
5. **On Vercel:** you added the variable but did not redeploy. Variable changes
   only apply to new deployments.

### "the API key was rejected" (401 / 403)

The key is reaching the app but the provider refuses it.

- Check it is copied in full — Gemini keys are about 39 characters
- Make sure it matches the provider you are using: a Gemini key in
  `OPENAI_API_KEY` will always be rejected
- Generate a fresh key at <https://aistudio.google.com/apikey>
- If you have several keys set, the app prefers Gemini, then OpenAI, then
  Anthropic. Force one with `AI_PROVIDER=gemini`.

### "rate limit or quota reached" (429)

You have hit the free tier's per-minute limit. Wait a minute. Processing seven demo
emails in one go is fourteen model calls, which can trip it.

Nothing is lost — the offline matcher handles the emails and says so. Reprocess
them later with **Classify again** on each email.

### "the model name was not found" (404)

Model names change over time. Remove `GEMINI_MODEL` from your settings to use the
default, or check the current names at
<https://ai.google.dev/gemini-api/docs/models>.

### Classifications are wrong

First, look at the email's detail page — it shows the score for every type and the
model's reasoning, which usually makes the cause obvious.

| Symptom | Fix |
|---|---|
| Two types keep being confused | Sharpen both descriptions to say what each *excludes*. Raise the margin slider. |
| Everything gets flagged | Your types need more examples, or better keywords. Run `npm run calibrate`. |
| Obviously unknown mail gets classified | Lower the relevant threshold slider, and check for over-broad keywords. |
| One type wins everything | Its keywords are too generic. Remove single common words like "order" or "email". |

Then run `npm run calibrate`, which tells you whether your types are genuinely
distinguishable or just look that way.

### Replies read generically

Two likely causes. Check whether the draft says "Built by filling in the approved
template" — if so, no AI was involved, and either no key is set or the call failed
(the page will say which). Otherwise, your reply template may be too rigid; leave
the AI room to address specifics, and use the guidance field to tell it what to
cover.

---

## Database problems

### "This deployment needs a database before it can do anything"

Or, on an older build, a raw `ENOENT: no such file or directory, mkdir '/var/task/.data'`.

Both mean the same thing: **`DATABASE_URL` is not set on the deployment.**

On your own computer the app writes to a local file, which needs no setup. Hosting
platforms give each request a throwaway, read-only filesystem, so that file cannot
be created and there is nowhere to put anything.

To fix it:

1. Create a free Postgres database and copy its **pooled** connection string —
   [guide 3](03-database.md) walks through it, and takes about five minutes.
2. In Vercel: your project → **Settings** → **Environment Variables** → add
   `DATABASE_URL` with that value.
3. Go to **Deployments**, click the ⋯ menu on the newest one, and choose
   **Redeploy**.

Step 3 is the one people miss. **Adding an environment variable does nothing to
the deployment that is already running** — only a new deployment picks it up.

Confirm it worked at `https://your-app.vercel.app/api/health`, which should show
`"kind": "postgres"`.

### "Could not reach the database"

- **Typo in the connection string.** Copy it fresh from Neon.
- **The password contains special characters.** If it has `@`, `:` or `/`, those
  must be percent-encoded. Easiest fix: reset the password in Neon to something
  alphanumeric.
- **Neon project is suspended.** The free tier sleeps after five minutes; the first
  query wakes it and can take a second or two. Just retry.
- **Missing `?sslmode=require`.** Neon and Supabase both need SSL.

### "relation ... does not exist"

The tables are missing. The app recreates them automatically on the next request,
so just retry once. If it persists, the database user may lack `CREATE TABLE`
permission — with Neon's default user this is not an issue.

### Data disappears between page loads

You are hosting without a database. The dashboard will be showing a warning about
it. This is the situation [guide 3](03-database.md) exists for: set `DATABASE_URL`
and redeploy.

### Everything vanished after I set DATABASE_URL

Expected. Your earlier work was in the local file; the app is now reading a
different, empty database. Load the demo company again, or re-add your types.

---

## Email problems

Always start with **Mailbox → Test the connection**. It tests reading and sending
separately and shows the actual error, which distinguishes "wrong password" from
"wrong port" from "not configured".

### "the mail server rejected the username or password"

For Gmail, almost always because you used your normal account password.

1. 2-Step Verification must be **on**: <https://myaccount.google.com/security>
2. Create an App Password: <https://myaccount.google.com/apppasswords>
3. **Remove the spaces** — `abcd efgh ijkl mnop` becomes `abcdefghijklmnop`
4. For reading, IMAP must be enabled in Gmail → Settings → Forwarding and POP/IMAP

For Outlook, a work or school account often has IMAP disabled by an administrator.
Use a personal account.

### Sending times out

Nearly always the port and TLS setting disagreeing:

| Port | Required setting |
|---|---|
| 587 | `SMTP_SECURE=false` |
| 465 | `SMTP_SECURE=true` |

If both combinations fail, your network may block outbound SMTP — common on
university and corporate networks. Try a phone hotspot to confirm. Vercel does not
block it, so a deployed copy may work where your local one does not.

### "Fetch new mail" finds nothing

- It only looks for **unread** messages. Mark one unread and try again.
- If `IMAP_MARK_SEEN=true`, previously fetched mail is now read, which is the point.
- Check `IMAP_MAILBOX` — `INBOX` is right for almost everyone. Gmail's Spam and
  All Mail folders have unusual names.
- Confirm the email actually arrived in the account you configured.

### Fetching times out on Vercel

Each message costs two model calls, and a request has 60 seconds. Lower the batch:

```
IMAP_BATCH_SIZE=3
```

Then click **Fetch new mail** more than once to work through a backlog.

### No alert email arrives for flagged mail

In order:

1. Is `REVIEW_TEAM_EMAIL` set? Check **Settings** — a warning appears there if not.
2. Is SMTP configured and green on the Mailbox page?
3. Check the spam folder. Mail sent from a Gmail account to itself sometimes lands
   there.
4. Open the flagged item on the Review page — it says whether the alert was sent,
   and shows the error if it failed.

Either way the email is safely in the review queue. A failed alert never loses it.

### "This draft still contains placeholders"

Working as intended. The template asked for something the system could not work
out. Click **Edit**, replace the highlighted `{{placeholder}}`, save, and send.

There is an override, but the block exists for a good reason.

---

## Deployment problems

### The Vercel build fails

Read the build log — the real error is usually a few lines above where you first
look.

**"Module not found"** — a file was not committed. Check `git status`, then
`git add . && git commit && git push`.

**A TypeScript error** — run `npm run typecheck` locally to see it properly.

**"maxDuration exceeds the limit"** — your plan allows less than 60 seconds. Lower
the `maxDuration` value at the top of the affected file under
`src/app/api/`.

**It builds locally but not on Vercel** — usually a case-sensitivity problem. macOS
and Windows ignore filename case; Vercel's Linux builders do not. Check that every
import matches the actual filename exactly.

### The deployed site shows "Not signed in"

`APP_PASSWORD` is set, which is correct. Open the site itself rather than the API
endpoint and sign in.

Forgotten the password? Change `APP_PASSWORD` in Vercel's environment variables and
redeploy.

### Environment variable changes have no effect

They only apply to new deployments. After changing any variable: **Deployments** →
⋯ on the latest one → **Redeploy**.

### The first request is very slow

Both Vercel and Neon suspend idle resources. The first request wakes them, costing
a second or two. Load the page once before a live demo.

---

## Testing problems

### `npm run test:flow` cannot connect

It needs the app already running. In another terminal:

```bash
npm run build && npm start
```

Or use `npm run verify`, which starts everything itself.

### Tests fail with "The compiled test build is missing"

```bash
npm run build:test
```

`npm test` normally does this for you.

### `npm run verify` fails at one stage

Full logs are written to `/tmp/verify-*.log` — for example `/tmp/verify-flow.log`
for the main suite. Each names the specific check that failed.

### Tests wiped my data

They reset the database they point at — that is stated in the README and at the top
of each script. Never run them against anything you care about. Use a separate
database for testing.

---

## Still stuck

Three things that between them diagnose almost anything:

**1. The health check** — `/api/health`.

**2. The server logs.** Locally, the terminal running the app. On Vercel, project →
**Logs**. Every error the app reports is written there with an explanation.

**3. The activity log** — the Dashboard's "Recent activity" panel, or
`/api/log?limit=100`, which records what the system did and why.

And if something worked before and does not now, `git diff` is often the fastest
answer.
