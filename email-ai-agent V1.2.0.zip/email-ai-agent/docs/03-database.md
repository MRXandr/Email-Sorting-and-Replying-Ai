# 3. Add a database

**Time needed:** about five minutes
**Cost:** nothing. Neon's free tier is permanent, not a trial.

**Do this before deploying.** You can skip it while working on your own computer.

---

## Why you need one

On your computer, the app saves everything to a file at `.data/store.json`. That
is deliberate — it means guide 1 needed no setup at all.

Hosting is different. Vercel does not run one long-lived server; it runs your code
in short-lived instances that are created on demand and thrown away. Two
consequences:

1. **The filesystem is read-only**, apart from a temporary folder.
2. **Instances do not share storage.** Two visitors can be served by two
   different instances that cannot see each other's data.

So without a database on a hosted deployment, you would add an email type, hit
refresh, and find it gone — not because of a bug, but because the second request
was served by a different instance. The app detects this situation and warns you
prominently on the Dashboard, but the fix is a real database.

Postgres is what this project uses. It is free, and the app creates all its own
tables on first run — there is nothing to set up by hand.

---

## Step 1 — Create a free Postgres database on Neon

1. Go to **<https://neon.com>** and click **Sign up**. Signing in with GitHub is
   easiest, since you will want a GitHub account for guide 5 anyway.
2. It will offer to create your first project. Give it any name — `email-agent` is
   fine.
3. Pick the region closest to you. This only affects speed.
4. Click **Create**.

It takes a few seconds. You will land on the project dashboard.

---

## Step 2 — Copy the connection string

On the project dashboard there is a **Connection string** box. It looks like:

```
postgresql://neondb_owner:npg_AbC123XyZ@ep-cool-name-a1b2c3-pooler.eu-central-1.aws.neon.tech/neondb?sslmode=require
```

**Make sure you take the pooled one.** Look for `-pooler` in the middle of the
host name. Neon usually shows the pooled string by default; if there is a
**Connection pooling** toggle, turn it on.

This matters more than it looks. Serverless means many short-lived instances, each
wanting a connection. A normal Postgres database allows a limited number and will
start refusing them. The pooled endpoint exists exactly for this, and using the
direct one is a common cause of an app that works fine at first and then starts
failing under any real use.

Click the copy button.

> That string contains the database password. Treat it like one.

---

## Step 3 — Put it in your settings file

Open `.env.local` (create it by copying `.env.example` if you have not already)
and find:

```
DATABASE_URL=
```

Paste the string after the `=`, all on one line, no quotes:

```
DATABASE_URL=postgresql://neondb_owner:npg_AbC123XyZ@ep-cool-name-a1b2c3-pooler.eu-central-1.aws.neon.tech/neondb?sslmode=require
```

Save.

---

## Step 4 — Restart and check

```bash
# Ctrl+C in the terminal running the app, then
npm run dev
```

Open the Dashboard. Under "How it is set up" you should see:

```
Storage      ● Postgres
```

with a green dot. You can also check directly by visiting
<http://localhost:3000/api/health>, which returns:

```json
{ "status": "ok", "database": { "ok": true, "kind": "postgres", "error": null } }
```

---

## Step 5 — Load your data into it

The new database is empty — your earlier work is still in the local file, which
the app is no longer reading. Click **Load the demo company** on the Dashboard to
populate it, or start adding your own types.

The nine tables are created automatically the first time the app connects. You do
not need to run any SQL. If you are curious, look at
`src/lib/db/schema.ts`.

---

## Seeing inside the database

Neon has a built-in SQL editor: open your project and click **SQL Editor**. Try:

```sql
SELECT name, slug FROM email_types ORDER BY name;

SELECT subject, status FROM emails ORDER BY created_at DESC LIMIT 10;

-- The examples your team taught it, which is the learning loop made visible
SELECT t.name, s.subject, s.created_at
FROM type_samples s
JOIN email_types t ON t.id = s.type_id
WHERE s.source = 'human_review'
ORDER BY s.created_at DESC;
```

---

## Free tier limits

Neon's free plan gives you 0.5 GB of storage and a project that suspends itself
after five minutes of inactivity, waking on the next query. That wake takes a
second or so, which you may notice as a slow first page load after a quiet period.
It does not lose data.

0.5 GB is a very large number of emails. You will not get near it.

---

## If you would rather use Supabase

Supabase also offers free Postgres and works identically — the app only needs a
connection string.

1. Create a project at <https://supabase.com>
2. Go to **Project Settings → Database**
3. Under **Connection string**, choose the **Connection pooling** tab (again,
   pooling matters)
4. Copy it and replace `[YOUR-PASSWORD]` with your database password
5. Paste it into `DATABASE_URL` as above

Any Postgres works, including one on your own machine. For a local one, add
`?sslmode=disable` to the end of the string.

---

## A note on what is stored

The database holds your email types and their drafts, the emails the system has
processed, its decisions, the drafted replies, and the review queue. That includes
the full text of every email processed — so if you point this at real customer
mail, the usual care applies about where that data lives and who can reach it. See
[guide 5](05-deploy-to-vercel.md#step-8--protect-it-with-a-password) about
putting a password on the site before sharing the link.

---

**Next:** [Connect a real mailbox](04-connect-email.md) — or skip straight to
[putting it on the internet](05-deploy-to-vercel.md) if you do not need real email
yet.
