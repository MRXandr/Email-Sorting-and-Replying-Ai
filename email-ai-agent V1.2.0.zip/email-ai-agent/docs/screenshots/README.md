# What it looks like

These are real screenshots of the running app with the demo company loaded and the
seven demo emails processed — exactly what you get after following
[guide 1](../01-run-it-locally.md).

---

### Dashboard

![Dashboard](1-dashboard.png)

Five emails sorted automatically, two waiting for a person. The right-hand panel
is worth knowing about: it shows at a glance whether the AI, the database and the
mailbox are actually connected, which is the fastest way to spot a setup problem.

---

### Inbox

![Inbox](2-inbox.png)

Everything processed, with its type, status and confidence. Flagged emails link
straight to the review screen.

---

### One email, and why it was classified that way

![Email detail](3-email-detail.png)

The part that matters for explaining the system to anyone: **every type's score**
is shown, with the phrases that matched, so no decision is a black box.

This example also shows the safety behaviour. The complaint template asks for
`{{expected_resolution_date}}` — a promise only a person can make — so the system
left the gap visible, highlighted it, and blocked sending until someone fills it
in. It would rather show an obvious hole than invent a date.

---

### The review queue

![Review queue](4-review-queue.png)

The two emails nothing matched: a supplier's wholesale pitch and a job
application. Neither is a customer enquiry, so the system refused to guess.

---

### Deciding what an unknown email is

![Review decision](5-review-decide.png)

The human-in-the-loop screen, and the point of the whole project. Two options:
file it under a type that already exists, or define a new one with its own reply
template. Either way the email is stored as a training example, so the next email
like it is handled without anyone being asked.

---

### Email types

![Types](6-types.png)

Your categories, with how many examples each has and how many it has learned from
people.

---

### One type's input and output drafts

![Type detail](7-type-detail.png)

The example incoming emails on the left of the pipeline, and the approved reply
template on the right — with a live preview highlighting every placeholder.

---

### Settings

![Settings](8-settings.png)

Company details, where flagged emails get reported, and how cautious the system
should be. The bottom panel shows what the deployment has configured.

---

### Mailbox

![Mailbox](9-mailbox.png)

Reading real email over IMAP, with a connection test that reports the actual
error when something is wrong.
